"""Validation layers for marivo.semantic v1.1.

Three layers:
  1. decorator-time (inline in authoring)
  2. AST whitelist (base metric body scanning)
  3. assembly-time (cross-object reference validation)
"""

from __future__ import annotations

import ast
import hashlib
import inspect
import textwrap
from collections.abc import Callable
from dataclasses import dataclass, field
from types import MappingProxyType
from typing import TYPE_CHECKING, Any, Literal, cast

from marivo.datasource.ir import DatasourceIR, TableSourceIR
from marivo.introspection._fuzzy import did_you_mean
from marivo.refs import SemanticKind
from marivo.refs import ref as ref_factory
from marivo.semantic.constraints import ASTSpec, ConstraintId, get_constraint
from marivo.semantic.errors import (
    ErrorKind,
    SemanticError,
    SemanticLoadError,
    StructuredWarning,
    WarningKind,
    repair,
)
from marivo.semantic.ir import (
    CumulativeComposition,
    DateParse,
    DatetimeParse,
    DimensionIR,
    DimensionKind,
    DomainIR,
    EntityIR,
    EventIR,
    HourPrefixParse,
    LinearComposition,
    MeasureIR,
    MetricIR,
    PeriodCalendarIR,
    RelationshipIR,
    SnapshotVersioningIR,
    SourceLocation,
    StateInceptionIR,
    StateModelDeclarationIR,
    StateModelIR,
    StateTransitionIR,
    StateTriggerDeclarationIR,
    StateTriggerIR,
    StrptimeParse,
    TemporalSetIR,
    TimestampParse,
    ValidityVersioningIR,
    WorkScheduleIR,
    additivity_bucket,
    composition_components,
    is_time_bearing_format,
)

if TYPE_CHECKING:
    from marivo.semantic._expression_binding import CompiledExpressionSidecar

__all__ = [
    "Registry",
    "assembly_validate",
    "canonicalize_state_models",
    "validate_decorator_call",
    "validate_event_body_ast",
    "validate_metric_body_ast",
]


# ---------------------------------------------------------------------------
# Registry type
# ---------------------------------------------------------------------------


@dataclass
class Registry:
    """Holds all loaded IR objects, indexed by semantic_id."""

    domains: dict[str, DomainIR] = field(default_factory=dict)
    datasources: dict[str, DatasourceIR] = field(default_factory=dict)
    entities: dict[str, EntityIR] = field(default_factory=dict)
    dimensions: dict[str, DimensionIR] = field(default_factory=dict)
    measures: dict[str, MeasureIR] = field(default_factory=dict)
    metrics: dict[str, MetricIR] = field(default_factory=dict)
    relationships: dict[str, RelationshipIR] = field(default_factory=dict)
    events: dict[str, EventIR] = field(default_factory=dict)
    state_models: dict[str, StateModelIR] = field(default_factory=dict)
    period_calendars: dict[str, PeriodCalendarIR] = field(default_factory=dict)
    temporal_sets: dict[str, TemporalSetIR] = field(default_factory=dict)
    work_schedules: dict[str, WorkScheduleIR] = field(default_factory=dict)
    _frozen: bool = field(default=False, init=False, repr=False)

    def freeze(self) -> None:
        """Freeze every registry map after successful whole-graph validation."""
        if self._frozen:
            return
        for name in (
            "domains",
            "datasources",
            "entities",
            "dimensions",
            "measures",
            "metrics",
            "relationships",
            "events",
            "state_models",
            "period_calendars",
            "temporal_sets",
            "work_schedules",
        ):
            value = dict(getattr(self, name))
            object.__setattr__(self, name, MappingProxyType(value))
        object.__setattr__(self, "_frozen", True)

    def __setattr__(self, name: str, value: object) -> None:
        if getattr(self, "_frozen", False):
            raise AttributeError("compiled semantic registry is immutable")
        object.__setattr__(self, name, value)


_PARTITION_TIME_COLUMN_NAMES = {
    "dt",
    "date",
    "ds",
    "log_date",
    "event_date",
    "order_date",
    "biz_date",
    "stat_date",
    "partition_date",
    "hh",
    "hour",
    "log_hour",
    "event_hour",
}

_TEMPORAL_DATA_TYPES = {"date", "datetime", "timestamp"}
_PUSHDOWN_UNFRIENDLY_CALLS = {"cast", "as_date", "as_timestamp"}


def _temporal_set_encoding(field: DimensionIR | None) -> Literal["date", "timestamp"] | None:
    """Return the closed civil-date/timestamp encoding for one time field.

    An omitted parse is resolved from the physical datasource at runtime, so
    the assembly validator leaves that case open.  ``strptime`` formats carry
    the same distinction explicitly; hour-prefix parsing is intentionally
    left unknown because it needs a separate date-bearing prefix field.
    """
    if field is None or not field.is_time_dimension:
        return None
    parse = field.parse
    if isinstance(parse, DateParse):
        return "date"
    if isinstance(parse, (DatetimeParse, TimestampParse)):
        return "timestamp"
    if isinstance(parse, StrptimeParse):
        return "timestamp" if is_time_bearing_format(parse.format) else "date"
    return None


def _participant_endpoint(
    event: EventIR,
    *,
    participant_name: str,
    registry: Registry,
) -> tuple[str | None, str | None]:
    participant = next(
        (item for item in event.participants if item.name == participant_name),
        None,
    )
    if participant is None:
        return None, None
    endpoint = event.source_entity
    for relationship_id in participant.path or ():
        relationship = registry.relationships.get(relationship_id)
        if relationship is None or relationship.from_entity != endpoint:
            return None, participant.cardinality
        endpoint = relationship.to_entity
    return endpoint, participant.cardinality


def canonicalize_state_models(
    registry: Registry,
    declarations: tuple[StateModelDeclarationIR, ...],
) -> list[SemanticError]:
    """Resolve authoring Event triggers once into final canonical StateModel IR."""
    errors: list[SemanticError] = []
    for declaration in declarations:
        subject = registry.entities.get(declaration.subject)
        if subject is None or not subject.primary_key:
            errors.append(
                SemanticLoadError(
                    kind=ErrorKind.INVALID_STATE_MODEL,
                    message=(
                        f"StateModel {declaration.semantic_id!r} subject must be a loaded "
                        "Entity with a non-empty primary key."
                    ),
                    refs=(declaration.semantic_id, declaration.subject),
                    expected="loaded Ref[entity] with non-empty primary_key",
                    received=declaration.subject,
                    location=declaration.location,
                    constraint_id=ConstraintId.STATE_MODEL_SHAPE,
                )
            )
            continue

        def resolve_trigger(
            trigger: object,
            *,
            current: StateModelDeclarationIR = declaration,
        ) -> StateTriggerIR | None:
            if not isinstance(trigger, StateTriggerDeclarationIR):
                return None
            event = registry.events.get(trigger.event_ref)
            if event is None:
                errors.append(
                    SemanticLoadError(
                        kind=ErrorKind.INVALID_STATE_MODEL,
                        message=(
                            f"StateModel {current.semantic_id!r} references unknown "
                            f"Event {trigger.event_ref!r}."
                        ),
                        refs=(current.semantic_id, trigger.event_ref),
                        expected="a loaded Ref[event]",
                        received=trigger.event_ref,
                        location=current.location,
                        constraint_id=ConstraintId.STATE_MODEL_TRIGGER,
                    )
                )
                return None
            if trigger.participant_role is not None:
                endpoint, cardinality = _participant_endpoint(
                    event,
                    participant_name=trigger.participant_role,
                    registry=registry,
                )
                if endpoint != current.subject or cardinality != "one":
                    errors.append(
                        SemanticLoadError(
                            kind=ErrorKind.INVALID_STATE_MODEL,
                            message=(
                                f"StateModel {current.semantic_id!r} trigger role "
                                f"{trigger.participant_role!r} does not identify its subject."
                            ),
                            refs=(
                                current.semantic_id,
                                trigger.event_ref,
                                trigger.participant_role,
                            ),
                            expected=(f"cardinality-one participant ending at {current.subject}"),
                            received=repr(
                                {
                                    "endpoint": endpoint,
                                    "cardinality": cardinality,
                                }
                            ),
                            location=current.location,
                            constraint_id=ConstraintId.STATE_MODEL_TRIGGER,
                        )
                    )
                    return None
                return StateTriggerIR(
                    event_ref=trigger.event_ref,
                    participant_role=trigger.participant_role,
                )

            qualifying: list[str] = []
            for participant in event.participants:
                endpoint, cardinality = _participant_endpoint(
                    event,
                    participant_name=participant.name,
                    registry=registry,
                )
                if endpoint == current.subject and cardinality == "one":
                    qualifying.append(participant.name)
            if len(qualifying) != 1:
                candidates = tuple(
                    (
                        "ms.participant_role("
                        f"event=ms.ref.event({trigger.event_ref!r}), name={name!r})"
                    )
                    for name in qualifying[:6]
                )
                kind = (
                    ErrorKind.AMBIGUOUS_PARTICIPANT_ROLE
                    if qualifying
                    else ErrorKind.INVALID_STATE_MODEL
                )
                errors.append(
                    SemanticLoadError(
                        kind=kind,
                        message=(
                            f"StateModel {current.semantic_id!r} Event trigger "
                            f"{trigger.event_ref!r} must resolve to exactly one subject role."
                        ),
                        refs=(current.semantic_id, trigger.event_ref),
                        expected=(f"one cardinality-one participant ending at {current.subject}"),
                        received=repr(tuple(qualifying)),
                        location=current.location,
                        constraint_id=ConstraintId.STATE_MODEL_TRIGGER,
                        details={"candidates": candidates},
                        repair=repair(
                            kind="reauthor",
                            canonical_id="participant_role",
                            action=(
                                "Choose one exact cardinality-one participant role "
                                "from the current Event definition."
                            ),
                            candidates=candidates,
                        ),
                    )
                )
                return None
            return StateTriggerIR(
                event_ref=trigger.event_ref,
                participant_role=qualifying[0],
            )

        inceptions: list[StateInceptionIR] = []
        transitions: list[StateTransitionIR] = []
        valid = True
        for trigger in declaration.inceptions:
            resolved = resolve_trigger(trigger)
            if resolved is None:
                valid = False
            else:
                inceptions.append(StateInceptionIR(trigger=resolved))
        for from_state, trigger, to_state in declaration.transitions:
            resolved = resolve_trigger(trigger)
            if resolved is None:
                valid = False
            else:
                transitions.append(
                    StateTransitionIR(
                        from_state=from_state,
                        trigger=resolved,
                        to_state=to_state,
                    )
                )
        if not valid:
            continue

        inception_keys = [
            (item.trigger.event_ref, item.trigger.participant_role) for item in inceptions
        ]
        if len(set(inception_keys)) != len(inception_keys):
            errors.append(
                SemanticLoadError(
                    kind=ErrorKind.INVALID_STATE_MODEL,
                    message=f"StateModel {declaration.semantic_id!r} has duplicate inception triggers.",
                    refs=(declaration.semantic_id,),
                    expected="unique canonical inception triggers",
                    received=repr(tuple(inception_keys)),
                    location=declaration.location,
                    constraint_id=ConstraintId.STATE_MODEL_SHAPE,
                )
            )
            continue

        terminal = {state.name for state in declaration.states if state.terminal}
        illegal_terminal = next(
            (item.from_state for item in transitions if item.from_state in terminal),
            None,
        )
        if illegal_terminal is not None:
            errors.append(
                SemanticLoadError(
                    kind=ErrorKind.INVALID_STATE_MODEL,
                    message=(
                        f"StateModel {declaration.semantic_id!r} terminal state "
                        f"{illegal_terminal!r} has an outgoing transition."
                    ),
                    refs=(declaration.semantic_id, illegal_terminal),
                    expected="terminal states with no outgoing transitions",
                    received=illegal_terminal,
                    location=declaration.location,
                    constraint_id=ConstraintId.STATE_MODEL_SHAPE,
                )
            )
            continue

        targets: dict[tuple[str, str, str], str] = {}
        nondeterministic: tuple[str, str, str] | None = None
        for item in transitions:
            key = (
                item.from_state,
                item.trigger.event_ref,
                item.trigger.participant_role,
            )
            existing = targets.get(key)
            if existing is not None and existing != item.to_state:
                nondeterministic = key
                break
            targets[key] = item.to_state
        if nondeterministic is not None:
            errors.append(
                SemanticLoadError(
                    kind=ErrorKind.INVALID_STATE_MODEL,
                    message=(
                        f"StateModel {declaration.semantic_id!r} has nondeterministic "
                        "targets for one source state and trigger."
                    ),
                    refs=(declaration.semantic_id,),
                    expected="at most one target for each source state and canonical trigger",
                    received=repr(nondeterministic),
                    location=declaration.location,
                    constraint_id=ConstraintId.STATE_MODEL_SHAPE,
                )
            )
            continue

        registry.state_models[declaration.semantic_id] = StateModelIR(
            semantic_id=declaration.semantic_id,
            domain=declaration.domain,
            name=declaration.name,
            subject=declaration.subject,
            states=declaration.states,
            inceptions=tuple(inceptions),
            transitions=tuple(transitions),
            ai_context=declaration.ai_context,
            python_symbol=declaration.python_symbol,
            location=declaration.location,
        )
    return errors


def _source_column_name(node: ast.AST) -> str | None:
    """Return the base table column name for simple chained column expressions."""
    current = node
    while isinstance(current, ast.Call):
        current = current.func
    while isinstance(current, ast.Attribute):
        value = current.value
        if isinstance(value, ast.Name):
            return current.attr
        current = value
        while isinstance(current, ast.Call):
            current = current.func
    return None


def _has_pushdown_unfriendly_time_call(node: ast.AST) -> bool:
    for child in ast.walk(node):
        if not isinstance(child, ast.Call) or not isinstance(child.func, ast.Attribute):
            continue
        if child.func.attr in _PUSHDOWN_UNFRIENDLY_CALLS:
            return True
    return False


def _return_expr(fn: Callable[..., Any]) -> ast.AST | None:
    try:
        source = textwrap.dedent(inspect.getsource(fn))
        tree = ast.parse(source)
    except (OSError, TypeError, IndentationError, SyntaxError):
        return None
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            for stmt in node.body:
                if isinstance(stmt, ast.Return):
                    return stmt.value
            return None
    return None


def _time_dimension_pushdown_advisory(field_ir: DimensionIR, fn: Callable[..., Any] | None) -> bool:
    if not field_ir.is_time_dimension:
        return False
    parse = field_ir.parse
    _temporal_parse_kinds = (DateParse, DatetimeParse, TimestampParse)
    if not isinstance(parse, _temporal_parse_kinds):
        return False
        return False
    if fn is None:
        return False
    expr = _return_expr(fn)
    if expr is None or not _has_pushdown_unfriendly_time_call(expr):
        return False
    source_column = _source_column_name(expr)
    if source_column is None:
        return False
    return source_column.lower() in _PARTITION_TIME_COLUMN_NAMES


_CAST_TARGET_TO_DECLARED: dict[str, set[str]] = {
    "date": {"date"},
    "timestamp": {"datetime", "timestamp"},
    "string": {"string"},
    "int32": {"integer"},
    "int64": {"integer"},
}


def _infer_terminal_cast(expr: ast.AST) -> str | None:
    """Walk a chained expression to find the terminal type-producing call.

    For table.col.cast("timestamp").cast("date"), the terminal call
    is .cast("date") — the root Call node evaluated last in the chain.
    Also detects .as_date() → "date" and .as_timestamp() → "timestamp".
    """
    current = expr
    while isinstance(current, ast.Call) and isinstance(current.func, ast.Attribute):
        method = current.func.attr
        if method == "cast" and current.args:
            arg = current.args[0]
            if isinstance(arg, ast.Constant) and isinstance(arg.value, str):
                return arg.value
        if method == "as_date":
            return "date"
        if method == "as_timestamp":
            return "timestamp"
        current = current.func.value
    return None


def _time_dimension_dtype_advisory(
    field_ir: DimensionIR, fn: Callable[..., Any] | None
) -> str | None:
    """Return the inferred cast target if it conflicts with declared data_type, else None."""
    if not field_ir.is_time_dimension:
        return None
    parse = field_ir.parse
    _temporal_parse_kinds = (DateParse, DatetimeParse, TimestampParse)
    if not isinstance(parse, _temporal_parse_kinds):
        return None
    if fn is None:
        return None
    expr = _return_expr(fn)
    if expr is None:
        return None
    inferred = _infer_terminal_cast(expr)
    if inferred is None:
        return None
    compatible = _CAST_TARGET_TO_DECLARED.get(inferred)
    if compatible is None:
        return None
    # Extract data_type from parse variant for comparison
    parse = field_ir.parse
    data_type_val: str | None = None
    if parse is None:
        return None  # deferred parse — cannot validate at this stage
    if isinstance(parse, DateParse):
        data_type_val = "date"
    elif isinstance(parse, DatetimeParse):
        data_type_val = "datetime"
    elif isinstance(parse, TimestampParse):
        data_type_val = "timestamp"
    elif isinstance(parse, StrptimeParse):
        data_type_val = "strptime"
    elif isinstance(parse, HourPrefixParse):
        data_type_val = "hour_prefix"
    if data_type_val not in compatible:
        return inferred
    return None


# ---------------------------------------------------------------------------
# Layer 1: decorator-time validation
# ---------------------------------------------------------------------------


def validate_decorator_call(kind: str, payload: dict[str, Any]) -> None:
    """Layer 1: decorator-time validation.  Raises SemanticDecoratorError.

    Currently a passthrough — decorator-time validation is handled inline
    in the authoring module.  This function exists as an extension point
    for future decorator-level checks.
    """


# ---------------------------------------------------------------------------
# Layer 2: AST whitelist validation
# ---------------------------------------------------------------------------


def _ast_spec_for(constraint_id: ConstraintId) -> ASTSpec:
    constraint = get_constraint(constraint_id)
    assert constraint is not None and constraint.ast_spec is not None
    return constraint.ast_spec


_EXPR_BODY_AST_SPEC = _ast_spec_for(ConstraintId.AST_SINGLE_RETURN)

# Names that indicate a raw SQL escape hatch when used as an attribute.
_SQL_ESCAPE_ATTRS = frozenset(_EXPR_BODY_AST_SPEC.forbidden_attributes)

# ibis Table method/property names that shadow column access via dot notation.
try:
    import ibis as _ibis

    _IBIS_TABLE_ATTRS: frozenset[str] = frozenset(
        name for name in dir(_ibis.Table) if not name.startswith("_")
    )
    del _ibis
except ImportError:
    _IBIS_TABLE_ATTRS = frozenset()

# AST node types that are FORBIDDEN as statements in metric bodies.
_AST_TRY_STAR = cast("type[ast.stmt]", getattr(ast, "TryStar", ast.Try))

_FORBIDDEN_STMT_TYPES: frozenset[type[ast.stmt]] = frozenset(
    {
        ast.Assign,
        ast.AugAssign,
        ast.AnnAssign,
        ast.Import,
        ast.ImportFrom,
        ast.For,
        ast.AsyncFor,
        ast.While,
        ast.If,
        ast.With,
        ast.AsyncWith,
        ast.Try,
        _AST_TRY_STAR,
        ast.FunctionDef,
        ast.AsyncFunctionDef,
        ast.ClassDef,
        ast.Delete,
        ast.Global,
        ast.Nonlocal,
        ast.Raise,
        ast.Assert,
        ast.Pass,
        ast.Break,
        ast.Continue,
    }
)


class _BaseMetricASTValidator(ast.NodeVisitor):
    """Walk a single-return ibis expression body AST and accumulate errors."""

    def __init__(self, fn_name: str, *, body_label: str = "Metric body") -> None:
        self.fn_name = fn_name
        self.body_label = body_label
        self.errors: list[SemanticError] = []
        self._param_names: set[str] = set()
        self._parent_map: dict[ast.AST, ast.AST] = {}

    def _add_error(
        self,
        kind: ErrorKind,
        message: str,
        *,
        constraint_id: ConstraintId,
    ) -> None:
        self.errors.append(
            SemanticLoadError(
                kind=kind.value,
                message=message,
                refs=(self.fn_name,),
                constraint_id=constraint_id,
            )
        )

    def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
        # Extract parameter names and build parent map for context-sensitive checks.
        self._param_names = {arg.arg for arg in node.args.args}
        self._parent_map = {
            child: parent for parent in ast.walk(node) for child in ast.iter_child_nodes(parent)
        }

        # Validate the function body structure

        # Must have exactly one top-level Return (no nested returns in if/else/etc.)
        # Recursively find all Return nodes in the entire function body
        all_returns: list[ast.Return] = []
        for child in ast.walk(node):
            if isinstance(child, ast.Return):
                all_returns.append(child)

        if len(all_returns) == 0:
            self._add_error(
                ErrorKind.METRIC_BODY_NOT_SINGLE_RETURN,
                f"{self.body_label} of {self.fn_name!r} must contain exactly one "
                f"return statement, found none.",
                constraint_id=ConstraintId.AST_SINGLE_RETURN,
            )
        elif len(all_returns) > 1:
            self._add_error(
                ErrorKind.METRIC_BODY_NOT_SINGLE_RETURN,
                f"{self.body_label} of {self.fn_name!r} must contain exactly one "
                f"return statement, found {len(all_returns)}.",
                constraint_id=ConstraintId.AST_SINGLE_RETURN,
            )

        # Check for forbidden statement types anywhere in the body
        leading_docstring = node.body[0] if node.body and _is_docstring_stmt(node.body[0]) else None
        for child in ast.walk(node):
            if child is node:
                continue
            # Skip expression nodes — we only check statement nodes
            if not isinstance(child, ast.stmt):
                continue
            if child is leading_docstring:
                continue
            # Allow the single Return; every other statement violates the
            # expression-body contract.
            if isinstance(child, ast.Return):
                continue
            for forbidden_type in (*_FORBIDDEN_STMT_TYPES, ast.Expr):
                if isinstance(child, forbidden_type):
                    # Every statement that reaches this loop is a forbidden
                    # statement: returns are skipped above and wrong return
                    # counts are handled separately (AST_SINGLE_RETURN). Classify
                    # them uniformly so the hint can route the author to the
                    # body-free constructors and ibis conditionals.
                    self._add_error(
                        ErrorKind.INVALID_COMPONENT_BODY,
                        f"{self.body_label} of {self.fn_name!r} contains a forbidden "
                        f"{type(child).__name__} statement.",
                        constraint_id=ConstraintId.AST_FORBIDDEN_STATEMENT,
                    )
                    break

        # Walk only the function body for deeper AST checks. Decorator calls
        # are normal Python and are not part of the captured expression DSL.
        for stmt in node.body:
            self.visit(stmt)

    def visit_Attribute(self, node: ast.Attribute) -> None:
        # Check for .sql / .raw_sql escape hatches
        if node.attr in _SQL_ESCAPE_ATTRS:
            self._add_error(
                ErrorKind.SQL_ESCAPE_HATCH,
                f"{self.body_label} of {self.fn_name!r} uses .{node.attr}(), "
                f"which is not allowed. Use provenance=ms.from_sql(...) on the decorator instead.",
                constraint_id=ConstraintId.AST_SQL_ESCAPE_HATCH,
            )
        # Check for ibis Table attribute shadowing (e.g. orders.schema instead of orders["schema"])
        if (
            _IBIS_TABLE_ATTRS
            and isinstance(node.value, ast.Name)
            and node.value.id in self._param_names
            and node.attr in _IBIS_TABLE_ATTRS
        ):
            # Method calls like orders.filter(...) are valid ibis; only flag
            # bare attribute access (return orders.schema), not call-site func.
            parent = self._parent_map.get(node)
            if not (isinstance(parent, ast.Call) and parent.func is node):
                self._add_error(
                    ErrorKind.IBIS_ATTR_SHADOW,
                    f"{self.body_label} of {self.fn_name!r} accesses .{node.attr} on the "
                    f"entity table parameter '{node.value.id}', which shadows an ibis "
                    f"Table method/property. Use bracket notation instead: "
                    f'{node.value.id}["{node.attr}"].',
                    constraint_id=ConstraintId.AST_IBIS_ATTR_SHADOW,
                )
        self.generic_visit(node)

    def visit_Call(self, node: ast.Call) -> None:
        func = node.func
        if (
            isinstance(func, ast.Attribute)
            and isinstance(func.value, ast.Name)
            and func.value.id == "ms"
            and func.attr == "component"
        ):
            self._add_error(
                ErrorKind.INVALID_COMPONENT_BODY,
                f"{self.body_label} of {self.fn_name!r} calls ms.component(), "
                "which is no longer supported. Use ms.ratio/ms.linear "
                "for body-free derived metric definitions.",
                constraint_id=ConstraintId.METRIC_COMPONENT_SCOPE,
            )
        self.generic_visit(node)

    def visit_Lambda(self, node: ast.Lambda) -> None:
        self._add_error(
            ErrorKind.INVALID_COMPONENT_BODY,
            f"{self.body_label} of {self.fn_name!r} contains a lambda expression, which is not allowed.",
            constraint_id=ConstraintId.AST_FORBIDDEN_STATEMENT,
        )
        # Don't recurse into lambda body


def _is_docstring_stmt(node: ast.stmt) -> bool:
    return (
        isinstance(node, ast.Expr)
        and isinstance(node.value, ast.Constant)
        and isinstance(node.value.value, str)
    )


def _body_hash_without_docstring(func_node: ast.FunctionDef) -> str:
    body = list(func_node.body)
    if body and _is_docstring_stmt(body[0]):
        body = body[1:]
    normalized = ast.dump(ast.Module(body=body, type_ignores=[]), include_attributes=False)
    return hashlib.sha256(normalized.encode()).hexdigest()[:16]


_BODY_KIND_LABELS = {
    "dimension": "Dimension body",
    "time_dimension": "Time dimension body",
    "measure": "Measure body",
    "metric": "Metric body",
}


def _event_call_name(node: ast.Call) -> str | None:
    if isinstance(node.func, ast.Name):
        return node.func.id
    if (
        isinstance(node.func, ast.Attribute)
        and isinstance(node.func.value, ast.Name)
        and node.func.value.id == "ms"
    ):
        return node.func.attr
    return None


def validate_event_body_ast(fn: Callable[..., Any]) -> Literal["all_rows", "filtered"]:
    """Validate the closed Event row-predicate body and classify its shape."""
    try:
        source = textwrap.dedent(inspect.getsource(fn))
        tree = ast.parse(source)
    except (OSError, TypeError, IndentationError, SyntaxError) as exc:
        raise SemanticLoadError(
            kind=ErrorKind.INVALID_EVENT_PREDICATE,
            message=f"Event body {fn.__name__!r} source could not be inspected.",
            refs=(fn.__name__,),
            expected="one inspectable return expression",
            received=type(exc).__name__,
        ) from exc
    function = next(
        (
            node
            for node in ast.walk(tree)
            if isinstance(node, ast.FunctionDef) and node.name == fn.__name__
        ),
        None,
    )
    if function is None:
        raise SemanticLoadError(
            kind=ErrorKind.INVALID_EVENT_PREDICATE,
            message=f"Event body {fn.__name__!r} has no function definition.",
            refs=(fn.__name__,),
            expected="one function with one return",
            received="missing function",
        )
    base_validator = _BaseMetricASTValidator(fn.__name__, body_label="Event body")
    base_validator.visit(function)
    if base_validator.errors:
        first = base_validator.errors[0]
        raise SemanticLoadError(
            kind=ErrorKind.INVALID_EVENT_PREDICATE,
            message=first.message,
            refs=(fn.__name__,),
            expected="one return containing ms.all_rows() or a restricted boolean predicate",
            received=first.kind,
            hint="Keep exactly one return and remove statements, aggregation, joins, or external calls.",
        )
    returns = [node for node in ast.walk(function) if isinstance(node, ast.Return)]
    if len(returns) != 1 or returns[0].value is None:
        raise SemanticLoadError(
            kind=ErrorKind.INVALID_EVENT_PREDICATE,
            message=f"Event body {fn.__name__!r} must return one predicate.",
            refs=(fn.__name__,),
            expected="return ms.all_rows() or one restricted boolean expression",
            received="missing return value",
        )
    value = returns[0].value
    if (
        isinstance(value, ast.Call)
        and isinstance(value.func, ast.Attribute)
        and isinstance(value.func.value, ast.Name)
        and value.func.value.id == "ms"
        and value.func.attr == "all_rows"
    ):
        if value.args or value.keywords:
            raise SemanticLoadError(
                kind=ErrorKind.INVALID_EVENT_PREDICATE,
                message="ms.all_rows() accepts no arguments.",
                refs=(fn.__name__,),
                expected="return ms.all_rows()",
                received=ast.unparse(value),
            )
        return "all_rows"

    if not isinstance(value, (ast.Compare, ast.BinOp, ast.UnaryOp)):
        raise SemanticLoadError(
            kind=ErrorKind.INVALID_EVENT_PREDICATE,
            message=f"Event body {fn.__name__!r} does not return a boolean predicate.",
            refs=(fn.__name__,),
            expected="one or more ms.bind(...) comparisons joined by boolean composition",
            received=ast.unparse(value),
        )

    allowed_nodes = (
        ast.Return,
        ast.Compare,
        ast.BinOp,
        ast.UnaryOp,
        ast.Call,
        ast.Attribute,
        ast.Name,
        ast.Load,
        ast.Constant,
        ast.BitAnd,
        ast.BitOr,
        ast.Invert,
        ast.Eq,
        ast.NotEq,
        ast.Lt,
        ast.LtE,
        ast.Gt,
        ast.GtE,
    )
    for node in ast.walk(value):
        if not isinstance(node, allowed_nodes):
            raise SemanticLoadError(
                kind=ErrorKind.INVALID_EVENT_PREDICATE,
                message=f"Event body {fn.__name__!r} uses unsupported {type(node).__name__}.",
                refs=(fn.__name__,),
                expected="ms.bind comparisons joined by boolean composition",
                received=ast.unparse(value),
            )
        if isinstance(node, ast.Call) and _event_call_name(node) != "bind":
            raise SemanticLoadError(
                kind=ErrorKind.INVALID_EVENT_PREDICATE,
                message=f"Event body {fn.__name__!r} may call only ms.bind(...).",
                refs=(fn.__name__,),
                expected="ms.bind(dimension_ref, rows)",
                received=ast.unparse(node),
            )
        if isinstance(node, ast.Call):
            is_ms_bind = (
                isinstance(node.func, ast.Attribute)
                and isinstance(node.func.value, ast.Name)
                and node.func.value.id == "ms"
                and node.func.attr == "bind"
            )
            if not is_ms_bind or len(node.args) != 2 or node.keywords:
                raise SemanticLoadError(
                    kind=ErrorKind.INVALID_EVENT_PREDICATE,
                    message=(
                        f"Event body {fn.__name__!r} must call "
                        "ms.bind(dimension_ref, rows) exactly."
                    ),
                    refs=(fn.__name__,),
                    expected="ms.bind(dimension_ref, rows)",
                    received=ast.unparse(node),
                )
        if isinstance(node, ast.Compare) and (len(node.ops) != 1 or len(node.comparators) != 1):
            raise SemanticLoadError(
                kind=ErrorKind.INVALID_EVENT_PREDICATE,
                message="Chained comparisons are not supported in Event predicates.",
                refs=(fn.__name__,),
                expected="one comparison per predicate term",
                received=ast.unparse(node),
                hint="Split comparisons into parenthesized terms joined with & or |.",
            )
        if isinstance(node, ast.Constant) and isinstance(node.value, bool):
            raise SemanticLoadError(
                kind=ErrorKind.INVALID_EVENT_PREDICATE,
                message="Bare boolean constants are not Event predicates.",
                refs=(fn.__name__,),
                expected="return ms.all_rows() for an unfiltered Event",
                received=repr(node.value),
            )
    return "filtered"


def validate_metric_body_ast(
    fn: Callable[..., Any],
    mode: Literal["base"],
    *,
    body_kind: Literal["dimension", "time_dimension", "measure", "metric"] = "metric",
) -> str:
    """Layer 2: AST whitelist validation for base metric bodies.

    Returns the body AST hash for storage in MetricIR.

    Raises SemanticLoadError on validation failures.
    """
    if mode != "base":
        raise ValueError(f"unsupported metric body AST validation mode {mode!r}")
    body_label = _BODY_KIND_LABELS[body_kind]

    # Compute body AST hash
    try:
        source = inspect.getsource(fn)
        source = textwrap.dedent(source)
        tree = ast.parse(source)
        # Find the function definition node
        func_node: ast.FunctionDef | None = None
        for node in ast.walk(tree):
            if isinstance(node, ast.FunctionDef) and node.name == fn.__name__:
                func_node = node
                break
        if func_node is None:
            for node in ast.walk(tree):
                if isinstance(node, ast.FunctionDef):
                    func_node = node
                    break

        if func_node is None:
            body_hash = hashlib.sha256(b"<no-function>").hexdigest()[:16]
        else:
            body_hash = _body_hash_without_docstring(func_node)
    except (OSError, TypeError, IndentationError):
        body_hash = hashlib.sha256(b"<unavailable>").hexdigest()[:16]
        return body_hash

    if func_node is None:
        return body_hash

    base_validator = _BaseMetricASTValidator(fn.__name__, body_label=body_label)
    base_validator.visit(func_node)
    if base_validator.errors:
        raise base_validator.errors[0]

    return body_hash


# ---------------------------------------------------------------------------
# Layer 3: assembly-time cross-object validation
# ---------------------------------------------------------------------------


_AGGREGATE_METHODS = {"sum", "mean", "avg", "count", "nunique", "max", "min"}


def _validate_snapshot_versioning(
    errors: list[SemanticError],
    ds_id: str,
    ds_ir: EntityIR,
    versioning: SnapshotVersioningIR,
) -> None:
    """Validate snapshot versioning metadata at assembly time."""
    partition_name = versioning.partition_field.rsplit(".", 1)[-1]
    if partition_name not in ds_ir.primary_key:
        errors.append(
            SemanticLoadError(
                kind=ErrorKind.INVALID_ENTITY_VERSIONING,
                message=(
                    f"Snapshot dataset {ds_id!r} partition field "
                    f"{versioning.partition_field!r} must be part of primary_key."
                ),
                refs=(ds_id, versioning.partition_field),
                details={
                    "entity": ds_id,
                    "field": "partition_field",
                    "partition_field": versioning.partition_field,
                    "primary_key": list(ds_ir.primary_key),
                },
            )
        )


def _validate_validity_versioning(
    errors: list[SemanticError],
    ds_id: str,
    ds_ir: EntityIR,
    versioning: ValidityVersioningIR,
    registry: Registry,
) -> None:
    """Validate validity versioning metadata at assembly time."""
    # valid_from local name must be in primary_key
    valid_from_local = versioning.valid_from.rsplit(".", 1)[-1]
    if valid_from_local not in ds_ir.primary_key:
        errors.append(
            SemanticLoadError(
                kind=ErrorKind.INVALID_ENTITY_VERSIONING,
                message=(
                    f"Validity entity {ds_id!r} valid_from dimension "
                    f"{versioning.valid_from!r} must be part of primary_key."
                ),
                refs=(ds_id, versioning.valid_from),
                details={
                    "entity": ds_id,
                    "dimension": "valid_from",
                    "reason": (
                        f"{versioning.valid_from!r} is not in primary_key {list(ds_ir.primary_key)}"
                    ),
                },
            )
        )

    # dimension-existence check: valid_from and valid_to must resolve to known dimensions in this entity
    for label, field_id in (
        ("valid_from", versioning.valid_from),
        ("valid_to", versioning.valid_to),
    ):
        field = registry.dimensions.get(field_id)
        if field is None or field.entity != ds_id:
            errors.append(
                SemanticLoadError(
                    kind=ErrorKind.INVALID_ENTITY_VERSIONING,
                    message=(
                        f"Validity entity {ds_id!r} {label} dimension "
                        f"{field_id!r} does not resolve to a known dimension on this entity."
                    ),
                    refs=(ds_id, field_id),
                    details={
                        "entity": ds_id,
                        "dimension": label,
                        "ref": field_id,
                    },
                )
            )


def _validate_measure_refs(registry: Registry) -> list[SemanticError]:
    """Validate that every measure's entity resolves to a known entity."""
    errors: list[SemanticError] = []
    for measure in registry.measures.values():
        if measure.entity not in registry.entities:
            errors.append(
                SemanticLoadError(
                    kind=ErrorKind.ENTITY_NOT_FOUND,
                    message=f"Measure {measure.semantic_id!r} references unknown entity {measure.entity!r}.",
                    refs=(measure.semantic_id, measure.entity),
                    details={"measure": measure.semantic_id, "entity": measure.entity},
                )
            )
    return errors


def _validate_expression_bindings(
    registry: Registry,
    sidecar: CompiledExpressionSidecar,
) -> list[SemanticError]:
    """Validate every compiled field binding against exact positional ownership."""
    errors: list[SemanticError] = []
    for owning_ref, body in sidecar.bodies.items():
        entity_ids: tuple[str, ...]
        if owning_ref.kind in {SemanticKind.DIMENSION, SemanticKind.TIME_DIMENSION}:
            dimension = registry.dimensions.get(owning_ref.path)
            entity_ids = () if dimension is None else (dimension.entity,)
        elif owning_ref.kind is SemanticKind.MEASURE:
            measure = registry.measures.get(owning_ref.path)
            entity_ids = () if measure is None else (measure.entity,)
        elif owning_ref.kind is SemanticKind.METRIC:
            metric = registry.metrics.get(owning_ref.path)
            entity_ids = () if metric is None else metric.entities
        elif owning_ref.kind is SemanticKind.EVENT:
            event = registry.events.get(owning_ref.path)
            entity_ids = () if event is None else (event.source_entity,)
        else:
            continue
        for binding in body.bindings:
            field_ref = binding.to_ref()
            field_body = sidecar.bodies.get(field_ref)
            field_owner = sidecar.field_owners.get(field_ref)
            if field_ref not in sidecar.catalog_refs or field_body is None or field_owner is None:
                errors.append(
                    SemanticLoadError(
                        kind=ErrorKind.BINDING_TARGET_MISSING,
                        message=(
                            f"Expression body {owning_ref.key!r} binds missing field "
                            f"{field_ref.key!r}."
                        ),
                        refs=(owning_ref.key, field_ref.key),
                        expected=(
                            "a loaded dimension, time_dimension, or measure with a compiled body"
                        ),
                        received="missing catalog object, owner, or expression body",
                        hint=(
                            "Declare the field in the loaded catalog and call it as "
                            "ms.bind(field_ref, entity_alias)."
                        ),
                    )
                )
                continue
            if binding.entity_position >= len(entity_ids):
                errors.append(
                    SemanticLoadError(
                        kind=ErrorKind.BINDING_ENTITY_MISMATCH,
                        message=(
                            f"Expression body {owning_ref.key!r} binds field "
                            f"{field_ref.key!r} to unavailable entity position "
                            f"{binding.entity_position}."
                        ),
                        refs=(owning_ref.key, field_ref.key),
                        expected=f"an entity position below {len(entity_ids)}",
                        received=str(binding.entity_position),
                        hint="Call the field with its exact direct entity parameter.",
                    )
                )
                continue
            expected_owner = ref_factory.entity(entity_ids[binding.entity_position])
            if field_owner != expected_owner:
                errors.append(
                    SemanticLoadError(
                        kind=ErrorKind.BINDING_ENTITY_MISMATCH,
                        message=(
                            f"Field {field_ref.key!r} does not belong to entity position "
                            f"{binding.entity_position} in {owning_ref.key!r}."
                        ),
                        refs=(owning_ref.key, field_ref.key, expected_owner.key),
                        expected=expected_owner.key,
                        received=field_owner.key,
                        hint="Call the field with the direct parameter for its owning entity.",
                    )
                )
    return errors


def _aggregate_receiver_param_name(call: ast.Call) -> str | None:
    func = call.func
    if not isinstance(func, ast.Attribute):
        return None
    if func.attr not in _AGGREGATE_METHODS:
        return None
    current: ast.AST = func.value
    while isinstance(current, (ast.Attribute, ast.Subscript, ast.Call)):
        if isinstance(current, ast.Attribute):
            current = current.value
            continue
        if isinstance(current, ast.Subscript):
            current = current.value
            continue
        if isinstance(current, ast.Call):
            current = current.func
            continue
    if isinstance(current, ast.Name):
        return current.id
    return None


def _non_root_aggregate_entity(
    fn: Callable[..., Any],
    *,
    metric_ir: MetricIR,
) -> str | None:
    try:
        source = textwrap.dedent(inspect.getsource(fn))
    except (OSError, TypeError):
        return None
    tree = ast.parse(source)
    func = next((node for node in ast.walk(tree) if isinstance(node, ast.FunctionDef)), None)
    if func is None:
        return None
    param_names = [arg.arg for arg in func.args.args]
    entity_by_param = dict(zip(param_names, metric_ir.entities, strict=False))
    for node in ast.walk(func):
        if not isinstance(node, ast.Call):
            continue
        param = _aggregate_receiver_param_name(node)
        if param is None:
            continue
        entity = entity_by_param.get(param)
        if entity is not None and entity != metric_ir.root_entity:
            return entity
    return None


def _is_filtered_domain_ref(ref: str, loaded_models: set[str] | None) -> bool:
    """Return True if ref points to an object in a model that was filtered out."""
    if loaded_models is None or "." not in ref:
        return False
    return ref.split(".", 1)[0] not in loaded_models


def _validate_default_time_dimension_unique(
    errors: list[SemanticError],
    registry: Registry,
) -> None:
    from collections import defaultdict

    defaults_by_entity: dict[str, list[str]] = defaultdict(list)
    for f_id, f_ir in registry.dimensions.items():
        if f_ir.is_time_dimension and getattr(f_ir, "is_default", False):
            defaults_by_entity[f_ir.entity].append(f_id)

    for entity_id, field_ids in defaults_by_entity.items():
        if len(field_ids) > 1:
            errors.append(
                SemanticLoadError(
                    kind=ErrorKind.DUPLICATE_DEFAULT_TIME_DIMENSION,
                    message=(
                        f"Entity {entity_id!r} has {len(field_ids)} time dimensions "
                        f"with is_default=True: {field_ids}. At most one is allowed."
                    ),
                    refs=tuple(field_ids),
                    constraint_id=ConstraintId.TIME_DIMENSION_DEFAULT_UNIQUE,
                    details={
                        "entity": entity_id,
                        "default_time_dimensions": field_ids,
                    },
                )
            )


def _filtered_domain_ref_warning(
    obj_id: str,
    ref: str,
    ref_kind: str,
) -> StructuredWarning:
    """Build a warning for a cross-object ref to a filtered-out domain."""
    ref_domain = ref.split(".", 1)[0]
    return StructuredWarning(
        kind="filtered_domain_ref",
        message=f"{ref_kind} {obj_id!r} references {ref!r} from filtered-out domain {ref_domain!r}.",
        refs=(obj_id, ref),
        location=None,
    )


def _validate_sampled_time_folds(registry: Registry, errors: list[SemanticError]) -> None:
    from marivo.semantic._metric_resolution import resolve_metric_temporal_contract
    from marivo.semantic.ir import DimensionKind

    for metric_id, metric_ir in registry.metrics.items():
        temporal_contract = resolve_metric_temporal_contract(metric_ir, registry)
        if metric_ir.fold_override is not None and temporal_contract is None:
            target_id = metric_ir.aggregation_target or metric_ir.measure
            target = registry.measures.get(target_id) if target_id is not None else None
            if target is not None and target_id is not None:
                errors.append(
                    SemanticLoadError(
                        kind=ErrorKind.TIME_FOLD_REQUIRES_SEMI_ADDITIVE,
                        message=(
                            f"Metric {metric_id!r} declares a fold override for measure "
                            f"{target_id!r}, but that measure is not semi-additive."
                        ),
                        refs=(metric_id, target_id),
                        constraint_id=ConstraintId.TIME_FOLD_SEMI_ADDITIVE,
                        expected="a semi-additive measure with a governed status-time axis",
                        received=f"measure additivity {target.additivity!r}",
                        hint=(
                            "Remove fold= or model the measure with "
                            "ms.semi_additive(over=<time_dimension>, fold=<fold>)."
                        ),
                        details={
                            "metric": metric_id,
                            "measure": target_id,
                            "measure_additivity": additivity_bucket(target.additivity),
                        },
                    )
                )
            continue
        if temporal_contract is None:
            continue
        field = registry.dimensions.get(temporal_contract.status_time_dimension)
        if field is None or field.kind is not DimensionKind.TIME:
            errors.append(
                SemanticLoadError(
                    kind=ErrorKind.INVALID_STATUS_TIME_DIMENSION,
                    message=(
                        f"Metric {metric_id!r} has a temporal fold over "
                        f"{temporal_contract.status_time_dimension!r}, "
                        "which is not a declared time dimension."
                    ),
                    refs=(metric_id, temporal_contract.status_time_dimension),
                    constraint_id=ConstraintId.STATUS_TIME_DIMENSION_INVALID,
                    details={
                        "metric": metric_id,
                        "over": temporal_contract.status_time_dimension,
                    },
                )
            )


def _time_dimensions_for_entity(entity_id: str, registry: Registry) -> list[DimensionIR]:
    """Return time dimensions on *entity_id*, sorted by semantic_id."""
    return sorted(
        (
            dim
            for dim in registry.dimensions.values()
            if dim.entity == entity_id and dim.kind == DimensionKind.TIME
        ),
        key=lambda dim: dim.semantic_id,
    )


def _validate_cumulative_metric(
    *,
    metric_id: str,
    metric_ir: MetricIR,
    registry: Registry,
) -> list[SemanticError]:
    """Validate a cumulative metric's base, aggregation, and over axis."""
    comp = metric_ir.composition
    if not isinstance(comp, CumulativeComposition):
        return []
    errors: list[SemanticError] = []
    base = registry.metrics.get(comp.base)
    if base is None:
        return errors
    if base.metric_type == "derived":
        errors.append(
            SemanticLoadError(
                kind=ErrorKind.INVALID_COMPOSITION,
                message=(
                    f"Metric {metric_id!r} cumulative base {comp.base!r} is derived; "
                    "cumulative base must be a tier-1 simple aggregate."
                ),
                refs=(metric_id, comp.base),
                constraint_id=ConstraintId.COMPOSITION_SHAPE,
                hint=(
                    "Compose in the other direction, for example a ratio of two cumulative "
                    "metrics. Compare is supported only when every outer component uses the "
                    "same trailing or grain_to_date anchor; all_history remains observe-only."
                ),
                details={
                    "metric": metric_id,
                    "base": comp.base,
                    "composition": "cumulative",
                },
            )
        )
        return errors
    if base.aggregation is None and base.weighted_mean is None:
        errors.append(
            SemanticLoadError(
                kind=ErrorKind.INVALID_COMPOSITION,
                message=(
                    f"Metric {metric_id!r} cumulative base {comp.base!r} is a tier-2 "
                    "body metric; cumulative base must be a tier-1 simple aggregate."
                ),
                refs=(metric_id, comp.base),
                constraint_id=ConstraintId.COMPOSITION_SHAPE,
                hint=(
                    "Use ms.aggregate(...) or ms.count(...) for the base metric so "
                    "Marivo can rewrite baseline and first-seen queries."
                ),
                details={
                    "metric": metric_id,
                    "base": comp.base,
                    "composition": "cumulative",
                },
            )
        )
        return errors
    agg = "weighted_mean" if base.weighted_mean is not None else base.aggregation
    agg_name = agg[0] if isinstance(agg, tuple) else agg
    if agg_name not in {"sum", "count", "count_distinct", "weighted_mean"}:
        errors.append(
            SemanticLoadError(
                kind=ErrorKind.INVALID_COMPOSITION,
                message=(
                    f"Metric {metric_id!r} cumulative base {comp.base!r} uses "
                    f"unsupported aggregation {agg_name!r}; cumulative base must "
                    "use sum, count, count_distinct, or weighted_mean."
                ),
                refs=(metric_id, comp.base),
                constraint_id=ConstraintId.COMPOSITION_SHAPE,
                hint=(
                    "For means, model cumulative sum over cumulative count and "
                    "compose the rate as ms.ratio(...)."
                ),
                details={
                    "metric": metric_id,
                    "base": comp.base,
                    "aggregation": agg_name,
                    "composition": "cumulative",
                },
            )
        )
    if comp.over is None:
        candidates = _time_dimensions_for_entity(base.root_entity or "", registry)
        candidate_ids = [dim.semantic_id for dim in candidates]
        default_candidates = [dim.semantic_id for dim in candidates if dim.is_default]
        default_label = (
            f" (default: {', '.join(default_candidates)})"
            if default_candidates
            else " (no default time dimension declared)"
        )
        errors.append(
            SemanticLoadError(
                kind=ErrorKind.INVALID_COMPOSITION,
                message=(
                    f"Metric {metric_id!r} omits over= but base root entity "
                    f"{base.root_entity!r} has {len(candidates)} time dimensions: "
                    f"{', '.join(candidate_ids)}{default_label}; "
                    "pass over=<Ref[time_dimension]> explicitly."
                ),
                refs=(metric_id, comp.base),
                constraint_id=ConstraintId.COMPOSITION_SHAPE,
                hint=(
                    "Entity defaults do not silently choose the business "
                    "accumulation axis. Pass over=<Ref[time_dimension]> explicitly."
                ),
                details={
                    "metric": metric_id,
                    "base": comp.base,
                    "candidates": candidate_ids,
                    "default_candidates": default_candidates,
                    "composition": "cumulative",
                },
            )
        )
    elif (
        comp.over not in registry.dimensions or not registry.dimensions[comp.over].is_time_dimension
    ):
        errors.append(
            SemanticLoadError(
                kind=ErrorKind.MISSING_DIMENSION_REF,
                message=(
                    f"Metric {metric_id!r} cumulative over={comp.over!r} is not a "
                    "known time dimension."
                ),
                refs=(metric_id, comp.over),
                constraint_id=ConstraintId.COMPOSITION_SHAPE,
                details={
                    "metric": metric_id,
                    "over": comp.over,
                    "missing_ref": comp.over,
                    "did_you_mean": did_you_mean(comp.over, sorted(registry.dimensions.keys())),
                    "composition": "cumulative",
                },
            )
        )
    elif base.root_entity is not None and registry.dimensions[comp.over].entity != base.root_entity:
        errors.append(
            SemanticLoadError(
                kind=ErrorKind.INVALID_COMPOSITION,
                message=(
                    f"Metric {metric_id!r} cumulative over={comp.over!r} belongs to "
                    f"{registry.dimensions[comp.over].entity!r}, not base root entity "
                    f"{base.root_entity!r}."
                ),
                refs=(metric_id, comp.over),
                constraint_id=ConstraintId.COMPOSITION_SHAPE,
                hint="Choose the time dimension on the base metric root entity.",
                details={
                    "metric": metric_id,
                    "over": comp.over,
                    "root_entity": base.root_entity,
                    "composition": "cumulative",
                },
            )
        )
    return errors


_PROJECTED_ALIAS_DISPLAY_LIMIT = 8


def _validate_projected_source_aliases(
    registry: Registry,
    sidecar: CompiledExpressionSidecar | None,
) -> list[SemanticError]:
    """Validate direct semantic column references against projected aliases."""
    missing_by_entity: dict[str, list[dict[str, object]]] = {}

    def record(
        *, object_id: str, entity: EntityIR, field: str, column: str, location: SourceLocation
    ) -> None:
        source = entity.source
        if not isinstance(source, TableSourceIR) or not source.columns:
            return
        aliases = {output_name for output_name, _binding in source.columns}
        if column in aliases:
            return
        missing_by_entity.setdefault(entity.semantic_id, []).append(
            {
                "object": object_id,
                "field": field,
                "received_column": column,
                "location": {"file": location.file, "line": location.line},
            }
        )

    for primary_entity in registry.entities.values():
        for column in primary_entity.primary_key:
            record(
                object_id=primary_entity.semantic_id,
                entity=primary_entity,
                field="primary_key",
                column=column,
                location=primary_entity.location,
            )
    for dimension in registry.dimensions.values():
        entity = registry.entities.get(dimension.entity)
        if entity is None or dimension.source_column is None:
            continue
        record(
            object_id=dimension.semantic_id,
            entity=entity,
            field="column",
            column=dimension.source_column,
            location=dimension.location,
        )
    if sidecar is not None:
        for measure in registry.measures.values():
            entity = registry.entities.get(measure.entity)
            body = sidecar.bodies.get(ref_factory.measure(measure.semantic_id))
            if entity is None or body is None or body.source_column is None:
                continue
            record(
                object_id=measure.semantic_id,
                entity=entity,
                field="column",
                column=body.source_column,
                location=measure.location,
            )

    errors: list[SemanticError] = []
    for entity_id, missing in missing_by_entity.items():
        entity = registry.entities[entity_id]
        source = entity.source
        if not isinstance(source, TableSourceIR):
            continue
        aliases = tuple(output_name for output_name, _binding in source.columns)
        visible_missing = missing[:_PROJECTED_ALIAS_DISPLAY_LIMIT]
        rendered_missing = ", ".join(
            f"{item['object']}.{item['field']}={item['received_column']!r}"
            for item in visible_missing
        )
        omitted_missing = len(missing) - len(visible_missing)
        if omitted_missing:
            rendered_missing += f", ... (+{omitted_missing} more)"
        refs = tuple(dict.fromkeys((entity_id, *(str(item["object"]) for item in missing))))
        errors.append(
            SemanticLoadError(
                kind=ErrorKind.INVALID_REF,
                message=(
                    f"Projected entity {entity_id!r} is missing output aliases required by "
                    f"semantic references: {rendered_missing}."
                ),
                refs=refs,
                location=entity.location,
                constraint_id=ConstraintId.REF_SHAPE,
                expected="stable output aliases declared by md.table(columns=...)",
                received=", ".join(str(item["received_column"]) for item in visible_missing),
                hint=(
                    "Add every missing md.source_column(...) binding to the entity's "
                    "md.table(columns=...), or change each semantic column= to an exposed alias."
                ),
                details={
                    "entity": entity_id,
                    "missing_references": missing,
                    "omitted_missing_reference_count": omitted_missing,
                    "available_output_aliases": list(aliases),
                },
            )
        )
    return errors


def assembly_validate(
    registry: Registry,
    sidecar: CompiledExpressionSidecar | None = None,
    *,
    loaded_models: set[str] | None = None,
) -> tuple[list[SemanticError], list[StructuredWarning]]:
    """Layer 3: assembly-time cross-object validation.

    Returns (errors, warnings).  Does not raise.

    When *loaded_models* is provided, cross-object references to objects
    in models that were intentionally not loaded produce
    ``filtered_domain_ref`` warnings instead of errors, so the registry
    remains usable.
    """
    errors: list[SemanticError] = []
    warnings: list[StructuredWarning] = []

    errors.extend(_validate_projected_source_aliases(registry, sidecar))

    # -- Validate datasource refs on entities --------------------------------
    for ds_id, ds_ir in registry.entities.items():
        if ds_ir.datasource not in registry.datasources:
            errors.append(
                SemanticLoadError(
                    kind=ErrorKind.MISSING_ENTITY_REF,
                    message=f"Entity {ds_id!r} references unknown datasource {ds_ir.datasource!r}.",
                    refs=(ds_id, ds_ir.datasource),
                    details={
                        "missing_ref": ds_ir.datasource,
                        "did_you_mean": did_you_mean(
                            ds_ir.datasource, sorted(registry.datasources.keys())
                        ),
                    },
                )
            )
        # Warn on string datasource ref
        # (String refs are the norm currently, so skip warning for now.
        #  This will become meaningful when typed refs are more common.)

        versioning = ds_ir.versioning
        if versioning is not None:
            if isinstance(versioning, SnapshotVersioningIR):
                _validate_snapshot_versioning(errors, ds_id, ds_ir, versioning)
            elif isinstance(versioning, ValidityVersioningIR):
                _validate_validity_versioning(errors, ds_id, ds_ir, versioning, registry)

    # -- Validate entity refs on dimensions ----------------------------------
    for f_id, f_ir in registry.dimensions.items():
        if f_ir.entity not in registry.entities:
            if _is_filtered_domain_ref(f_ir.entity, loaded_models):
                warnings.append(_filtered_domain_ref_warning(f_id, f_ir.entity, "Dimension"))
            else:
                errors.append(
                    SemanticLoadError(
                        kind=ErrorKind.MISSING_ENTITY_REF,
                        message=f"Dimension {f_id!r} references unknown entity {f_ir.entity!r}.",
                        refs=(f_id, f_ir.entity),
                        details={
                            "missing_ref": f_ir.entity,
                            "did_you_mean": did_you_mean(
                                f_ir.entity, sorted(registry.entities.keys())
                            ),
                        },
                    )
                )

    # -- Validate measure entity refs -----------------------------------------
    # -- Validate period-calendar source-field ownership --------------------
    for calendar_id, calendar in registry.period_calendars.items():
        date_field = registry.dimensions.get(calendar.date)
        if (
            date_field is None
            or not date_field.is_time_dimension
            or date_field.granularity != "day"
        ):
            errors.append(
                SemanticLoadError(
                    kind=ErrorKind.INVALID_REF,
                    message=(
                        f"Period calendar {calendar_id!r} date ref {calendar.date!r} must "
                        "resolve to a day-grain time dimension."
                    ),
                    refs=(calendar_id, calendar.date),
                )
            )
            continue
        for level, level_ref in calendar.levels:
            field = registry.dimensions.get(level_ref)
            if field is None or field.is_time_dimension or field.entity != date_field.entity:
                errors.append(
                    SemanticLoadError(
                        kind=ErrorKind.INVALID_REF,
                        message=(
                            f"Period calendar {calendar_id!r} level {level!r} must reference "
                            "a categorical dimension on the calendar date entity."
                        ),
                        refs=(calendar_id, level_ref),
                    )
                )
        for correspondence_name, level, baseline_ref in calendar.correspondences:
            baseline = registry.dimensions.get(baseline_ref)
            if level not in {name for name, _field in calendar.levels}:
                errors.append(
                    SemanticLoadError(
                        kind=ErrorKind.INVALID_REF,
                        message=(
                            f"Period calendar {calendar_id!r} correspondence {correspondence_name!r} "
                            f"names undeclared level {level!r}."
                        ),
                        refs=(calendar_id, baseline_ref),
                    )
                )
            elif (
                baseline is None
                or baseline.is_time_dimension
                or baseline.entity != date_field.entity
            ):
                errors.append(
                    SemanticLoadError(
                        kind=ErrorKind.INVALID_REF,
                        message=(
                            f"Period calendar {calendar_id!r} correspondence {correspondence_name!r} "
                            "must reference a categorical dimension on the calendar date entity."
                        ),
                        refs=(calendar_id, baseline_ref),
                    )
                )

    # -- Validate temporal-set source-field ownership -----------------------
    for set_id, temporal_set in registry.temporal_sets.items():
        occurrence = registry.dimensions.get(temporal_set.occurrence_id)
        start_field = registry.dimensions.get(temporal_set.start)
        end_field = registry.dimensions.get(temporal_set.end)
        category_field = (
            registry.dimensions.get(temporal_set.category)
            if temporal_set.category is not None
            else None
        )
        if (
            occurrence is None
            or occurrence.is_time_dimension
            or occurrence.entity != getattr(start_field, "entity", None)
            or occurrence.entity != getattr(end_field, "entity", None)
            or (temporal_set.category is not None and category_field is None)
            or (
                category_field is not None
                and (category_field.is_time_dimension or category_field.entity != occurrence.entity)
            )
        ):
            errors.append(
                SemanticLoadError(
                    kind=ErrorKind.INVALID_REF,
                    message=(
                        f"Temporal set {set_id!r} occurrence_id, start, end, and category "
                        "must be fields on one source entity, with occurrence_id/category categorical."
                    ),
                    refs=tuple(
                        ref
                        for ref in (
                            set_id,
                            temporal_set.occurrence_id,
                            temporal_set.start,
                            temporal_set.end,
                            temporal_set.category,
                        )
                        if isinstance(ref, str)
                    ),
                )
            )

        for label, field in (("start", start_field), ("end", end_field)):
            if field is None or not field.is_time_dimension:
                errors.append(
                    SemanticLoadError(
                        kind=ErrorKind.INVALID_REF,
                        message=(
                            f"Temporal set {set_id!r} {label} ref must resolve to a time dimension."
                        ),
                        refs=(set_id, getattr(temporal_set, label)),
                    )
                )
        start_encoding = _temporal_set_encoding(start_field)
        end_encoding = _temporal_set_encoding(end_field)
        if (
            start_encoding is not None
            and end_encoding is not None
            and start_encoding != end_encoding
        ):
            errors.append(
                SemanticLoadError(
                    kind=ErrorKind.INVALID_REF,
                    message=(
                        f"Temporal set {set_id!r} start and end time dimensions must "
                        "use the same civil-date or timestamp encoding."
                    ),
                    refs=(set_id, temporal_set.start, temporal_set.end),
                    expected="matching date/date or timestamp/timestamp time encodings",
                    received=f"start={start_encoding}, end={end_encoding}",
                )
            )

    # -- Validate work-schedule source-field ownership ----------------------
    for schedule_id, schedule in registry.work_schedules.items():
        date_field = registry.dimensions.get(schedule.date)
        working_field = registry.dimensions.get(schedule.is_working)
        valid_date = (
            date_field is not None
            and date_field.is_time_dimension
            and date_field.granularity == "day"
            and _temporal_set_encoding(date_field) in {None, "date"}
        )
        valid_working = (
            working_field is not None
            and not working_field.is_time_dimension
            and working_field.entity == getattr(date_field, "entity", None)
        )
        if not valid_date or not valid_working:
            errors.append(
                SemanticLoadError(
                    kind=ErrorKind.INVALID_REF,
                    message=(
                        f"Work schedule {schedule_id!r} date must be a day-grain civil-date "
                        "time dimension and is_working must be a categorical field on the same entity."
                    ),
                    refs=(schedule_id, schedule.date, schedule.is_working),
                )
            )

    # -- Validate measure entity refs -----------------------------------------
    errors.extend(_validate_measure_refs(registry))

    # -- Validate Event sources, fields, and directed participant paths -------
    for event_id, event_ir in registry.events.items():
        source = registry.entities.get(event_ir.source_entity)
        if source is None:
            errors.append(
                SemanticLoadError(
                    kind=ErrorKind.INVALID_EVENT_SOURCE,
                    message=f"Event {event_id!r} has unknown source Entity.",
                    refs=(event_id, event_ir.source_entity),
                    expected="owner(occurred_at) present in the compiled catalog",
                    received=event_ir.source_entity,
                )
            )
            continue
        occurred = registry.dimensions.get(event_ir.occurred_at)
        if (
            occurred is None
            or not occurred.is_time_dimension
            or occurred.entity != event_ir.source_entity
        ):
            errors.append(
                SemanticLoadError(
                    kind=ErrorKind.INVALID_EVENT_TIME,
                    message=f"Event {event_id!r} occurred_at is not a source-owned time Dimension.",
                    refs=(event_id, event_ir.occurred_at),
                    expected=f"Ref[time_dimension] owned by {event_ir.source_entity}",
                    received=event_ir.occurred_at,
                )
            )
        for identity_ref in event_ir.identity:
            dimension = registry.dimensions.get(identity_ref)
            if (
                dimension is None
                or dimension.is_time_dimension
                or dimension.entity != event_ir.source_entity
            ):
                errors.append(
                    SemanticLoadError(
                        kind=ErrorKind.INVALID_EVENT_IDENTITY,
                        message=(
                            f"Event {event_id!r} identity component is not a "
                            "source-owned categorical Dimension."
                        ),
                        refs=(event_id, identity_ref),
                        expected=f"Ref[dimension] owned by {event_ir.source_entity}",
                        received=identity_ref,
                    )
                )
        for participant in event_ir.participants:
            endpoint = event_ir.source_entity
            for relationship_id in participant.path or ():
                relationship = registry.relationships.get(relationship_id)
                if relationship is None or relationship.from_entity != endpoint:
                    errors.append(
                        SemanticLoadError(
                            kind=ErrorKind.INVALID_EVENT_PARTICIPANT_PATH,
                            message=(
                                f"Event {event_id!r} participant {participant.name!r} "
                                "path is missing or not directed from its current endpoint."
                            ),
                            refs=(event_id, relationship_id),
                            expected=f"Relationship from {endpoint}",
                            received=(
                                "missing"
                                if relationship is None
                                else f"{relationship.from_entity} -> {relationship.to_entity}"
                            ),
                        )
                    )
                    endpoint = ""
                    break
                endpoint = relationship.to_entity
            endpoint_entity = registry.entities.get(endpoint)
            if (
                endpoint_entity is not None
                and participant.cardinality == "one"
                and not endpoint_entity.primary_key
            ):
                errors.append(
                    SemanticLoadError(
                        kind=ErrorKind.INVALID_EVENT_PARTICIPANT_CARDINALITY,
                        message=(
                            f"Event {event_id!r} cardinality-one participant "
                            f"{participant.name!r} ends at Entity {endpoint!r} without a primary key."
                        ),
                        refs=(event_id, endpoint),
                        expected="a non-empty endpoint Entity primary_key",
                        received="empty primary_key",
                    )
                )
            if endpoint_entity is not None and endpoint_entity.datasource != source.datasource:
                errors.append(
                    SemanticLoadError(
                        kind=ErrorKind.INVALID_EVENT_PARTICIPANT_PATH,
                        message=(
                            f"Event {event_id!r} participant {participant.name!r} "
                            "crosses datasource execution domains."
                        ),
                        refs=(event_id, event_ir.source_entity, endpoint),
                        expected=f"datasource {source.datasource}",
                        received=endpoint_entity.datasource,
                    )
                )

    if sidecar is not None:
        errors.extend(_validate_expression_bindings(registry, sidecar))

    # -- Validate entity refs on metrics -------------------------------------
    for m_id, m_ir in registry.metrics.items():
        for ds_ref in m_ir.entities:
            if ds_ref not in registry.entities:
                if _is_filtered_domain_ref(ds_ref, loaded_models):
                    warnings.append(_filtered_domain_ref_warning(m_id, ds_ref, "Metric"))
                else:
                    errors.append(
                        SemanticLoadError(
                            kind=ErrorKind.MISSING_ENTITY_REF,
                            message=f"Metric {m_id!r} references unknown entity {ds_ref!r}.",
                            refs=(m_id, ds_ref),
                            details={
                                "missing_ref": ds_ref,
                                "did_you_mean": did_you_mean(
                                    ds_ref, sorted(registry.entities.keys())
                                ),
                            },
                        )
                    )

    # -- Validate tier-1 filter dimensions -----------------------------------
    for metric_id, metric_ir in registry.metrics.items():
        if not metric_ir.filter:
            continue
        root_entity = metric_ir.root_entity
        if root_entity is None:
            errors.append(
                SemanticLoadError(
                    kind=ErrorKind.INVALID_FILTER,
                    message=(f"Metric {metric_id!r} has a filter but no resolved root entity."),
                    refs=(metric_id,),
                    constraint_id=ConstraintId.FILTER_CONDITION_VALID,
                    expected="a filtered tier-1 metric with one target entity",
                    received="root_entity=None",
                )
            )
            continue
        entity_dimensions = {
            dimension.name: dimension
            for dimension in registry.dimensions.values()
            if dimension.entity == root_entity
        }
        for dimension_name, _value in metric_ir.filter:
            dimension = entity_dimensions.get(dimension_name)
            if dimension is None:
                filter_candidates = tuple(did_you_mean(dimension_name, sorted(entity_dimensions)))
                errors.append(
                    SemanticLoadError(
                        kind=ErrorKind.INVALID_FILTER,
                        message=(
                            f"Metric {metric_id!r} filter dimension {dimension_name!r} "
                            f"is not declared on target entity {root_entity!r}."
                        ),
                        refs=(metric_id, root_entity),
                        constraint_id=ConstraintId.FILTER_CONDITION_VALID,
                        expected=(
                            "a local semantic dimension declared on the metric target entity"
                        ),
                        received=dimension_name,
                        details={
                            "metric": metric_id,
                            "target_entity": root_entity,
                            "filter_dimension": dimension_name,
                            "did_you_mean": filter_candidates,
                        },
                    )
                )
                continue
            if dimension.entity != root_entity:
                errors.append(
                    SemanticLoadError(
                        kind=ErrorKind.INVALID_FILTER,
                        message=(
                            f"Metric {metric_id!r} filter dimension {dimension.semantic_id!r} "
                            f"belongs to entity {dimension.entity!r}, not {root_entity!r}."
                        ),
                        refs=(metric_id, dimension.semantic_id),
                        constraint_id=ConstraintId.FILTER_CONDITION_VALID,
                        expected=f"dimension on entity {root_entity}",
                        received=f"dimension on entity {dimension.entity}",
                    )
                )

    # -- Validate metric additivity + tier-1 measure resolution --------------
    from marivo.semantic.ir import additivity_bucket as _bucket

    for m_id, m_ir in registry.metrics.items():
        if m_ir.metric_type == "derived":
            continue
        if m_ir.additivity is None:
            # Resolution failed: diagnose the tier-1 cause precisely.
            if m_ir.weighted_mean is not None:
                value_id = m_ir.weighted_mean.value
                weight_id = m_ir.weighted_mean.weight
                value = registry.measures.get(value_id)
                weight = registry.measures.get(weight_id)
                missing = value_id if value is None else weight_id if weight is None else None
                if missing is not None:
                    errors.append(
                        SemanticLoadError(
                            kind=ErrorKind.UNKNOWN_MEASURE,
                            message=(
                                f"Metric {m_id!r} references unknown weighted-mean measure "
                                f"{missing!r}."
                            ),
                            refs=(m_id, missing),
                            details={
                                "metric": m_id,
                                "measure": missing,
                                "did_you_mean": did_you_mean(
                                    missing, sorted(registry.measures.keys())
                                ),
                            },
                        )
                    )
                    continue
                assert value is not None and weight is not None
                if value.entity != weight.entity:
                    errors.append(
                        SemanticLoadError(
                            kind=ErrorKind.INVALID_MEASURE_AGGREGATION,
                            message=(
                                f"Metric {m_id!r} weighted_mean value {value_id!r} and "
                                f"weight {weight_id!r} must belong to the same entity; got "
                                f"{value.entity!r} and {weight.entity!r}."
                            ),
                            refs=(m_id, value_id, weight_id),
                            constraint_id=ConstraintId.MEASURE_AGGREGATION_VALID,
                            details={
                                "metric": m_id,
                                "value": value_id,
                                "weight": weight_id,
                                "value_entity": value.entity,
                                "weight_entity": weight.entity,
                            },
                        )
                    )
                elif weight.additivity != "additive":
                    errors.append(
                        SemanticLoadError(
                            kind=ErrorKind.INVALID_MEASURE_AGGREGATION,
                            message=(
                                f"Metric {m_id!r} weighted_mean weight {weight_id!r} must "
                                f"be additive; got {weight.additivity!r}."
                            ),
                            refs=(m_id, weight_id),
                            constraint_id=ConstraintId.MEASURE_AGGREGATION_VALID,
                            details={
                                "metric": m_id,
                                "weight": weight_id,
                                "additivity": weight.additivity,
                            },
                        )
                    )
                continue
            if m_ir.aggregation is not None:
                target_kind = m_ir.aggregation_target_kind or (
                    "measure" if m_ir.measure is not None else None
                )
                target_id = m_ir.aggregation_target or m_ir.measure or ""
                agg = m_ir.aggregation
                if target_kind == "entity":
                    if target_id not in registry.entities:
                        errors.append(
                            SemanticLoadError(
                                kind=ErrorKind.ENTITY_NOT_FOUND,
                                message=(
                                    f"Metric {m_id!r} references unknown entity {target_id!r}."
                                ),
                                refs=(m_id, target_id),
                                details={
                                    "metric": m_id,
                                    "entity": target_id,
                                    "did_you_mean": did_you_mean(
                                        target_id, sorted(registry.entities.keys())
                                    ),
                                },
                            )
                        )
                    else:
                        errors.append(
                            SemanticLoadError(
                                kind=ErrorKind.INVALID_MEASURE_AGGREGATION,
                                message=(
                                    f"Metric {m_id!r} applies {agg!r} to entity "
                                    f"{target_id!r}; entity counts must use 'count'."
                                ),
                                refs=(m_id, target_id),
                                details={"metric": m_id, "entity": target_id, "aggregation": agg},
                            )
                        )
                    continue
                measure: MeasureIR | DimensionIR | None = registry.measures.get(target_id)
                if measure is None:
                    measure = registry.dimensions.get(target_id)
                if measure is None:
                    errors.append(
                        SemanticLoadError(
                            kind=ErrorKind.UNKNOWN_MEASURE,
                            message=f"Metric {m_id!r} references unknown measure {target_id!r}.",
                            refs=(m_id, target_id),
                            details={
                                "metric": m_id,
                                "measure": target_id,
                                "did_you_mean": did_you_mean(
                                    target_id,
                                    sorted(
                                        set(registry.dimensions.keys())
                                        | set(registry.measures.keys())
                                    ),
                                ),
                            },
                        )
                    )
                elif getattr(measure, "additivity", None) is None:
                    errors.append(
                        SemanticLoadError(
                            kind=ErrorKind.MISSING_MEASURE_ADDITIVITY,
                            message=f"Measure {target_id!r} used by {m_id!r} must declare additivity.",
                            refs=(m_id, target_id),
                            constraint_id=ConstraintId.MEASURE_ADDITIVITY_REQUIRED,
                            details={"metric": m_id, "measure": target_id},
                        )
                    )
                else:
                    errors.append(
                        SemanticLoadError(
                            kind=ErrorKind.INVALID_MEASURE_AGGREGATION,
                            message=(
                                f"Metric {m_id!r} applies {agg!r} to non-additive measure "
                                f"{target_id!r}; use mean/min/max or a ratio."
                            ),
                            refs=(m_id, target_id),
                            constraint_id=ConstraintId.MEASURE_AGGREGATION_VALID,
                            details={"metric": m_id, "measure": target_id, "aggregation": agg},
                        )
                    )
            else:
                errors.append(
                    SemanticLoadError(
                        kind=ErrorKind.MISSING_METRIC_ADDITIVITY,
                        message=f"Simple metric {m_id!r} must declare additivity.",
                        refs=(m_id,),
                        constraint_id=ConstraintId.METRIC_ADDITIVITY_REQUIRED,
                        details={"metric": m_id},
                    )
                )
            continue
        if len(m_ir.entities) == 0:
            continue
        if len(m_ir.entities) == 1 and m_ir.root_entity is None:
            continue
        if len(m_ir.entities) > 1 and m_ir.root_entity is None:
            errors.append(
                SemanticLoadError(
                    kind=ErrorKind.MISSING_METRIC_ROOT_ENTITY,
                    message=f"Multi-entity base metric {m_id!r} must declare root_entity.",
                    refs=(m_id,),
                    details={"metric": m_id, "entities": sorted(m_ir.entities)},
                )
            )
            continue
        if m_ir.root_entity is not None and m_ir.root_entity not in m_ir.entities:
            errors.append(
                SemanticLoadError(
                    kind=ErrorKind.INVALID_METRIC_ROOT_ENTITY,
                    message=(
                        f"Metric {m_id!r} root_entity {m_ir.root_entity!r} "
                        "must be one of its entities."
                    ),
                    refs=(m_id, m_ir.root_entity),
                    details={
                        "metric": m_id,
                        "root_entity": m_ir.root_entity,
                        "entities": sorted(m_ir.entities),
                    },
                )
            )

    # -- Validate metric fanout_policy --------------------------------------
    for m_id, m_ir in registry.metrics.items():
        policy = getattr(m_ir, "fanout_policy", "block")
        if policy not in {"block", "aggregate_then_join"}:
            errors.append(
                SemanticLoadError(
                    kind=ErrorKind.INVALID_METRIC_FANOUT_POLICY,
                    message=(
                        f"Metric {m_id!r} fanout_policy {policy!r} must be "
                        "'block' or 'aggregate_then_join'."
                    ),
                    refs=(m_id,),
                    details={"metric": m_id, "fanout_policy": policy},
                )
            )
            continue
        if m_ir.metric_type == "derived" and policy != "block":
            errors.append(
                SemanticLoadError(
                    kind=ErrorKind.DERIVED_METRIC_FANOUT_POLICY,
                    message=(
                        f"Derived metric {m_id!r} must keep fanout_policy='block'; "
                        "fan-out is authored on the component metrics."
                    ),
                    refs=(m_id,),
                    details={"metric": m_id, "fanout_policy": policy},
                )
            )
            continue
        if (
            policy == "aggregate_then_join"
            and m_ir.metric_type != "derived"
            and m_ir.additivity is not None
            and _bucket(m_ir.additivity) not in {"additive", "semi_additive"}
        ):
            errors.append(
                SemanticLoadError(
                    kind=ErrorKind.INVALID_METRIC_FANOUT_POLICY,
                    message=(
                        f"Metric {m_id!r} fanout_policy='aggregate_then_join' "
                        "requires additivity in {'additive', 'semi_additive'}."
                    ),
                    refs=(m_id,),
                    details={
                        "metric": m_id,
                        "fanout_policy": policy,
                        "additivity": m_ir.additivity,
                    },
                )
            )

    # -- Validate root-only aggregates for multi-entity base metrics ----------
    for m_id, m_ir in registry.metrics.items():
        if (
            m_ir.metric_type != "simple"
            or m_ir.aggregation is not None
            or m_ir.weighted_mean is not None
        ):
            continue
        if sidecar is not None and len(m_ir.entities) > 1 and m_ir.root_entity is not None:
            body = sidecar.bodies.get(ref_factory.metric(m_id))
            fn = None if body is None else body.callable
            if callable(fn):
                offending_entity = _non_root_aggregate_entity(fn, metric_ir=m_ir)
                if offending_entity is not None:
                    errors.append(
                        SemanticLoadError(
                            kind=ErrorKind.NON_ROOT_METRIC_AGGREGATE,
                            message=(
                                f"Metric {m_id!r} aggregates a non-root entity "
                                f"{offending_entity!r}."
                            ),
                            refs=(m_id, offending_entity),
                            details={
                                "metric": m_id,
                                "root_entity": m_ir.root_entity,
                                "offending_entity": offending_entity,
                            },
                        )
                    )

    # -- Validate sampled semi-additive time folds ---------------------------
    _validate_sampled_time_folds(registry, errors)

    # -- Validate metric component refs in composition --------------------
    for m_id, m_ir in registry.metrics.items():
        if m_ir.composition is None:
            continue
        for comp_key, comp_ref in composition_components(m_ir.composition).items():
            if comp_ref not in registry.metrics:
                if _is_filtered_domain_ref(comp_ref, loaded_models):
                    warnings.append(
                        _filtered_domain_ref_warning(m_id, comp_ref, "Metric component")
                    )
                else:
                    errors.append(
                        SemanticLoadError(
                            kind=ErrorKind.MISSING_METRIC_REF,
                            message=f"Metric {m_id!r} composition component "
                            f"{comp_key!r} references unknown metric "
                            f"{comp_ref!r}.",
                            refs=(m_id, comp_ref),
                            details={
                                "missing_ref": comp_ref,
                                "did_you_mean": did_you_mean(
                                    comp_ref, sorted(registry.metrics.keys())
                                ),
                            },
                        )
                    )
        errors.extend(
            _validate_cumulative_metric(
                metric_id=m_id,
                metric_ir=m_ir,
                registry=registry,
            )
        )

        if isinstance(m_ir.composition, LinearComposition):
            from marivo.semantic.unit_algebra import linear_units_conflict

            term_units = [
                registry.metrics[t.metric].unit
                for t in m_ir.composition.terms
                if t.metric in registry.metrics
            ]
            if linear_units_conflict(term_units):
                errors.append(
                    SemanticLoadError(
                        kind=ErrorKind.INCOMMENSURABLE_LINEAR_UNITS,
                        message=(
                            f"Metric {m_id!r} adds incommensurable units "
                            f"{sorted(u for u in term_units if u is not None)!r}; "
                            "linear terms must share one unit."
                        ),
                        refs=(m_id,),
                        constraint_id=ConstraintId.LINEAR_UNIT_COMMENSURABLE,
                        details={
                            "metric": m_id,
                            "units": {
                                t.metric: registry.metrics[t.metric].unit
                                for t in m_ir.composition.terms
                                if t.metric in registry.metrics
                            },
                        },
                    )
                )

    # -- Validate dimension refs in relationships -----------------------------
    for r_id, r_ir in registry.relationships.items():
        if r_ir.from_entity not in registry.entities:
            if _is_filtered_domain_ref(r_ir.from_entity, loaded_models):
                warnings.append(
                    _filtered_domain_ref_warning(r_id, r_ir.from_entity, "Relationship")
                )
            else:
                errors.append(
                    SemanticLoadError(
                        kind=ErrorKind.INVALID_RELATIONSHIP_ENDPOINT,
                        message=f"Relationship {r_id!r} references unknown "
                        f"from_entity {r_ir.from_entity!r}.",
                        refs=(r_id, r_ir.from_entity),
                    )
                )
        if r_ir.to_entity not in registry.entities:
            if _is_filtered_domain_ref(r_ir.to_entity, loaded_models):
                warnings.append(_filtered_domain_ref_warning(r_id, r_ir.to_entity, "Relationship"))
            else:
                errors.append(
                    SemanticLoadError(
                        kind=ErrorKind.INVALID_RELATIONSHIP_ENDPOINT,
                        message=f"Relationship {r_id!r} references unknown "
                        f"to_entity {r_ir.to_entity!r}.",
                        refs=(r_id, r_ir.to_entity),
                    )
                )
        # Validate dimension refs via JoinKey pairs
        for join_key in r_ir.keys:
            ff = join_key.from_key
            if ff not in registry.dimensions:
                if _is_filtered_domain_ref(ff, loaded_models):
                    warnings.append(_filtered_domain_ref_warning(r_id, ff, "Relationship"))
                else:
                    errors.append(
                        SemanticLoadError(
                            kind=ErrorKind.MISSING_DIMENSION_REF,
                            message=f"Relationship {r_id!r} references unknown from_key {ff!r}.",
                            refs=(r_id, ff),
                            details={
                                "missing_ref": ff,
                                "did_you_mean": did_you_mean(
                                    ff, sorted(registry.dimensions.keys())
                                ),
                            },
                        )
                    )
            tf = join_key.to_key
            if tf not in registry.dimensions:
                if _is_filtered_domain_ref(tf, loaded_models):
                    warnings.append(_filtered_domain_ref_warning(r_id, tf, "Relationship"))
                else:
                    errors.append(
                        SemanticLoadError(
                            kind=ErrorKind.MISSING_DIMENSION_REF,
                            message=f"Relationship {r_id!r} references unknown to_key {tf!r}.",
                            refs=(r_id, tf),
                            details={
                                "missing_ref": tf,
                                "did_you_mean": did_you_mean(
                                    tf, sorted(registry.dimensions.keys())
                                ),
                            },
                        )
                    )

    # -- Validate HourPrefixParse prefix cross-reference ---------------------
    for f_id, f_ir in registry.dimensions.items():
        if f_ir.is_time_dimension and isinstance(f_ir.parse, HourPrefixParse):
            prefix_name = f_ir.parse.prefix
            prefix_field = registry.dimensions.get(prefix_name)
            if prefix_field is None:
                candidates = [
                    d
                    for d in registry.dimensions.values()
                    if d.entity == f_ir.entity and d.name == prefix_name
                ]
                prefix_field = candidates[0] if len(candidates) == 1 else None
            if prefix_field is None or not prefix_field.is_time_dimension:
                if _is_filtered_domain_ref(prefix_name, loaded_models):
                    warnings.append(
                        _filtered_domain_ref_warning(f_id, prefix_name, "Time dimension")
                    )
                else:
                    errors.append(
                        SemanticLoadError(
                            kind=ErrorKind.MISSING_DIMENSION_REF,
                            message=f"Time dimension {f_id!r} prefix "
                            f"{prefix_name!r} is not a registered time dimension.",
                            refs=(f_id, prefix_name),
                            details={
                                "missing_ref": prefix_name,
                                "did_you_mean": did_you_mean(
                                    prefix_name, sorted(registry.dimensions.keys())
                                ),
                            },
                        )
                    )

    # -- Validate at most one default time_dimension per entity --------------
    _validate_default_time_dimension_unique(errors, registry)

    # -- Cross-model cycle detection (basic) --------------------------------
    # Check for cycles in metric component references
    _detect_metric_cycles(registry, errors)

    # -- Metric provenance contract ------------------------------------------
    # SqlProvenance carries sql + dialect; verification_mode is always "sql_parity".
    # - Base metrics: SqlProvenance.sql requires a non-empty dialect
    # - Derived metrics: must not carry provenance
    for m_id, m_ir in registry.metrics.items():
        prov = m_ir.provenance
        if m_ir.metric_type == "derived":
            if prov is not None:
                errors.append(
                    SemanticLoadError(
                        kind=ErrorKind.INVALID_VERIFICATION_MODE,
                        message=(
                            f"Derived metric {m_id!r} must omit provenance. "
                            "Verify its component metrics instead."
                        ),
                        refs=(m_id,),
                        location=m_ir.location,
                        constraint_id=ConstraintId.METRIC_VERIFICATION_MODE_VALID,
                    )
                )
            continue

        if prov is not None and not prov.dialect:
            errors.append(
                SemanticLoadError(
                    kind=ErrorKind.PROVENANCE_DIALECT_MISSING,
                    message=(
                        f"Metric {m_id!r} declares provenance SQL but not a dialect. "
                        "Both are required for SQL parity verification."
                    ),
                    refs=(m_id,),
                    location=m_ir.location,
                    constraint_id=ConstraintId.PROVENANCE_DIALECT_REQUIRED,
                )
            )

    # -- Warnings -----------------------------------------------------------
    # String ref warnings: datasource names are intentionally strings in the
    # target API, and cross-file refs are common, so skip string-ref warnings.

    # Partition pushdown advisory warnings
    for f_id, f_ir in registry.dimensions.items():
        field_ref = (
            ref_factory.time_dimension(f_id)
            if f_ir.is_time_dimension
            else ref_factory.dimension(f_id)
        )
        body = None if sidecar is None else sidecar.bodies.get(field_ref)
        if _time_dimension_pushdown_advisory(
            f_ir,
            None if body is None else body.callable,
        ):
            warnings.append(
                StructuredWarning(
                    kind=WarningKind.TIME_DIMENSION_PUSHDOWN_ADVISORY.value,
                    message=(
                        f"Time field {f_id!r} casts or parses a partition-like source column. "
                        "If this is a day/hour partition axis, prefer a raw string/integer "
                        "time_field with date_format so window filters can use simple "
                        "partition comparisons."
                    ),
                    refs=(f_id,),
                    location=f_ir.location,
                )
            )

    # Dtype/data_type mismatch advisory warnings
    for f_id, f_ir in registry.dimensions.items():
        field_ref = (
            ref_factory.time_dimension(f_id)
            if f_ir.is_time_dimension
            else ref_factory.dimension(f_id)
        )
        body = None if sidecar is None else sidecar.bodies.get(field_ref)
        inferred = _time_dimension_dtype_advisory(
            f_ir,
            None if body is None else body.callable,
        )
        if inferred is not None:
            compatible = sorted(_CAST_TARGET_TO_DECLARED.get(inferred, set()))
            parse = f_ir.parse
            declared_data_type: str | None = None
            if parse is None:
                continue  # deferred parse — skip dtype advisory
            elif isinstance(parse, DateParse):
                declared_data_type = "date"
            elif isinstance(parse, DatetimeParse):
                declared_data_type = "datetime"
            elif isinstance(parse, TimestampParse):
                declared_data_type = "timestamp"
            elif isinstance(parse, StrptimeParse):
                declared_data_type = "strptime"
            elif isinstance(parse, HourPrefixParse):
                declared_data_type = "hour_prefix"
            warnings.append(
                StructuredWarning(
                    kind=WarningKind.TIME_DIMENSION_DTYPE_ADVISORY.value,
                    message=(
                        f"Time field {f_id!r} declared data_type={declared_data_type!r} "
                        f"but body .cast({inferred!r}) produces ibis dtype {inferred!r}. "
                        f"Compatible data_type values: {', '.join(compatible)}. "
                        "This mismatch causes TypeError at execution."
                    ),
                    refs=(f_id,),
                    location=f_ir.location,
                )
            )

    return errors, warnings


def _detect_metric_cycles(
    registry: Registry,
    errors: list[SemanticError],
) -> None:
    """Detect circular references in metric composition components."""
    # Build adjacency: metric -> set of metrics it references via components
    adj: dict[str, set[str]] = {}
    for m_id, m_ir in registry.metrics.items():
        deps: set[str] = set()
        if m_ir.composition is not None:
            for comp_ref in composition_components(m_ir.composition).values():
                if comp_ref in registry.metrics:
                    deps.add(comp_ref)
        adj[m_id] = deps

    # DFS-based cycle detection
    unvisited, in_progress, done = 0, 1, 2
    color: dict[str, int] = dict.fromkeys(adj, unvisited)

    def dfs(node: str, path: list[str]) -> bool:
        color[node] = in_progress
        path.append(node)
        for neighbor in adj.get(node, set()):
            if color.get(neighbor) == in_progress:
                # Found a cycle
                cycle_start = path.index(neighbor)
                cycle = [*path[cycle_start:], neighbor]
                errors.append(
                    SemanticLoadError(
                        kind=ErrorKind.CROSS_MODEL_CYCLE,
                        message=f"Circular metric reference detected: {' -> '.join(cycle)}",
                        refs=tuple(cycle),
                    )
                )
                return True
            if color.get(neighbor) == unvisited and dfs(neighbor, path):
                return True
        path.pop()
        color[node] = done
        return False

    for m_id in adj:
        if color[m_id] == unvisited:
            dfs(m_id, [])
