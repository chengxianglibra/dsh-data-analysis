"""Internal semantic resolver backed by Materializer."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any, TypeVar

import ibis
import ibis.expr.types as ir

from marivo.datasource.ir import QueryParamScalar, QueryParamScalarList
from marivo.datasource.source import AuthoringScope
from marivo.refs import (
    EntityKind,
    EventKind,
    FieldKind,
    MeasureKind,
    MetricKind,
    Ref,
    SemanticKind,
    SemanticKindTag,
)
from marivo.semantic.catalog import SemanticCatalog
from marivo.semantic.errors import ErrorKind, SemanticRuntimeError, _raise
from marivo.semantic.ir import AggKind
from marivo.semantic.materializer import Materializer

KindT = TypeVar("KindT", bound=SemanticKindTag)


def _require_kind(
    catalog: SemanticCatalog,
    value: Ref[KindT],
    *,
    expected: tuple[SemanticKind, ...],
) -> str:
    if type(value) is not Ref:
        _raise(
            ErrorKind.INVALID_REF,
            f"Resolver requires an exact Ref; received {type(value).__name__}. "
            "Pass entry.ref or construct ms.ref.<kind>(path).",
            cls=SemanticRuntimeError,
        )
    ref = value
    if ref.kind not in expected:
        expected_text = " or ".join(str(item) for item in expected)
        _raise(
            ErrorKind.MATERIALIZE_FAILED,
            f"Semantic ref {ref.key!r} has kind {ref.kind}; expected {expected_text}.",
            cls=SemanticRuntimeError,
            refs=(ref.key,),
            details={"expected_kind": expected_text, "actual_kind": str(ref.kind)},
        )
    return catalog.require(ref).path


@dataclass
class SemanticResolver:
    """Internal semantic-to-Ibis resolver for analysis and catalog previews."""

    catalog: SemanticCatalog
    connections: Any
    sample_size: int | None = None
    entity_scopes: Mapping[str, AuthoringScope] | None = None
    source_bindings: Mapping[str, Mapping[str, QueryParamScalar | QueryParamScalarList]] | None = (
        None
    )

    def __post_init__(self) -> None:
        self._materializer = Materializer(
            self.catalog._project,
            self.connections.session_backend,
            sample_size=self.sample_size,
            entity_scopes=self.entity_scopes,
            source_bindings=self.source_bindings,
        )

    def entity(self, entity_ref: Ref[EntityKind]) -> ibis.Table:
        ref = _require_kind(self.catalog, entity_ref, expected=(SemanticKind.ENTITY,))
        return self._materializer.entity(ref)

    def table(self, entity_ref: Ref[EntityKind]) -> ibis.Table:
        """Private compatibility spelling for tabular preview internals."""
        return self.entity(entity_ref)

    def dimension(self, ref_value: Ref[FieldKind]) -> ir.Value:
        ref = _require_kind(
            self.catalog,
            ref_value,
            expected=(SemanticKind.DIMENSION, SemanticKind.TIME_DIMENSION),
        )
        return self._materializer.dimension(ref)

    def metric(self, ref_value: Ref[MetricKind]) -> ir.Value:
        ref = _require_kind(self.catalog, ref_value, expected=(SemanticKind.METRIC,))
        return self._materializer.metric(ref)

    def measure(self, ref_value: Ref[MeasureKind]) -> ir.Value:
        ref = _require_kind(self.catalog, ref_value, expected=(SemanticKind.MEASURE,))
        return self._materializer.measure(ref)

    def measure_on(
        self,
        ref_value: Ref[MeasureKind],
        table: ibis.Table,
    ) -> ir.Value:
        ref = _require_kind(self.catalog, ref_value, expected=(SemanticKind.MEASURE,))
        return self._materializer.measure_on(ref, table)

    def aggregate_measure_on(
        self,
        ref_value: Ref[MeasureKind],
        table: ibis.Table,
        agg: AggKind,
    ) -> ir.Value:
        """Apply one registered aggregate to a governed measure on ``table``."""
        ref = _require_kind(self.catalog, ref_value, expected=(SemanticKind.MEASURE,))
        return self._materializer.aggregate_measure_on(ref, table, agg)

    def weighted_mean_aggregates_on(
        self,
        value: Ref[MeasureKind],
        weight: Ref[MeasureKind],
        table: ibis.Table,
    ) -> tuple[ir.Value, ir.Value, ir.Value]:
        """Build exact weighted-mean aggregate expressions on one governed table."""
        value_ref = _require_kind(self.catalog, value, expected=(SemanticKind.MEASURE,))
        weight_ref = _require_kind(self.catalog, weight, expected=(SemanticKind.MEASURE,))
        return self._materializer.weighted_mean_aggregates_on(value_ref, weight_ref, table)

    def dimension_on(
        self,
        ref_value: Ref[FieldKind],
        table: ibis.Table,
    ) -> ir.Value:
        ref = _require_kind(
            self.catalog,
            ref_value,
            expected=(SemanticKind.DIMENSION, SemanticKind.TIME_DIMENSION),
        )
        return self._materializer.dimension_on(ref, table)

    def metric_on(
        self,
        ref_value: Ref[MetricKind],
        *tables: ibis.Table,
    ) -> ir.Value:
        ref = _require_kind(self.catalog, ref_value, expected=(SemanticKind.METRIC,))
        return self._materializer.metric_on(ref, *tables)

    def event(
        self,
        event_ref: Ref[EventKind],
        *,
        participants: tuple[str, ...],
    ) -> ibis.Table:
        """Materialize one Event occurrence relation for participant roles."""
        ref = _require_kind(self.catalog, event_ref, expected=(SemanticKind.EVENT,))
        return self._materializer.event(ref, participants=participants)

    def event_occurrences(self, event_ref: Ref[EventKind]) -> ibis.Table:
        """Materialize one Event's exact source occurrences without participant joins."""
        ref = _require_kind(self.catalog, event_ref, expected=(SemanticKind.EVENT,))
        return self._materializer.event_occurrences(ref)
