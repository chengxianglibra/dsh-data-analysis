"""Decompose DeltaFrames into AttributionFrames."""

from __future__ import annotations

from datetime import datetime
from time import monotonic
from typing import Any, Literal

import numpy as np
import pandas as pd

from marivo._compat import UTC
from marivo.analysis.errors import (
    AnalysisError,
    AnalysisRepair,
    AttributionAdditivityError,
    ComponentDecompositionError,
    CumulativeFrameUnsupportedError,
    SemanticKindMismatchError,
)
from marivo.analysis.evidence.identity import make_issue_id
from marivo.analysis.evidence.types import AnalysisScope, ComparabilityIssue
from marivo.analysis.frames._attribution_columns import (
    ATTRIBUTION_AXIS_COLUMN,
    ATTRIBUTION_DRIVER_COLUMN,
    ATTRIBUTION_LEVEL_COLUMN,
    ATTRIBUTION_OTHER_MASK_COLUMN,
    ATTRIBUTION_PATH_COLUMN,
)
from marivo.analysis.frames.attribution import (
    AttributionBucketReconciliationV1,
    AttributionFrame,
    AttributionMethodEvidenceV1,
    AttributionReconciliation,
    AttributionTopKSelectionV1,
    _reconciliation_bucket_scalar,
)
from marivo.analysis.frames.base import BaseFrame
from marivo.analysis.frames.component import (
    ComponentFrame,
    resolve_role_column_name,
    resolve_role_columns,
)
from marivo.analysis.frames.delta import CumulativeDeltaFrameMetaV1, DeltaFrame, DeltaFrameMeta
from marivo.analysis.intents._attribution_mode import AttributionMode, validate_attribution_mode
from marivo.analysis.intents._attribution_topk import AttributionTopKMapV1, build_top_k_map
from marivo.analysis.intents._derived import (
    ensure_frame_in_session,
    persist_attribution_frame,
    require_numeric_column,
    resolve_session,
)
from marivo.analysis.intents._validate import (
    raise_first,
    validate_decompose_axes_columns,
    validate_decompose_columns,
)
from marivo.analysis.semantic_inputs import normalize_dimension_boundary
from marivo.analysis.session._load import load_frame
from marivo.analysis.session.core import Session, ensure_session_can_execute
from marivo.introspection.live.model import LiveHelpTarget
from marivo.refs import DimensionKind, TimeDimensionKind
from marivo.semantic.catalog import _SemanticInput


def _bucket_column_for_panel(frame: DeltaFrame) -> str:
    axes = frame.meta.alignment.get("axes", {})
    if isinstance(axes, dict):
        for axis in axes.values():
            if isinstance(axis, dict) and axis.get("role") == "time":
                column = axis.get("column")
                if isinstance(column, str) and column:
                    return column
    return "bucket_start"


def _panel_dimension_columns(frame: DeltaFrame) -> list[str]:
    axes = frame.meta.alignment.get("axes", {})
    if not isinstance(axes, dict):
        return []
    columns: list[str] = []
    for axis in axes.values():
        if not isinstance(axis, dict) or axis.get("role") != "dimension":
            continue
        column = axis.get("column")
        if isinstance(column, str) and column:
            columns.append(column)
    return sorted(columns)


def _normalize_axis_boundary(
    session: Session,
    axis: _SemanticInput[DimensionKind | TimeDimensionKind],
) -> str:
    return normalize_dimension_boundary(
        session.catalog,
        axis,
        argument="axis",
        help_target="attribute",
    )


def _resolve_axis_column(frame: DeltaFrame, axis_id: str, columns: list[str]) -> str | None:
    requested = axis_id
    if requested in columns:
        return requested

    axes = frame.meta.alignment.get("axes", {})
    if isinstance(axes, dict):
        for axis_id, axis_meta in axes.items():
            if not isinstance(axis_meta, dict):
                continue
            column = axis_meta.get("column")
            if not isinstance(column, str) or column not in columns:
                continue
            ref = axis_meta.get("ref")
            time_dim = axis_meta.get("time_dimension")
            candidates = [str(axis_id), column]
            if isinstance(ref, str):
                candidates.append(ref)
            if isinstance(time_dim, str):
                candidates.append(time_dim)
                # Also match the leaf of a dotted requested axis
                # against time_dimension (e.g. "sales.orders.created_at"
                # matches time_dimension="created_at").
                requested_leaf = requested.rsplit(".", 1)[-1]
                if requested_leaf == time_dim:
                    candidates.append(requested)
            if requested in candidates:
                return column

    axis_leaf = requested.rsplit(".", 1)[-1]
    if axis_leaf in columns:
        return axis_leaf
    return None


def _effective_component_axis_column(
    frame: DeltaFrame,
    axis_id: str,
    columns: list[str],
) -> str | None:
    resolved = _resolve_axis_column(frame, axis_id, columns)
    if resolved is not None:
        return resolved
    axis_leaf = axis_id.rsplit(".", 1)[-1]
    if frame.meta.semantic_kind == "time_series" and axis_leaf in (
        "bucket_start",
        "bucket_start_a",
    ):
        if "bucket_start" in columns:
            return "bucket_start"
        if "bucket_start_a" in columns:
            return "bucket_start_a"
    if axis_leaf == "bucket_start" and "bucket_start_a" in columns:
        return "bucket_start_a"
    return None


def _component_bucket_column(frame: DeltaFrame, columns: list[str]) -> str | None:
    if frame.meta.semantic_kind not in {"time_series", "panel"}:
        return None
    if "bucket_start" in columns:
        return "bucket_start"
    if "bucket_start_a" in columns:
        return "bucket_start_a"
    return None


def _load_delta_component_frame(frame: DeltaFrame, *, session: Session) -> ComponentFrame | None:
    assert isinstance(frame.meta, DeltaFrameMeta)
    if frame.meta.component_ref is None:
        return None
    loaded = load_frame(frame.meta.component_ref, session=session)
    if not isinstance(loaded, ComponentFrame):
        raise ComponentDecompositionError(
            message="delta component_ref did not resolve to a ComponentFrame",
            context={
                "delta_ref": frame.ref,
                "component_ref": frame.meta.component_ref,
                "loaded_kind": loaded.meta.kind,
            },
        )
    return loaded


_NON_LINEAR_FOLD_RECOMMENDED_PATH = (
    "Use a component-aware ratio or weighted-mean metric for mix "
    "attribution, or attribute numerator and denominator separately and "
    "synthesize the ratio externally."
)


def _non_linear_fold_labels(frame: DeltaFrame) -> list[str]:
    fold = getattr(frame.meta, "fold", None)
    component_folds = getattr(frame.meta, "component_folds", [])
    entries: list[dict[str, Any]] = []
    if isinstance(fold, dict):
        entries.append(fold)
    entries.extend(item for item in component_folds if isinstance(item, dict))
    non_linear: list[str] = []
    for entry in entries:
        label = entry.get("time_fold")
        if not label or str(label) == "derived":
            continue
        fold_kind = entry.get("fold_kind")
        # Structured fold_kind (populated by observe): only 'mean' is linear.
        # Legacy payload without fold_kind: only an exact 'mean' label is linear,
        # avoiding the old startswith('mean') prefix match silently passing
        # labels like 'mean_weighted'.
        is_linear = (fold_kind == "mean") if fold_kind is not None else (str(label) == "mean")
        if not is_linear:
            non_linear.append(str(label))
    return non_linear


def _component_allows_non_linear_fold(component: ComponentFrame | None) -> bool:
    return component is not None and component.meta.composition_kind in {
        "ratio",
        "weighted_mean",
    }


def _raise_non_linear_fold_error(frame: DeltaFrame, fold_labels: list[str]) -> None:
    raise ComponentDecompositionError(
        message=(
            "decompose cannot sum non-linear sampled time fold deltas by axis; "
            "component-aware ratio or weighted-mean deltas can use mix attribution"
        ),
        context={
            "reason": "non_linear_time_fold",
            "delta_ref": frame.ref,
            "time_folds": fold_labels,
            "supported_component_kinds": ["ratio", "weighted_mean"],
            "recommended_path": _NON_LINEAR_FOLD_RECOMMENDED_PATH,
        },
    )


def _mean_fold_coverage_warning(frame: DeltaFrame, session: Session) -> list[ComparabilityIssue]:
    """Warn (non-blocking) when a mean-fold delta decomposes segments whose
    per-window sample counts differ.

    Sum-of-segment-means equals overall-mean-of-sums only when every segment
    has the same sample count; missing samples (device up/down, collection
    gaps) make the contribution decomposition approximate. The warning is
    best-effort: it requires the current/baseline source frames to be
    loadable and to carry a coverage_summary (hand-built test deltas without
    real source frames are skipped silently).
    """
    fold = getattr(frame.meta, "fold", None)
    if not isinstance(fold, dict):
        return []
    fold_kind = fold.get("fold_kind")
    if fold_kind is not None:
        is_mean = fold_kind == "mean"
    else:
        is_mean = str(fold.get("time_fold", "")) == "mean"
    if not is_mean:
        return []

    summaries: dict[str, dict[str, Any]] = {}
    scopes: dict[str, AnalysisScope] = {}
    for side, ref in (
        ("current", frame.meta.source_current_ref),
        ("baseline", frame.meta.source_baseline_ref),
    ):
        try:
            loaded = load_frame(ref, session=session)
        except AnalysisError:
            return []
        summary = getattr(loaded.meta, "coverage_summary", None)
        if not isinstance(summary, dict):
            return []
        summaries[side] = summary
        loaded_scope = loaded.meta.analysis_scope
        scopes[side] = loaded_scope if isinstance(loaded_scope, AnalysisScope) else AnalysisScope()

    def _uneven(summary: dict[str, Any]) -> bool:
        try:
            return float(summary["min"]) < float(summary["avg"])
        except (TypeError, ValueError, KeyError):
            return False

    if not (_uneven(summaries["current"]) or _uneven(summaries["baseline"])):
        return []

    return [
        ComparabilityIssue(
            issue_id=make_issue_id(
                artifact_id=frame.ref,
                kind="comparability_approximate",
                source_refs=(frame.meta.source_current_ref, frame.meta.source_baseline_ref),
            ),
            kind="comparability_approximate",
            severity="warning",
            source_refs=(frame.ref,),
            left_scope=scopes["current"],
            right_scope=scopes["baseline"],
            incompatible_fields=("sample_coverage",),
            approximation_details=(
                "mean-fold segment sample counts are uneven",
                f"current_min={summaries['current'].get('min')}",
                f"current_avg={summaries['current'].get('avg')}",
                f"baseline_min={summaries['baseline'].get('min')}",
                f"baseline_avg={summaries['baseline'].get('avg')}",
            ),
        )
    ]


def _status_time_dimension(frame: DeltaFrame) -> str | None:
    assert isinstance(frame.meta, DeltaFrameMeta)
    if frame.meta.status_time_dimension is not None:
        return frame.meta.status_time_dimension
    fold = frame.meta.fold
    if isinstance(fold, dict):
        value = fold.get("status_time_dimension")
        if isinstance(value, str) and value:
            return value
    return None


def _raise_attribution_additivity_error(
    frame: DeltaFrame,
    *,
    axes: list[str],
    reason: str,
    status_time_dimension: str | None = None,
    component: ComponentFrame | None = None,
) -> None:
    assert isinstance(frame.meta, DeltaFrameMeta)
    if status_time_dimension is None:
        status_time_dimension = _status_time_dimension(frame)
    if reason == "missing_additivity_metadata":
        message = "decompose requires persisted additivity metadata before summing deltas by axis"
        action = (
            "Re-run observe and compare with the current semantic model so the DeltaFrame "
            "carries additivity metadata, then retry attribute."
        )
    elif reason == "semi_additive_time_axis":
        message = "decompose cannot sum a semi-additive metric delta over its status time axis"
        action = (
            "Attribute over non-time dimensions only, or model additive components and "
            "attribute those components separately."
        )
    else:
        message = "decompose cannot sum a non-additive metric delta by axis"
        action = (
            "Model the metric as a component-aware ratio or weighted average, or attribute "
            "its additive numerator and denominator separately."
        )
    composition_kind: str | None = (
        component.meta.composition_kind if component is not None else None
    )
    if composition_kind is None and isinstance(frame.meta.composition, dict):
        persisted_kind = frame.meta.composition.get("kind")
        if isinstance(persisted_kind, str):
            composition_kind = persisted_kind
    raise AttributionAdditivityError(
        message=message,
        expected="an additive delta or a component-aware ratio/weighted-mean delta",
        received=(
            f"additivity={frame.meta.additivity!r}, aggregation={frame.meta.aggregation!r}, "
            f"composition_kind={composition_kind!r}"
        ),
        location="session.attribute",
        repair=AnalysisRepair(
            kind="retry",
            action=action,
            help_target=LiveHelpTarget(surface="analysis", canonical_id="attribute"),
        ),
        context={
            "reason": reason,
            "delta_ref": frame.ref,
            "metric": frame.meta.metric_id,
            "metric_id": frame.meta.metric_id,
            "additivity": frame.meta.additivity,
            "aggregation": frame.meta.aggregation,
            "axes": axes,
            "status_time_dimension": status_time_dimension,
            "composition_kind": composition_kind,
            "supported_component_kinds": ["ratio", "weighted_mean"],
            "recommended_path": action,
        },
    )


def _validate_attribution_additivity(
    frame: DeltaFrame,
    *,
    axes: list[str],
    component: ComponentFrame | None,
) -> None:
    if isinstance(frame.meta, CumulativeDeltaFrameMetaV1):
        # Public decompose remains gated. Internal cumulative business-axis
        # execution is admitted by the compact structure before reaching here.
        return
    assert isinstance(frame.meta, DeltaFrameMeta)
    if _component_allows_non_linear_fold(component):
        return
    if frame.meta.additivity == "additive":
        return
    if frame.meta.additivity == "semi_additive":
        status_time_dimension = _status_time_dimension(frame)
        if status_time_dimension is None:
            _raise_attribution_additivity_error(
                frame,
                axes=axes,
                reason="missing_additivity_metadata",
                component=component,
            )
        if status_time_dimension not in axes:
            return
        _raise_attribution_additivity_error(
            frame,
            axes=axes,
            reason="semi_additive_time_axis",
            status_time_dimension=status_time_dimension,
            component=component,
        )
    _raise_attribution_additivity_error(
        frame,
        axes=axes,
        reason=(
            "missing_additivity_metadata"
            if frame.meta.additivity is None
            else "non_additive_metric"
        ),
        component=component,
    )


def _validate_attribution_semantics(
    frame: DeltaFrame,
    *,
    axes: list[str],
    session: Session,
) -> ComponentFrame | None:
    """Validate persisted attribution semantics before any materialization."""
    component = _load_delta_component_frame(frame, session=session)
    non_linear_fold_labels = _non_linear_fold_labels(frame)
    if non_linear_fold_labels and not _component_allows_non_linear_fold(component):
        _raise_non_linear_fold_error(frame, non_linear_fold_labels)
    _validate_attribution_additivity(frame, axes=axes, component=component)
    return component


def _component_role_column_name(component: ComponentFrame, role: str) -> str:
    return resolve_role_column_name(component.meta.components, role)


def _component_measure_role(component: ComponentFrame) -> str:
    if component.meta.composition_kind == "ratio":
        return _component_role_column_name(component, "denominator")
    if component.meta.composition_kind == "weighted_mean":
        return _component_role_column_name(component, "weight")
    raise ComponentDecompositionError(
        message="unsupported component composition kind",
        context={"composition_kind": component.meta.composition_kind},
    )


def _component_value_role(component: ComponentFrame) -> str:
    """Return the value-role column name for the mix math.

    Both ratio and weighted_mean use the truthful numerator role.
    """
    if component.meta.composition_kind == "ratio":
        return "numerator"
    if component.meta.composition_kind == "weighted_mean":
        return "numerator"
    raise ComponentDecompositionError(
        message="unsupported component composition kind for value role",
        context={"composition_kind": component.meta.composition_kind},
    )


def _component_method(component: ComponentFrame) -> str:
    if component.meta.composition_kind == "ratio":
        return "ratio_mix"
    if component.meta.composition_kind == "weighted_mean":
        return "weighted_mix"
    raise ComponentDecompositionError(
        message="unsupported component composition kind",
        context={"composition_kind": component.meta.composition_kind},
    )


def _safe_divide(numerator: pd.Series, denominator: pd.Series) -> pd.Series:
    numerator = pd.to_numeric(numerator, errors="coerce")
    denominator = pd.to_numeric(denominator, errors="coerce")
    return pd.Series(
        np.where(denominator.notna() & (denominator != 0), numerator / denominator, np.nan),
        index=numerator.index,
    )


def _path_segment(value: Any) -> str:
    """Render one hierarchy path segment with a stable null placeholder.

    ``str(float('nan'))`` / ``astype(str)`` on missing values yields the
    language-dependent literal ``'nan'``; writing that into a persisted
    attribution_path makes it part of the finding identity.  Render any
    missing value as ``"<NA>"`` instead so the persisted path is stable.
    """
    if pd.isna(value):
        return "<NA>"
    return str(value)


def _hierarchy_display_value(row: pd.Series, column: str, axis_position: int) -> object:
    if ATTRIBUTION_OTHER_MASK_COLUMN in row.index and int(row[ATTRIBUTION_OTHER_MASK_COLUMN]) & (
        1 << axis_position
    ):
        return "Other"
    return row[column]


_ATTRIBUTION_TOTAL_DELTA_COLUMN = "_attribution_total_delta"
_ATTRIBUTION_ONE_SIDED_COLUMN = "_attribution_one_sided"
# Every decompose path keeps the dimension columns and the attribution base
# protocol columns as distinct columns.
_ATTRIBUTION_BASE_RESERVED_COLUMNS = frozenset(
    {
        _ATTRIBUTION_TOTAL_DELTA_COLUMN,
        _ATTRIBUTION_ONE_SIDED_COLUMN,
        ATTRIBUTION_OTHER_MASK_COLUMN,
        "contribution",
        "rank",
        "share_of_negative_pool",
        "share_of_positive_pool",
        "share_of_total_delta",
    }
)
# value_effect/mix_effect/residual appear on the component mix/linear paths
# and the additive multi-axis joint/hierarchy paths, but NOT on the
# single-axis additive path.
_ATTRIBUTION_EFFECT_RESERVED_COLUMNS = frozenset(
    {
        "value_effect",
        "mix_effect",
        "residual",
    }
)
# current_share/baseline_share appear only on the component-aware mix path.
_ATTRIBUTION_COMPONENT_SHARE_RESERVED_COLUMNS = frozenset(
    {
        "current_share",
        "baseline_share",
    }
)
# The hierarchy layout columns appear only on multi-axis joint/hierarchy layouts.
_ATTRIBUTION_HIERARCHY_RESERVED_COLUMNS = frozenset(
    {
        ATTRIBUTION_LEVEL_COLUMN,
        ATTRIBUTION_AXIS_COLUMN,
        ATTRIBUTION_DRIVER_COLUMN,
        ATTRIBUTION_PATH_COLUMN,
    }
)


def _add_contribution_shares(
    output: pd.DataFrame,
    *,
    total_delta: float,
) -> pd.DataFrame:
    """Attach signed net and same-sign pool shares without hiding offsets."""
    contribution = pd.to_numeric(output["contribution"], errors="coerce")
    valid = contribution.notna()
    positive_total = float(contribution[valid & (contribution > 0)].sum())
    negative_total = float(-contribution[valid & (contribution < 0)].sum())
    output["share_of_total_delta"] = np.where(
        valid & (total_delta != 0), contribution / total_delta, np.nan
    )
    output["share_of_positive_pool"] = np.where(
        valid & (contribution > 0) & (positive_total != 0),
        contribution / positive_total,
        np.nan,
    )
    output["share_of_negative_pool"] = np.where(
        valid & (contribution < 0) & (negative_total != 0),
        -contribution / negative_total,
        np.nan,
    )
    output[_ATTRIBUTION_TOTAL_DELTA_COLUMN] = total_delta
    return output


def _component_side_value(
    numerator: pd.Series,
    basis: pd.Series,
    *,
    component: ComponentFrame,
    side: str,
) -> pd.Series:
    """Return a within-segment value, treating an absent zero/zero side as zero."""
    numeric_numerator = pd.to_numeric(numerator, errors="coerce")
    numeric_basis = pd.to_numeric(basis, errors="coerce")
    invalid_zero_basis = (
        numeric_basis.eq(0) & numeric_numerator.notna() & ~np.isclose(numeric_numerator, 0.0)
    )
    if bool(invalid_zero_basis.any()):
        raise ComponentDecompositionError(
            message="component-aware decompose found a non-zero numerator with zero weight",
            context={
                "component_ref": component.ref,
                "side": side,
                "invalid_row_count": int(invalid_zero_basis.sum()),
            },
        )
    value = _safe_divide(numeric_numerator, numeric_basis)
    structural_zero = numeric_basis.eq(0) & numeric_numerator.fillna(0.0).eq(0)
    return value.mask(structural_zero, 0.0)


def _component_total_value(
    numerator: pd.Series,
    basis_total: float,
    *,
    component: ComponentFrame,
    side: str,
) -> float:
    numerator_total = float(pd.to_numeric(numerator, errors="coerce").sum(skipna=True))
    if np.isfinite(basis_total) and basis_total != 0:
        return numerator_total / basis_total
    if (
        np.isfinite(basis_total)
        and np.isclose(basis_total, 0.0)
        and np.isclose(numerator_total, 0.0)
    ):
        return 0.0
    raise ComponentDecompositionError(
        message="component-aware decompose could not form an aggregate component value",
        context={
            "component_ref": component.ref,
            "side": side,
            "numerator_total": numerator_total,
            "basis_total": basis_total,
        },
    )


def _populate_component_mix(
    output: pd.DataFrame,
    *,
    component: ComponentFrame,
    numerator_name: str,
    share_role: str,
    value_name: str,
) -> pd.DataFrame:
    current_numerator = pd.to_numeric(output[f"current_{numerator_name}"], errors="coerce")
    baseline_numerator = pd.to_numeric(output[f"baseline_{numerator_name}"], errors="coerce")
    current_basis = pd.to_numeric(output[f"current_{share_role}"], errors="coerce")
    baseline_basis = pd.to_numeric(output[f"baseline_{share_role}"], errors="coerce")
    current_total = float(current_basis.sum(skipna=True))
    baseline_total = float(baseline_basis.sum(skipna=True))
    current_total_value = _component_total_value(
        current_numerator,
        current_total,
        component=component,
        side="current",
    )
    baseline_total_value = _component_total_value(
        baseline_numerator,
        baseline_total,
        component=component,
        side="baseline",
    )
    current_share = (
        current_basis / current_total if current_total != 0 else pd.Series(0.0, index=output.index)
    )
    baseline_share = (
        baseline_basis / baseline_total
        if baseline_total != 0
        else pd.Series(0.0, index=output.index)
    )
    current_value = _component_side_value(
        current_numerator,
        current_basis,
        component=component,
        side="current",
    )
    baseline_value = _component_side_value(
        baseline_numerator,
        baseline_basis,
        component=component,
        side="baseline",
    )
    output[f"current_{value_name}"] = current_value
    output[f"baseline_{value_name}"] = baseline_value
    output["contribution"] = current_share * current_value - baseline_share * baseline_value
    output["value_effect"] = current_share * (current_value - baseline_value)
    output["mix_effect"] = (current_share - baseline_share) * baseline_value
    output["residual"] = output["contribution"] - output["value_effect"] - output["mix_effect"]
    if bool(output["contribution"].isna().any()):
        invalid_row_count = int(output["contribution"].isna().sum())
        raise ComponentDecompositionError(
            message="component-aware decompose could not form every contribution row",
            expected="every pair to carry both a current and a baseline component value",
            received=f"{invalid_row_count} contribution row(s) could not be formed",
            location="session.attribute component decomposition",
            repair=AnalysisRepair(
                kind="inspect",
                action=(
                    "Inspect the component sidecar for rows that fail temporal "
                    "alignment (e.g. missing/NaT time keys); re-observe the "
                    "derived metric with a complete temporal axis, or drop the "
                    "un-matchable component rows, then retry attribution."
                ),
                help_target=LiveHelpTarget(surface="analysis", canonical_id="attribute"),
            ),
            context={
                "component_ref": component.ref,
                "share_role": share_role,
                "invalid_row_count": invalid_row_count,
            },
        )
    output["current_share"] = current_share
    output["baseline_share"] = baseline_share
    output[_ATTRIBUTION_ONE_SIDED_COLUMN] = current_basis.eq(0) ^ baseline_basis.eq(0)
    return _add_contribution_shares(
        output,
        total_delta=current_total_value - baseline_total_value,
    )


def _finalize_attribution_output(
    output: pd.DataFrame,
    *,
    bucket_column: str | None,
    deepest_only: bool = False,
) -> tuple[pd.DataFrame, AttributionReconciliation]:
    """Validate every deepest attribution partition and remove internal columns.

    ``deepest_only`` is set by the hierarchy paths, which emit one row per
    prefix level and must reconcile only the deepest level.  It is passed
    explicitly rather than inferred from the presence of a ``level`` column,
    so a legal business dimension literally named ``level`` is never mistaken
    for the internal hierarchy level marker and cropped (issue #43).
    """
    if output.empty:
        return (
            output.drop(
                columns=[_ATTRIBUTION_TOTAL_DELTA_COLUMN, _ATTRIBUTION_ONE_SIDED_COLUMN],
                errors="ignore",
            ),
            AttributionReconciliation(partition_count=0, max_abs_residual=0.0),
        )

    checked = output
    if deepest_only:
        checked = checked[
            checked[ATTRIBUTION_LEVEL_COLUMN] == checked[ATTRIBUTION_LEVEL_COLUMN].max()
        ]
    grouped: list[tuple[object | None, pd.DataFrame]]
    if bucket_column is None:
        grouped = [(None, checked)]
    else:
        grouped = list(checked.groupby(bucket_column, dropna=False, sort=True))

    facts: list[tuple[object | None, int, float, float, float, float, float]] = []
    for bucket_value, group in grouped:
        total_values = pd.to_numeric(
            group[_ATTRIBUTION_TOTAL_DELTA_COLUMN], errors="coerce"
        ).dropna()
        if total_values.empty:
            raise ComponentDecompositionError(
                message="attribution output is missing its independent reconciliation total",
                context={"bucket_column": bucket_column},
            )
        total_delta = float(total_values.iloc[0])
        contribution_sum = float(pd.to_numeric(group["contribution"], errors="coerce").sum())
        residual = total_delta - contribution_sum
        tolerance = max(1e-12, 1e-9 * max(abs(total_delta), abs(contribution_sum), 1.0))
        if not np.isfinite(residual) or abs(residual) > tolerance:
            raise ComponentDecompositionError(
                message="attribution contributions do not reconcile to the overall delta",
                context={
                    "total_delta": total_delta,
                    "contribution_sum": contribution_sum,
                    "reconciliation_residual": residual,
                    "tolerance": tolerance,
                },
            )
        one_sided_sum = 0.0
        if _ATTRIBUTION_ONE_SIDED_COLUMN in group.columns:
            one_sided = group[_ATTRIBUTION_ONE_SIDED_COLUMN].fillna(False).astype(bool)
            one_sided_sum = float(
                pd.to_numeric(group.loc[one_sided, "contribution"], errors="coerce").sum()
            )
        facts.append(
            (
                bucket_value,
                len(group),
                total_delta,
                contribution_sum,
                one_sided_sum,
                residual,
                tolerance,
            )
        )

    single_partition = len(facts) == 1
    _, _, total_delta, contribution_sum, one_sided_sum, residual, _tolerance = facts[0]
    bucket_reconciliations = (
        tuple(
            AttributionBucketReconciliationV1(
                bucket_key=((bucket_column, _reconciliation_bucket_scalar(bucket_value)),),
                row_count=row_count,
                total_delta=partition_total,
                contribution_sum=partition_sum,
                residual=partition_residual,
                tolerance=partition_tolerance,
            )
            for (
                bucket_value,
                row_count,
                partition_total,
                partition_sum,
                _one_sided_sum,
                partition_residual,
                partition_tolerance,
            ) in facts
        )
        if bucket_column is not None
        else ()
    )
    reconciliation = AttributionReconciliation(
        partition_count=len(facts),
        total_delta=total_delta if single_partition else None,
        contribution_sum=contribution_sum if single_partition else None,
        one_sided_contribution_sum=one_sided_sum if single_partition else None,
        unattributed_contribution_sum=residual if single_partition else None,
        residual=residual if single_partition else None,
        max_abs_residual=max(abs(item[5]) for item in facts),
        bucket_reconciliations=bucket_reconciliations,
    )
    cleaned = output.drop(
        columns=[_ATTRIBUTION_TOTAL_DELTA_COLUMN, _ATTRIBUTION_ONE_SIDED_COLUMN],
        errors="ignore",
    )
    return cleaned, reconciliation


def _infer_delta_value_column_name(component: ComponentFrame) -> str:
    """Infer the metric-name value column from the component delta frame columns.

    Looks for a ``current_<name>`` column whose ``<name>`` is not a declared
    decomposition component metric name.
    """
    known_component_names = set(resolve_role_columns(component.meta.components))
    for column in component._df.columns:
        if column.startswith("current_"):
            name = column[len("current_") :]
            if name not in known_component_names:
                return name
    raise ComponentDecompositionError(
        message="component delta frame has no metric value column",
        context={"component_ref": component.ref},
    )


def _component_mix_output_for_df(
    *,
    df: pd.DataFrame,
    component: ComponentFrame,
    axis_column: str,
) -> pd.DataFrame:
    share_role = _component_measure_role(component)
    numerator_name = _component_role_column_name(component, _component_value_role(component))
    value_name = _infer_delta_value_column_name(component)
    required = [
        axis_column,
        f"current_{numerator_name}",
        f"baseline_{numerator_name}",
        f"current_{share_role}",
        f"baseline_{share_role}",
        f"current_{value_name}",
        f"baseline_{value_name}",
    ]
    missing = [column for column in required if column not in df.columns]
    if missing:
        raise ComponentDecompositionError(
            message="component-aware decompose requires component delta columns",
            context={"component_ref": component.ref, "missing_columns": missing},
        )
    output = df[required].copy()
    output = _populate_component_mix(
        output,
        component=component,
        numerator_name=numerator_name,
        share_role=share_role,
        value_name=value_name,
    )
    output = output.reindex(
        output["contribution"].abs().sort_values(ascending=False).index
    ).reset_index(drop=True)
    output["rank"] = range(1, len(output) + 1)
    return output[
        [
            axis_column,
            "contribution",
            "share_of_total_delta",
            "share_of_positive_pool",
            "share_of_negative_pool",
            "value_effect",
            "mix_effect",
            "residual",
            f"current_{numerator_name}",
            f"baseline_{numerator_name}",
            f"current_{share_role}",
            f"baseline_{share_role}",
            f"current_{value_name}",
            f"baseline_{value_name}",
            "current_share",
            "baseline_share",
            _ATTRIBUTION_TOTAL_DELTA_COLUMN,
            _ATTRIBUTION_ONE_SIDED_COLUMN,
            "rank",
        ]
    ]


def _component_linear_output_for_df(
    *,
    df: pd.DataFrame,
    component: ComponentFrame,
    axis_column: str,
) -> pd.DataFrame:
    """Additive attribution: each component term contributes sign*(current-baseline)."""
    out = df[[axis_column]].copy()
    total = pd.Series(0.0, index=df.index)
    for sign, ref_id in component.meta.linear_terms:
        role = next(
            (r for r, cid in component.meta.components.items() if cid == ref_id),
            None,
        )
        if role is None:
            continue
        col = _component_role_column_name(component, role)
        cur_key = f"current_{col}"
        base_key = f"baseline_{col}"
        if cur_key not in df.columns or base_key not in df.columns:
            continue
        cur = pd.to_numeric(df[cur_key], errors="coerce")
        base = pd.to_numeric(df[base_key], errors="coerce")
        contrib = (cur - base) * (1.0 if sign == "+" else -1.0)
        total = total.add(contrib, fill_value=0.0)
    out["contribution"] = total
    out["value_effect"] = total  # additive: all contribution is value-effect
    out["mix_effect"] = 0.0
    out["residual"] = 0.0
    total_val = float(out["contribution"].sum())
    out = _add_contribution_shares(out, total_delta=total_val)
    out = out.reindex(out["contribution"].abs().sort_values(ascending=False).index).reset_index(
        drop=True
    )
    out["rank"] = range(1, len(out) + 1)
    return out[
        [
            axis_column,
            "contribution",
            "share_of_total_delta",
            "share_of_positive_pool",
            "share_of_negative_pool",
            "value_effect",
            "mix_effect",
            "residual",
            _ATTRIBUTION_TOTAL_DELTA_COLUMN,
            "rank",
        ]
    ]


def _component_mix_output(
    *,
    component: ComponentFrame,
    axis_column: str,
    bucket_column: str | None = None,
) -> pd.DataFrame:
    df = component._dataframe_copy()
    if bucket_column is None:
        return _component_mix_output_for_df(
            df=df,
            component=component,
            axis_column=axis_column,
        )

    if bucket_column not in df.columns:
        raise ComponentDecompositionError(
            message="component-aware panel decompose requires a bucket column",
            context={"component_ref": component.ref, "bucket_column": bucket_column},
        )

    pieces: list[pd.DataFrame] = []
    for bucket_value, bucket_df in df.groupby(bucket_column, dropna=False, sort=True):
        piece = _component_mix_output_for_df(
            df=bucket_df,
            component=component,
            axis_column=axis_column,
        )
        piece.insert(0, bucket_column, bucket_value)
        pieces.append(piece)
    if not pieces:
        raise ComponentDecompositionError(
            message="component-aware decompose could not form any bucket groups",
            context={"component_ref": component.ref, "bucket_column": bucket_column},
        )
    return pd.concat(pieces, ignore_index=True)


def _component_joint_mix_output_for_df(
    *,
    df: pd.DataFrame,
    component: ComponentFrame,
    axis_columns: list[str],
) -> pd.DataFrame:
    """Compute mix effects after aggregating components by a joint axis tuple."""
    share_role = _component_measure_role(component)
    numerator_name = _component_role_column_name(component, _component_value_role(component))
    value_name = _infer_delta_value_column_name(component)
    numeric_columns = [
        f"current_{numerator_name}",
        f"baseline_{numerator_name}",
        f"current_{share_role}",
        f"baseline_{share_role}",
    ]
    required = [*axis_columns, *numeric_columns]
    missing = [column for column in required if column not in df.columns]
    if missing:
        raise ComponentDecompositionError(
            message="component-aware decompose requires component delta columns",
            context={"component_ref": component.ref, "missing_columns": missing},
        )
    output = (
        df[required]
        .groupby(axis_columns, dropna=False, sort=False)[numeric_columns]
        .sum(min_count=1)
        .reset_index()
    )
    output = _populate_component_mix(
        output,
        component=component,
        numerator_name=numerator_name,
        share_role=share_role,
        value_name=value_name,
    )
    output = output.reindex(
        output["contribution"].abs().sort_values(ascending=False).index
    ).reset_index(drop=True)
    output["rank"] = range(1, len(output) + 1)
    return output[
        [
            *axis_columns,
            "contribution",
            "share_of_total_delta",
            "share_of_positive_pool",
            "share_of_negative_pool",
            "value_effect",
            "mix_effect",
            "residual",
            f"current_{numerator_name}",
            f"baseline_{numerator_name}",
            f"current_{share_role}",
            f"baseline_{share_role}",
            f"current_{value_name}",
            f"baseline_{value_name}",
            "current_share",
            "baseline_share",
            _ATTRIBUTION_TOTAL_DELTA_COLUMN,
            _ATTRIBUTION_ONE_SIDED_COLUMN,
            "rank",
        ]
    ]


def _component_joint_linear_output_for_df(
    *,
    df: pd.DataFrame,
    component: ComponentFrame,
    axis_columns: list[str],
) -> pd.DataFrame:
    """Compute additive component effects after aggregating by a joint axis tuple."""
    component_columns = [
        _component_role_column_name(component, role)
        for _, ref_id in component.meta.linear_terms
        for role, component_ref in component.meta.components.items()
        if component_ref == ref_id
    ]
    numeric_columns = [
        column
        for name in component_columns
        for column in (f"current_{name}", f"baseline_{name}")
        if column in df.columns
    ]
    grouped = (
        df[[*axis_columns, *numeric_columns]]
        .groupby(axis_columns, dropna=False, sort=False)[numeric_columns]
        .sum(min_count=1)
        .reset_index()
    )
    out = grouped[axis_columns].copy()
    total = pd.Series(0.0, index=grouped.index)
    for sign, ref_id in component.meta.linear_terms:
        role = next(
            (
                role
                for role, component_ref in component.meta.components.items()
                if component_ref == ref_id
            ),
            None,
        )
        if role is None:
            continue
        column = _component_role_column_name(component, role)
        current_key = f"current_{column}"
        baseline_key = f"baseline_{column}"
        if current_key not in grouped.columns or baseline_key not in grouped.columns:
            continue
        total = total.add(
            (
                pd.to_numeric(grouped[current_key], errors="coerce")
                - pd.to_numeric(grouped[baseline_key], errors="coerce")
            )
            * (1.0 if sign == "+" else -1.0),
            fill_value=0.0,
        )
    out["contribution"] = total
    out["value_effect"] = total
    out["mix_effect"] = 0.0
    out["residual"] = 0.0
    total_value = float(out["contribution"].sum())
    out = _add_contribution_shares(out, total_delta=total_value)
    out = out.reindex(out["contribution"].abs().sort_values(ascending=False).index).reset_index(
        drop=True
    )
    out["rank"] = range(1, len(out) + 1)
    return out[
        [
            *axis_columns,
            "contribution",
            "share_of_total_delta",
            "share_of_positive_pool",
            "share_of_negative_pool",
            "value_effect",
            "mix_effect",
            "residual",
            _ATTRIBUTION_TOTAL_DELTA_COLUMN,
            "rank",
        ]
    ]


def _component_multi_axis_output(
    *,
    component: ComponentFrame,
    axis_columns: list[str],
    mode: AttributionMode,
    bucket_column: str | None,
    top_k_map: AttributionTopKMapV1 | None = None,
) -> pd.DataFrame:
    """Produce joint or hierarchy component attribution, preserving panel buckets."""
    df = component._dataframe_copy()
    if component.meta.composition_kind == "linear":

        def joint_for_df(values: pd.DataFrame, axes: list[str]) -> pd.DataFrame:
            return _component_joint_linear_output_for_df(
                df=values, component=component, axis_columns=axes
            )
    else:

        def joint_for_df(values: pd.DataFrame, axes: list[str]) -> pd.DataFrame:
            return _component_joint_mix_output_for_df(
                df=values, component=component, axis_columns=axes
            )

    def output_for_df(values: pd.DataFrame) -> pd.DataFrame:
        if mode == "joint":
            if top_k_map is None:
                return joint_for_df(values, axis_columns)
            mapped = top_k_map.map_frame(values)
            return joint_for_df(mapped, [*axis_columns, ATTRIBUTION_OTHER_MASK_COLUMN])
        pieces: list[pd.DataFrame] = []
        for level in range(1, len(axis_columns) + 1):
            prefix = axis_columns[:level]
            mapped = top_k_map.map_frame(values, level=level) if top_k_map is not None else values
            group_columns = [*prefix]
            if top_k_map is not None:
                group_columns.append(ATTRIBUTION_OTHER_MASK_COLUMN)
            piece = joint_for_df(mapped, group_columns)
            effect_columns = [column for column in piece.columns if column not in group_columns]
            for axis_column in axis_columns[level:]:
                piece[axis_column] = pd.NA
            piece.insert(
                0,
                ATTRIBUTION_PATH_COLUMN,
                piece.apply(
                    lambda row, prefix=tuple(prefix): " > ".join(
                        _path_segment(_hierarchy_display_value(row, column, index))
                        for index, column in enumerate(prefix)
                    ),
                    axis=1,
                ),
            )
            piece.insert(
                0,
                ATTRIBUTION_DRIVER_COLUMN,
                piece.apply(
                    lambda row, axis_column=axis_columns[level - 1], axis_position=level - 1: (
                        _hierarchy_display_value(row, axis_column, axis_position)
                    ),
                    axis=1,
                ),
            )
            piece.insert(0, ATTRIBUTION_AXIS_COLUMN, axis_columns[level - 1])
            piece.insert(0, ATTRIBUTION_LEVEL_COLUMN, level)
            pieces.append(
                piece[
                    [
                        ATTRIBUTION_LEVEL_COLUMN,
                        ATTRIBUTION_AXIS_COLUMN,
                        ATTRIBUTION_DRIVER_COLUMN,
                        ATTRIBUTION_PATH_COLUMN,
                        *axis_columns,
                        *([ATTRIBUTION_OTHER_MASK_COLUMN] if top_k_map is not None else []),
                        *effect_columns,
                    ]
                ]
            )
        return pd.concat(pieces, ignore_index=True)

    if bucket_column is None:
        return output_for_df(df)
    if bucket_column not in df.columns:
        raise ComponentDecompositionError(
            message="component-aware panel decompose requires a bucket column",
            context={"component_ref": component.ref, "bucket_column": bucket_column},
        )
    pieces = []
    for bucket_value, bucket_df in df.groupby(bucket_column, dropna=False, sort=True):
        piece = output_for_df(bucket_df)
        piece.insert(0, bucket_column, bucket_value)
        pieces.append(piece)
    if not pieces:
        raise ComponentDecompositionError(
            message="component-aware decompose could not form any bucket groups",
            context={"component_ref": component.ref, "bucket_column": bucket_column},
        )
    return pd.concat(pieces, ignore_index=True)


def _normalize_axes_boundary(
    session: Session,
    axes: list[_SemanticInput[DimensionKind | TimeDimensionKind]] | None,
    axis: _SemanticInput[DimensionKind | TimeDimensionKind] | None,
) -> list[str]:
    if axes is None and axis is not None:
        axes = [axis]
    if not axes:
        raise SemanticKindMismatchError(
            message="decompose requires at least one axis",
            context={"argument": "axes"},
        )
    axis_ids = [_normalize_axis_boundary(session, item) for item in axes]
    if len(set(axis_ids)) != len(axis_ids):
        raise SemanticKindMismatchError(
            message="decompose axes must be distinct",
            context={"argument": "axes", "reason": "duplicate_axes", "axes": axis_ids},
        )
    return axis_ids


def _axis_columns_for_delta(
    frame: DeltaFrame,
    axis_ids: list[str],
    *,
    source_df: pd.DataFrame,
) -> list[str]:
    available_columns = [str(column) for column in source_df.columns]
    axis_columns: list[str] = []
    for axis_id in axis_ids:
        axis_column = _effective_component_axis_column(frame, axis_id, available_columns)
        if axis_column is None:
            raise_first(validate_decompose_columns(frame, axis_id, source_df=source_df))
        assert axis_column is not None  # validated above; needed for type narrowing
        axis_columns.append(axis_column)
    if len(set(axis_columns)) != len(axis_columns):
        raise SemanticKindMismatchError(
            message="decompose axes must resolve to distinct columns",
            context={
                "argument": "axes",
                "reason": "duplicate_axis_columns",
                "axis_columns": axis_columns,
            },
        )
    return axis_columns


def _validate_attribution_axis_columns(
    axis_columns: list[str],
    *,
    value_column: str,
    bucket_column: str | None = None,
    extra_reserved_columns: set[str] | None = None,
) -> None:
    """Fail closed when a requested axis column collides with the final row layout.

    The caller selects the reserved namespace for the branch that will run
    (single-axis additive, component mix/linear, multi-axis joint/hierarchy),
    so a dimension that only collides on another path stays usable here
    (issue #40).  Without the branch-aware check, a ``contribution``/``rank``
    axis would reach the pandas layout step and surface a raw ``ValueError``
    instead of a typed semantic error.
    """
    reserved_columns = set(_ATTRIBUTION_BASE_RESERVED_COLUMNS)
    if value_column:
        reserved_columns.add(value_column)
    if bucket_column is not None:
        reserved_columns.add(bucket_column)
    if extra_reserved_columns:
        reserved_columns.update(extra_reserved_columns)
    for axis_column in axis_columns:
        if axis_column not in reserved_columns:
            continue
        raise SemanticKindMismatchError(
            message="attribution dimension conflicts with a reserved result column",
            expected="a dimension name outside the attribution reserved namespace",
            received=repr(axis_column),
            location="session.attribute axes",
            repair=AnalysisRepair(
                kind="semantic_authoring",
                action=(
                    f"Rename dimension {axis_column!r} to a non-reserved semantic name, "
                    "reload the catalog, then re-observe and compare before retrying attribution."
                ),
                help_target=LiveHelpTarget(surface="analysis", canonical_id="attribute"),
            ),
            hint=(
                "Every attribution output must keep the dimension and attribution "
                "protocol fields as distinct columns."
            ),
            context={
                "argument": "axes",
                "reason": "reserved_axis_column",
                "axis_column": axis_column,
                "reserved_columns": sorted(reserved_columns),
            },
        )


def _single_axis_sum_output(
    df: pd.DataFrame,
    *,
    axis_column: str,
    value_column: str,
    bucket_column: str | None = None,
    top_k_map: AttributionTopKMapV1 | None = None,
) -> pd.DataFrame:
    """Aggregate an additive delta while preserving its single dimension column."""
    _validate_attribution_axis_columns(
        [axis_column],
        value_column=value_column,
        bucket_column=bucket_column,
    )
    if top_k_map is not None:
        df = top_k_map.map_frame(df)
    rows: list[dict[str, object]] = []
    bucket_values: list[object] = [None]
    if bucket_column is not None:
        bucket_values = list(df[bucket_column].drop_duplicates())

    for bucket_value in bucket_values:
        bucket_df = df if bucket_column is None else df[df[bucket_column] == bucket_value]
        denominator = float(bucket_df[value_column].sum())
        group_columns = [axis_column]
        if top_k_map is not None:
            group_columns.append(ATTRIBUTION_OTHER_MASK_COLUMN)
        grouped = (
            bucket_df.groupby(group_columns, dropna=False)[value_column]
            .sum()
            .reset_index()
            .rename(columns={value_column: "contribution"})
        )
        grouped = grouped.reindex(
            grouped["contribution"].abs().sort_values(ascending=False, kind="mergesort").index
        ).reset_index(drop=True)
        grouped = _add_contribution_shares(grouped, total_delta=denominator)
        for rank_val, (_, row) in enumerate(grouped.iterrows(), start=1):
            output_row: dict[str, object] = {
                axis_column: row[axis_column],
                "contribution": float(row["contribution"]),
                "share_of_total_delta": row["share_of_total_delta"],
                "share_of_positive_pool": row["share_of_positive_pool"],
                "share_of_negative_pool": row["share_of_negative_pool"],
                _ATTRIBUTION_TOTAL_DELTA_COLUMN: denominator,
                "rank": rank_val,
            }
            if top_k_map is not None:
                output_row[ATTRIBUTION_OTHER_MASK_COLUMN] = int(row[ATTRIBUTION_OTHER_MASK_COLUMN])
            if bucket_column is not None:
                output_row[bucket_column] = bucket_value
            rows.append(output_row)

    columns = [
        axis_column,
        "contribution",
        "share_of_total_delta",
        "share_of_positive_pool",
        "share_of_negative_pool",
        _ATTRIBUTION_TOTAL_DELTA_COLUMN,
        "rank",
    ]
    if top_k_map is not None:
        columns.insert(1, ATTRIBUTION_OTHER_MASK_COLUMN)
    if bucket_column is not None:
        columns = [bucket_column, *columns]
    output = pd.DataFrame(rows)
    if output.empty:
        output = pd.DataFrame(columns=columns)
    elif top_k_map is not None:
        output[axis_column] = output[axis_column].astype(df[axis_column].dtype)
    return output[columns]


def _joint_sum_output_for_df(
    df: pd.DataFrame,
    *,
    axis_columns: list[str],
    value_column: str,
) -> pd.DataFrame:
    """Aggregate an additive delta once for every complete axis combination."""
    output = (
        df.groupby(axis_columns, dropna=False, sort=False)[value_column]
        .sum()
        .reset_index()
        .rename(columns={value_column: "contribution"})
    )
    output["value_effect"] = output["contribution"]
    output["mix_effect"] = 0.0
    output["residual"] = 0.0
    total = float(output["contribution"].sum())
    output = _add_contribution_shares(output, total_delta=total)
    output = output.reindex(
        output["contribution"].abs().sort_values(ascending=False).index
    ).reset_index(drop=True)
    output["rank"] = range(1, len(output) + 1)
    return output[
        [
            *axis_columns,
            "contribution",
            "share_of_total_delta",
            "share_of_positive_pool",
            "share_of_negative_pool",
            "value_effect",
            "mix_effect",
            "residual",
            _ATTRIBUTION_TOTAL_DELTA_COLUMN,
            "rank",
        ]
    ]


def _multi_axis_joint_sum_output(
    df: pd.DataFrame,
    *,
    axis_columns: list[str],
    value_column: str,
    bucket_column: str | None = None,
) -> pd.DataFrame:
    """Apply joint additive attribution independently for each panel bucket."""
    if bucket_column is None:
        return _joint_sum_output_for_df(df, axis_columns=axis_columns, value_column=value_column)
    pieces: list[pd.DataFrame] = []
    for bucket_value, bucket_df in df.groupby(bucket_column, dropna=False, sort=True):
        piece = _joint_sum_output_for_df(
            bucket_df, axis_columns=axis_columns, value_column=value_column
        )
        piece.insert(0, bucket_column, bucket_value)
        pieces.append(piece)
    if not pieces:
        columns = [
            bucket_column,
            *axis_columns,
            "contribution",
            "share_of_total_delta",
            "share_of_positive_pool",
            "share_of_negative_pool",
            "value_effect",
            "mix_effect",
            "residual",
            _ATTRIBUTION_TOTAL_DELTA_COLUMN,
            "rank",
        ]
        return pd.DataFrame(columns=columns)
    return pd.concat(pieces, ignore_index=True)


def _multi_axis_hierarchy_output(
    df: pd.DataFrame,
    *,
    axis_columns: list[str],
    value_column: str,
    bucket_column: str | None = None,
    top_k_map: AttributionTopKMapV1 | None = None,
) -> pd.DataFrame:
    """Emit additive hierarchy rows while retaining every requested axis column."""
    rows: list[dict[str, object]] = []
    bucket_values: list[object] = [None]
    if bucket_column is not None:
        bucket_values = list(df[bucket_column].drop_duplicates())
    for bucket_value in bucket_values:
        bucket_df = df if bucket_column is None else df[df[bucket_column] == bucket_value]
        denominator = float(bucket_df[value_column].sum())
        for level in range(1, len(axis_columns) + 1):
            prefix = axis_columns[:level]
            level_df = (
                top_k_map.map_frame(bucket_df, level=level) if top_k_map is not None else bucket_df
            )
            group_columns = [*prefix]
            if top_k_map is not None:
                group_columns.append(ATTRIBUTION_OTHER_MASK_COLUMN)
            grouped = (
                level_df.groupby(group_columns, dropna=False)[value_column]
                .sum()
                .reset_index()
                .rename(columns={value_column: "contribution"})
            )
            grouped = grouped.sort_values(
                "contribution", key=lambda values: values.abs(), ascending=False, kind="mergesort"
            ).reset_index(drop=True)
            grouped = _add_contribution_shares(grouped, total_delta=denominator)
            for rank, (_, row) in enumerate(grouped.iterrows(), start=1):
                contribution = float(row["contribution"])
                output_row: dict[str, object] = {
                    ATTRIBUTION_LEVEL_COLUMN: level,
                    ATTRIBUTION_AXIS_COLUMN: axis_columns[level - 1],
                    ATTRIBUTION_DRIVER_COLUMN: _hierarchy_display_value(
                        row, axis_columns[level - 1], level - 1
                    ),
                    ATTRIBUTION_PATH_COLUMN: " > ".join(
                        _path_segment(_hierarchy_display_value(row, column, index))
                        for index, column in enumerate(prefix)
                    ),
                    "contribution": contribution,
                    "share_of_total_delta": row["share_of_total_delta"],
                    "share_of_positive_pool": row["share_of_positive_pool"],
                    "share_of_negative_pool": row["share_of_negative_pool"],
                    "value_effect": contribution,
                    "mix_effect": 0.0,
                    "residual": 0.0,
                    _ATTRIBUTION_TOTAL_DELTA_COLUMN: denominator,
                    "rank": rank,
                }
                for axis_column in axis_columns:
                    output_row[axis_column] = row[axis_column] if axis_column in prefix else pd.NA
                if top_k_map is not None:
                    output_row[ATTRIBUTION_OTHER_MASK_COLUMN] = int(
                        row[ATTRIBUTION_OTHER_MASK_COLUMN]
                    )
                if bucket_column is not None:
                    output_row[bucket_column] = bucket_value
                rows.append(output_row)
    columns = [
        ATTRIBUTION_LEVEL_COLUMN,
        ATTRIBUTION_AXIS_COLUMN,
        ATTRIBUTION_DRIVER_COLUMN,
        ATTRIBUTION_PATH_COLUMN,
        *axis_columns,
        "contribution",
        "share_of_total_delta",
        "share_of_positive_pool",
        "share_of_negative_pool",
        "value_effect",
        "mix_effect",
        "residual",
        _ATTRIBUTION_TOTAL_DELTA_COLUMN,
        "rank",
    ]
    if top_k_map is not None:
        columns.insert(4 + len(axis_columns), ATTRIBUTION_OTHER_MASK_COLUMN)
    if bucket_column is not None:
        columns = [bucket_column, *columns]
    output = pd.DataFrame(rows)
    if output.empty:
        output = pd.DataFrame(columns=columns)
    return output[columns]


def _additive_top_k_map(
    frame: DeltaFrame,
    *,
    axis_columns: list[str],
    top_k: int | None,
    component: ComponentFrame | None,
) -> tuple[AttributionTopKMapV1 | None, AttributionTopKSelectionV1 | None]:
    if top_k is None:
        return None, None
    if component is None:
        source = frame._dataframe_copy()
        current_column = "current"
        baseline_column = "baseline"
        score_method: Literal["metric_magnitude", "denominator_exposure", "weight_exposure"] = (
            "metric_magnitude"
        )
    else:
        source = component._dataframe_copy()
        if component.meta.composition_kind == "linear":
            value_name = _infer_delta_value_column_name(component)
            current_column = f"current_{value_name}"
            baseline_column = f"baseline_{value_name}"
            score_method = "metric_magnitude"
        else:
            role = _component_measure_role(component)
            current_column = f"current_{role}"
            baseline_column = f"baseline_{role}"
            score_method = (
                "weight_exposure"
                if component.meta.composition_kind == "weighted_mean"
                else "denominator_exposure"
            )
    current_scores = source[[*axis_columns, current_column]].rename(
        columns={current_column: "__top_k_score"}
    )
    baseline_scores = source[[*axis_columns, baseline_column]].rename(
        columns={baseline_column: "__top_k_score"}
    )
    mapping = build_top_k_map(
        current_scores,
        baseline_scores,
        axis_columns=axis_columns,
        score_column="__top_k_score",
        limit=top_k,
    )
    return mapping, AttributionTopKSelectionV1(
        limit=top_k,
        score_method=score_method,
        original_partition_count=mapping.original_scope_count,
        effective_partition_count=mapping.collapsed_scope_count,
    )


def _decompose(
    frame: DeltaFrame,
    *,
    axes: list[_SemanticInput[DimensionKind | TimeDimensionKind]] | None = None,
    axis: _SemanticInput[DimensionKind | TimeDimensionKind] | None = None,
    mode: AttributionMode | None = None,
    session: Session | None = None,
    _intent: str = "decompose",
    _analysis_purpose: str | None = None,
    _params_extra: dict[str, object] | None = None,
    _method_evidence: AttributionMethodEvidenceV1 | None = None,
    _top_k: int | None = None,
    _scope_frame: DeltaFrame | None = None,
    _materialization_sources: tuple[BaseFrame, ...] = (),
) -> AttributionFrame:
    session = resolve_session(session)
    ensure_session_can_execute(session)
    if not isinstance(frame, DeltaFrame):
        raise SemanticKindMismatchError(message="decompose requires a DeltaFrame input")
    if not isinstance(frame.meta, DeltaFrameMeta):
        raise SemanticKindMismatchError(
            message="decompose requires a metric DeltaFrame; DeltaFrame[funnel] has no "
            "component or additivity contract to decompose",
            context={"semantic_kind": frame.meta.semantic_kind},
        )
    if frame.meta.cumulative is not None and not (
        _intent == "attribute" and isinstance(frame.meta, CumulativeDeltaFrameMetaV1)
    ):
        raise CumulativeFrameUnsupportedError(
            intent=_intent,
            frame_ref=frame.ref,
            metric_id=frame.meta.metric_id,
            cumulative=frame.meta.cumulative,
        )
    axis_ids = _normalize_axes_boundary(session, axes, axis)
    validated_mode = validate_attribution_mode(axis_ids, mode, intent="decompose")
    params_extra = dict(_params_extra or {})
    if _top_k is not None:
        params_extra["top_k"] = _top_k
    ensure_frame_in_session(frame, session=session, label="decompose frame")
    persistence_sources: list[BaseFrame] = []
    seen_source_refs: set[str] = set()
    for source in (
        *(() if _scope_frame is None else (_scope_frame,)),
        frame,
        *_materialization_sources,
    ):
        source_ref = source.meta.artifact_id or source.ref
        if source_ref not in seen_source_refs:
            ensure_frame_in_session(source, session=session, label="decompose source")
            persistence_sources.append(source)
            seen_source_refs.add(source_ref)
    if frame.meta.semantic_kind not in {"scalar", "time_series", "segmented", "panel"}:
        raise SemanticKindMismatchError(
            message=f"decompose does not support semantic_kind={frame.meta.semantic_kind!r}",
        )

    component = _validate_attribution_semantics(frame, axes=axis_ids, session=session)

    coverage_warnings = _mean_fold_coverage_warning(frame, session)

    started_at = datetime.now(UTC)
    started = monotonic()
    source_df = frame._dataframe_copy()
    value_column = require_numeric_column(source_df, "delta", purpose="decompose")
    raise_first(validate_decompose_axes_columns(frame, axis_ids, source_df=source_df))
    axis_columns = _axis_columns_for_delta(frame, axis_ids, source_df=source_df)

    # Component-aware path: ratio/weighted mix or linear additive attribution.
    if component is not None:
        component_columns = [str(column) for column in component._dataframe_copy().columns]
        component_axis_columns: list[str] = []
        missing_component_axes: list[str] = []
        for axis_id, axis_column in zip(axis_ids, axis_columns, strict=True):
            component_axis_column = _effective_component_axis_column(
                frame, axis_id, component_columns
            )
            if component_axis_column is None and axis_column in component_columns:
                component_axis_column = axis_column
            if component_axis_column is None:
                missing_component_axes.append(axis_id)
            else:
                component_axis_columns.append(component_axis_column)
        if missing_component_axes:
            raise ComponentDecompositionError(
                message="component-aware decompose could not resolve every requested axis",
                context={
                    "delta_ref": frame.ref,
                    "component_ref": component.ref,
                    "axes": axis_ids,
                    "missing_axes": missing_component_axes,
                    "available_component_columns": component_columns,
                },
            )
        top_k_map, top_k_selection = _additive_top_k_map(
            frame,
            axis_columns=component_axis_columns,
            top_k=_top_k,
            component=component,
        )
        bucket_column = None
        if frame.meta.semantic_kind == "panel":
            bucket_column = _component_bucket_column(frame, component_columns)
            if bucket_column is None:
                raise ComponentDecompositionError(
                    message="component-aware panel decompose requires a bucket column",
                    context={"delta_ref": frame.ref, "component_ref": component.ref},
                )
        # Validate against the columns this component path actually writes:
        # base protocol fields, value/mix/residual effects, component share
        # fields, the current_/baseline_ component role columns, and (for
        # multi-axis) the hierarchy row-layout fields.
        component_extra_reserved = set(_ATTRIBUTION_EFFECT_RESERVED_COLUMNS)
        component_extra_reserved.update(_ATTRIBUTION_COMPONENT_SHARE_RESERVED_COLUMNS)
        component_extra_reserved.update(
            column for column in component_columns if column.startswith(("current_", "baseline_"))
        )
        if validated_mode is not None:
            component_extra_reserved.update(_ATTRIBUTION_HIERARCHY_RESERVED_COLUMNS)
        _validate_attribution_axis_columns(
            component_axis_columns,
            value_column=value_column,
            bucket_column=bucket_column,
            extra_reserved_columns=component_extra_reserved,
        )
        if validated_mode is None and top_k_map is not None:
            output = _component_multi_axis_output(
                component=component,
                axis_columns=component_axis_columns,
                mode="joint",
                bucket_column=bucket_column,
                top_k_map=top_k_map,
            )
            method = (
                "sum"
                if component.meta.composition_kind == "linear"
                else _component_method(component)
            )
        elif validated_mode is None and component.meta.composition_kind == "linear":
            output = _component_linear_output_for_df(
                df=component._dataframe_copy(),
                component=component,
                axis_column=component_axis_columns[0],
            )
            method = "sum"
        elif validated_mode is None:
            output = _component_mix_output(
                component=component,
                axis_column=component_axis_columns[0],
                bucket_column=bucket_column,
            )
            method = _component_method(component)
        else:
            output = _component_multi_axis_output(
                component=component,
                axis_columns=component_axis_columns,
                mode=validated_mode,
                bucket_column=bucket_column,
                top_k_map=top_k_map,
            )
            method = (
                "sum"
                if component.meta.composition_kind == "linear"
                else _component_method(component)
            )
        output, reconciliation = _finalize_attribution_output(
            output,
            bucket_column=bucket_column,
            deepest_only=validated_mode == "hierarchy",
        )
        driver_field = (
            component_axis_columns[0]
            if validated_mode is None
            else ATTRIBUTION_PATH_COLUMN
            if validated_mode == "hierarchy"
            else None
        )
        params: dict[str, Any] = {
            "source_ref": frame.ref,
            "component_ref": component.ref,
            "axes": axis_ids,
            "axis_columns": component_axis_columns,
            "measure_column": "delta",
            "driver_field": driver_field,
            "value_column": "delta",
            "contribution_column": "contribution",
            "method": method,
        }
        params.update(params_extra)
        return persist_attribution_frame(
            session=session,
            df=output,
            intent=_intent,
            params=params,
            sources=persistence_sources,
            metric_ids=[frame.meta.metric_id],
            attribution_kind="decomposition",
            driver_field=driver_field,
            value_column="delta",
            contribution_column="contribution",
            method=method,
            semantic_kind=frame.meta.semantic_kind,
            semantic_model=frame.meta.semantic_model,
            started_at=started_at,
            started_monotonic=started,
            analysis_purpose=_analysis_purpose,
            extra_issues=coverage_warnings,
            reconciliation=reconciliation,
            axis_ids=axis_ids,
            axis_columns=component_axis_columns,
            mode=validated_mode,
            bucket_column=bucket_column,
            method_evidence=_method_evidence,
            top_k_selection=top_k_selection,
        )

    top_k_map, top_k_selection = _additive_top_k_map(
        frame,
        axis_columns=axis_columns,
        top_k=_top_k,
        component=None,
    )
    if validated_mode is not None:
        bucket_column = (
            _bucket_column_for_panel(frame) if frame.meta.semantic_kind == "panel" else None
        )
        # Multi-axis additive joint/hierarchy emits value/mix/residual effects;
        # hierarchy additionally emits the level/axis/driver/path layout fields.
        multi_axis_extra_reserved = set(_ATTRIBUTION_EFFECT_RESERVED_COLUMNS)
        if validated_mode == "hierarchy":
            multi_axis_extra_reserved.update(_ATTRIBUTION_HIERARCHY_RESERVED_COLUMNS)
        _validate_attribution_axis_columns(
            axis_columns,
            value_column=value_column,
            bucket_column=bucket_column,
            extra_reserved_columns=multi_axis_extra_reserved,
        )
        if validated_mode == "joint":
            joint_df = top_k_map.map_frame(source_df) if top_k_map is not None else source_df
            joint_axes = [*axis_columns]
            if top_k_map is not None:
                joint_axes.append(ATTRIBUTION_OTHER_MASK_COLUMN)
            output = _multi_axis_joint_sum_output(
                joint_df,
                axis_columns=joint_axes,
                value_column=value_column,
                bucket_column=bucket_column,
            )
            driver_field = None
            method = "sum"
        else:
            output = _multi_axis_hierarchy_output(
                source_df,
                axis_columns=axis_columns,
                value_column=value_column,
                bucket_column=bucket_column,
                top_k_map=top_k_map,
            )
            driver_field = ATTRIBUTION_PATH_COLUMN
            method = "sum"
        output, reconciliation = _finalize_attribution_output(
            output,
            bucket_column=bucket_column,
            deepest_only=validated_mode == "hierarchy",
        )
        params = {
            "source_ref": frame.ref,
            "axes": axis_ids,
            "axis_columns": axis_columns,
            "measure_column": value_column,
            "bucket_column": bucket_column,
            "driver_field": driver_field,
            "value_column": value_column,
            "contribution_column": "contribution",
            "method": method,
            "mode": validated_mode,
        }
        params.update(params_extra)
        return persist_attribution_frame(
            session=session,
            df=output,
            intent=_intent,
            params=params,
            sources=persistence_sources,
            metric_ids=[frame.meta.metric_id],
            attribution_kind="decomposition",
            driver_field=driver_field,
            value_column=value_column,
            contribution_column="contribution",
            method=method,
            semantic_kind=frame.meta.semantic_kind,
            semantic_model=frame.meta.semantic_model,
            started_at=started_at,
            started_monotonic=started,
            analysis_purpose=_analysis_purpose,
            extra_issues=coverage_warnings,
            reconciliation=reconciliation,
            axis_ids=axis_ids,
            axis_columns=axis_columns,
            mode=validated_mode,
            bucket_column=bucket_column,
            method_evidence=_method_evidence,
            top_k_selection=top_k_selection,
        )

    if frame.meta.semantic_kind == "panel":
        bucket_column = _bucket_column_for_panel(frame)
        axis_column = axis_columns[0]
        output = _single_axis_sum_output(
            source_df,
            axis_column=axis_column,
            value_column=value_column,
            bucket_column=bucket_column,
            top_k_map=top_k_map,
        )
        output, reconciliation = _finalize_attribution_output(
            output,
            bucket_column=bucket_column,
        )
        params = {
            "source_ref": frame.ref,
            "axes": axis_ids,
            "axis_columns": axis_columns,
            "measure_column": value_column,
            "bucket_column": bucket_column,
            "driver_field": axis_column,
            "value_column": value_column,
            "contribution_column": "contribution",
            "method": "sum",
        }
        params.update(params_extra)
        return persist_attribution_frame(
            session=session,
            df=output,
            intent=_intent,
            params=params,
            sources=persistence_sources,
            metric_ids=[frame.meta.metric_id],
            attribution_kind="decomposition",
            driver_field=axis_column,
            value_column=value_column,
            contribution_column="contribution",
            method="sum",
            semantic_kind=frame.meta.semantic_kind,
            semantic_model=frame.meta.semantic_model,
            started_at=started_at,
            started_monotonic=started,
            analysis_purpose=_analysis_purpose,
            extra_issues=coverage_warnings,
            reconciliation=reconciliation,
            axis_ids=axis_ids,
            axis_columns=axis_columns,
            mode=None,
            bucket_column=bucket_column,
            method_evidence=_method_evidence,
            top_k_selection=top_k_selection,
        )

    axis_column = axis_columns[0]
    output = _single_axis_sum_output(
        source_df,
        axis_column=axis_column,
        value_column=value_column,
        top_k_map=top_k_map,
    )
    output, reconciliation = _finalize_attribution_output(output, bucket_column=None)
    params = {
        "source_ref": frame.ref,
        "axes": axis_ids,
        "axis_columns": axis_columns,
        "measure_column": value_column,
        "driver_field": axis_column,
        "value_column": value_column,
        "contribution_column": "contribution",
        "method": "sum",
    }
    params.update(params_extra)
    return persist_attribution_frame(
        session=session,
        df=output,
        intent=_intent,
        params=params,
        sources=persistence_sources,
        metric_ids=[frame.meta.metric_id],
        attribution_kind="decomposition",
        driver_field=axis_column,
        value_column=value_column,
        contribution_column="contribution",
        method="sum",
        semantic_kind=frame.meta.semantic_kind,
        semantic_model=frame.meta.semantic_model,
        started_at=started_at,
        started_monotonic=started,
        analysis_purpose=_analysis_purpose,
        extra_issues=coverage_warnings,
        reconciliation=reconciliation,
        axis_ids=axis_ids,
        axis_columns=axis_columns,
        mode=None,
        bucket_column=None,
        method_evidence=_method_evidence,
        top_k_selection=top_k_selection,
    )


def decompose(
    frame: DeltaFrame,
    *,
    axes: list[_SemanticInput[DimensionKind | TimeDimensionKind]] | None = None,
    axis: _SemanticInput[DimensionKind | TimeDimensionKind] | None = None,
    mode: AttributionMode | None = None,
    session: Session | None = None,
    _intent: str = "decompose",
    _analysis_purpose: str | None = None,
    _params_extra: dict[str, object] | None = None,
) -> AttributionFrame:
    """Decompose one delta without accepting hidden method-evidence injection."""

    return _decompose(
        frame,
        axes=axes,
        axis=axis,
        mode=mode,
        session=session,
        _intent=_intent,
        _analysis_purpose=_analysis_purpose,
        _params_extra=_params_extra,
    )
