"""Graph-native logical and physical planning for metric observation."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, TypeAlias

from marivo.analysis.errors import WindowInvalidError
from marivo.analysis.intents._observe_planner_base import plan_base_observe
from marivo.analysis.intents._observe_planner_types import (
    BaseObservePlan,
    CumulativePhysicalLeafPlanV1,
)
from marivo.analysis.intents._runtime_metric_lowering import lower_metric_inputs
from marivo.analysis.intents.observe_errors import (
    ObservePlanningError,
    RepairAction,
    RepairSafety,
    raise_observe_planning_error,
)
from marivo.analysis.runtime_metric import RuntimeMetricExpr
from marivo.refs import MetricKind, Ref, RefPayloadV1, SemanticKind
from marivo.refs import ref as ref_factory
from marivo.semantic._filter_runtime import authored_filter_predicate
from marivo.semantic._metric_resolution import (
    fold_input_to_ir,
    fold_ir_to_input,
    resolve_aggregate_temporal_contract,
    resolve_measure_aggregate_additivity,
)
from marivo.semantic.catalog import (
    DerivedMetricDetails,
    SemanticCatalog,
    SimpleMetricDetails,
)
from marivo.semantic.ir import (
    CumulativeComposition,
    TimeFoldIR,
    additivity_bucket,
)
from marivo.semantic.metric_graph import (
    AggregateNodeV1,
    CatalogBodyLeafV1,
    CumulativeNodeV1,
    DatasourceCompatibilityDomainV1,
    MetricExpressionGraphV1,
    MetricGraphNodeV1,
    SliceNodeV1,
    WeightedMeanAggregateNodeV1,
    node_child_ids,
)
from marivo.semantic.metric_graph_canonical import canonical_value, fingerprint
from marivo.semantic.metric_graph_lowering import (
    MetricExpressionForestV1,
    lower_catalog_metric,
    lower_catalog_metrics,
)
from marivo.semantic.unit_algebra import tier1_unit

if TYPE_CHECKING:
    from marivo.analysis.intents._subject_cohort import ResolvedSubjectCohort

PhysicalLeafPlanV1: TypeAlias = BaseObservePlan | CumulativePhysicalLeafPlanV1


@dataclass(frozen=True)
class ResolvedMetricLeafV1:
    """One physical graph node and the governed metric used to execute it."""

    node_id: str
    value_node_id: str
    occurrence_roles: tuple[str, ...]
    metric_id: str
    metric_ir: Any
    node: MetricGraphNodeV1
    plan: PhysicalLeafPlanV1


@dataclass(frozen=True)
class MetricGraphObservePlanV1:
    """A canonical forest plus one reusable plan per physical value node."""

    forest: MetricExpressionForestV1
    leaves: tuple[ResolvedMetricLeafV1, ...]
    datasource_name: str
    source_domain: DatasourceCompatibilityDomainV1
    lineage_metadata: dict[str, Any]
    warnings: tuple[dict[str, Any], ...]

    @property
    def graph(self) -> MetricExpressionGraphV1:
        return self.forest.graph


@dataclass(frozen=True)
class _RuntimeAggregateMetricAdapter:
    semantic_id: str
    name: str
    domain: str
    root_entity: str
    entities: tuple[str, ...]
    aggregation: Any
    measure: str
    additivity: str
    unit: str | None
    time_fold: TimeFoldIR | None
    status_time_dimension: str | None
    runtime_measure_id: str
    metric_type: str = "simple"
    composition: None = None
    fanout_policy: str = "block"


@dataclass(frozen=True)
class _RuntimeWeightedMeanSpecAdapter:
    value: str
    weight: str


@dataclass(frozen=True)
class _RuntimeWeightedMeanMetricAdapter:
    semantic_id: str
    name: str
    domain: str
    root_entity: str
    entities: tuple[str, ...]
    weighted_mean: _RuntimeWeightedMeanSpecAdapter
    additivity: str
    unit: str | None
    aggregation: None = None
    measure: None = None
    time_fold: None = None
    status_time_dimension: None = None
    metric_type: str = "simple"
    composition: None = None
    fanout_policy: str = "block"


def _runtime_metric_adapter(catalog: SemanticCatalog, node_id: str, node: AggregateNodeV1) -> Any:
    if node.target_ref.kind is not SemanticKind.MEASURE:
        raise_observe_planning_error(
            code="runtime-metric-target-kind",
            message="Runtime aggregate nodes require a governed measure target.",
            candidates={
                "target_kind": node.target_ref.kind.value,
                "target_ref": node.target_ref.to_dict(),
            },
            repair=[],
        )
    registry = catalog._require_index().registry
    measure = registry.measures.get(node.target_ref.path)
    if measure is None:
        raise_observe_planning_error(
            code="runtime-metric-measure-missing",
            message=f"Runtime aggregate measure {node.target_ref.path!r} is not loaded.",
            candidates={"measure_ref": node.target_ref.to_dict()},
            repair=[],
        )
    temporal_contract = resolve_aggregate_temporal_contract(
        measure.additivity,
        fold_override=fold_input_to_ir(node.fold),
    )
    resolved_additivity = resolve_measure_aggregate_additivity(node.agg, measure.additivity)
    return _RuntimeAggregateMetricAdapter(
        semantic_id=f"runtime.{node_id}",
        name="runtime_value",
        domain=measure.domain,
        root_entity=measure.entity,
        entities=(measure.entity,),
        aggregation=node.agg,
        measure=measure.semantic_id,
        additivity=additivity_bucket(resolved_additivity or "non_additive"),
        unit=node.unit_override
        or tier1_unit(node.agg[0] if isinstance(node.agg, tuple) else node.agg, measure.unit),
        time_fold=temporal_contract.fold if temporal_contract is not None else None,
        status_time_dimension=(
            temporal_contract.status_time_dimension if temporal_contract is not None else None
        ),
        runtime_measure_id=measure.semantic_id,
    )


def _validate_aggregate_temporal_contract(node: AggregateNodeV1, metric_ir: Any) -> None:
    """Fail closed when graph and executable metric temporal semantics diverge."""

    time_fold = getattr(metric_ir, "time_fold", None)
    adapter_fold = fold_ir_to_input(time_fold)
    status_time_dimension = getattr(metric_ir, "status_time_dimension", None)
    if node.fold == adapter_fold and (node.fold is None or status_time_dimension):
        return
    raise_observe_planning_error(
        code="metric-temporal-contract-drift",
        message="Metric graph and executable temporal-fold semantics do not match.",
        candidates={
            "graph_fold": node.fold,
            "adapter_fold": adapter_fold,
            "status_time_dimension": status_time_dimension,
            "metric": getattr(metric_ir, "semantic_id", None),
        },
        repair=[],
    )


def _runtime_weighted_mean_adapter(
    catalog: SemanticCatalog,
    node_id: str,
    node: WeightedMeanAggregateNodeV1,
) -> _RuntimeWeightedMeanMetricAdapter:
    registry = catalog._require_index().registry
    value = registry.measures.get(node.value_ref.path)
    weight = registry.measures.get(node.weight_ref.path)
    if value is None or weight is None:
        raise_observe_planning_error(
            code="runtime-weighted-mean-measure-missing",
            message="Runtime weighted_mean requires both governed measures to be loaded.",
            candidates={
                "value_ref": node.value_ref.to_dict(),
                "weight_ref": node.weight_ref.to_dict(),
            },
            repair=[],
        )
    if value.entity != weight.entity:
        weight_candidates = sorted(
            measure.semantic_id
            for measure in registry.measures.values()
            if measure.entity == value.entity and measure.additivity == "additive"
        )
        raise_observe_planning_error(
            code="runtime-weighted-mean-grain-mismatch",
            message=(
                "Runtime weighted_mean value and weight must belong to the same entity "
                "and physical row grain."
            ),
            candidates={
                "value_entity": value.entity,
                "weight_entity": weight.entity,
                "additive_weight_refs": weight_candidates,
            },
            repair=(
                [
                    RepairAction(
                        action="replace_measure_ref",
                        target="runtime_metric.weighted_mean",
                        arg="weight",
                        value=weight_candidates[0],
                        safety=RepairSafety.MODELING_DECISION,
                        why="the replacement is additive and shares the value measure's entity",
                    )
                ]
                if weight_candidates
                else []
            ),
        )
    if weight.additivity != "additive":
        weight_candidates = sorted(
            measure.semantic_id
            for measure in registry.measures.values()
            if measure.entity == value.entity and measure.additivity == "additive"
        )
        raise_observe_planning_error(
            code="runtime-weighted-mean-weight-non-additive",
            message="Runtime weighted_mean weight must be additive.",
            candidates={
                "weight_ref": node.weight_ref.to_dict(),
                "weight_additivity": additivity_bucket(weight.additivity),
                "additive_weight_refs": weight_candidates,
            },
            repair=(
                [
                    RepairAction(
                        action="replace_measure_ref",
                        target="runtime_metric.weighted_mean",
                        arg="weight",
                        value=weight_candidates[0],
                        safety=RepairSafety.MODELING_DECISION,
                        why="weighted_mean requires an additive weight on the value entity",
                    )
                ]
                if weight_candidates
                else []
            ),
        )
    return _RuntimeWeightedMeanMetricAdapter(
        semantic_id=f"runtime.{node_id}",
        name="runtime_value",
        domain=value.domain,
        root_entity=value.entity,
        entities=(value.entity,),
        weighted_mean=_RuntimeWeightedMeanSpecAdapter(
            value=value.semantic_id,
            weight=weight.semantic_id,
        ),
        additivity="non_additive",
        unit=node.unit_override or value.unit,
    )


def _catalog_metric_adapter(catalog: SemanticCatalog, metric_id: str) -> Any:
    from marivo.analysis.intents._observe_planner_types import _planned_metric

    details = catalog.require(ref_factory.metric(metric_id)).details()
    if not isinstance(details, (SimpleMetricDetails, DerivedMetricDetails)):
        raise_observe_planning_error(
            code="metric-graph-metric-missing",
            message=f"Metric graph representative {metric_id!r} was not found.",
            candidates={"metric": metric_id},
            repair=[],
        )
    return _planned_metric(details)


def _representative_metrics(
    catalog: SemanticCatalog,
    graph: MetricExpressionGraphV1,
) -> dict[str, str]:
    """Resolve one governed catalog representative for every executable node.

    Node fingerprints deliberately exclude catalog wrapper identity.  Choosing
    a representative is therefore a physical planning concern only; equal
    aggregates use the same node and are executed once.
    """

    registry = catalog._require_index().registry
    node_by_id = {record.node_id: record.node for record in graph.nodes}
    executable_ids: set[str] = set()

    def visit(node_id: str) -> None:
        node = node_by_id[node_id]
        if isinstance(
            node,
            (
                CatalogBodyLeafV1,
                AggregateNodeV1,
                WeightedMeanAggregateNodeV1,
                CumulativeNodeV1,
            ),
        ):
            executable_ids.add(node_id)
            return
        if isinstance(node, SliceNodeV1):
            # Runtime planning replaces a sliced leaf with a scoped physical
            # leaf. Catalog lowering currently retains governed filters on the
            # aggregate node itself, so a catalog-only forest cannot reach this
            # branch.
            visit(node.child_id)
            return
        for child_id in node_child_ids(node):
            visit(child_id)

    for root_id in graph.roots:
        visit(root_id)
    representatives: dict[str, str] = {}
    for metric_id in sorted(registry.metrics):
        metric = registry.metrics[metric_id]
        if (
            metric.metric_type == "derived"
            and getattr(metric.composition, "kind", None) != "cumulative"
        ):
            continue
        lowered = lower_catalog_metric(
            registry,
            metric_id,
            sidecar=catalog._state.sidecar,
        )
        root_id = lowered.graph.roots[0]
        if root_id in executable_ids:
            representatives.setdefault(root_id, metric_id)
    return representatives


def _canonical_slice_runtime_value(value: Any) -> Any:
    if isinstance(value, tuple):
        if (
            len(value) == 2
            and all(isinstance(item, tuple) and len(item) == 2 for item in value)
            and value[0][0] == "op"
            and value[1][0] == "value"
        ):
            return {
                "op": value[0][1],
                "value": _canonical_slice_runtime_value(value[1][1]),
            }
        return [_canonical_slice_runtime_value(item) for item in value]
    return value


def _physical_node_filter(
    node: MetricGraphNodeV1,
    *,
    nodes: dict[str, MetricGraphNodeV1],
) -> dict[Any, Any]:
    """Return authored row filters owned by one physical metric node."""
    if isinstance(node, (AggregateNodeV1, WeightedMeanAggregateNodeV1)):
        return {
            predicate.dimension_ref.path: _canonical_slice_runtime_value(predicate.value)
            for predicate in node.filter
        }
    if isinstance(node, CumulativeNodeV1):
        return _physical_node_filter(nodes[node.child_id], nodes=nodes)
    return {}


def _validate_authored_filter_types(
    *,
    node: MetricGraphNodeV1,
    registry: Any,
    session: Any,
    dataset_irs: dict[str, Any],
    dataset_fns: dict[str, Any],
    metric_id: str,
) -> None:
    """Validate authored metric filter literals against resolved Ibis field types."""
    if not isinstance(node, (AggregateNodeV1, WeightedMeanAggregateNodeV1)):
        return
    for predicate in node.filter:
        dimension_id = predicate.dimension_ref.path
        dimension = registry.dimensions.get(dimension_id)
        if dimension is None:
            continue
        dataset_ir = dataset_irs[dimension.entity]
        backend = session._connection_runtime.get_or_create(dataset_ir.datasource_name)
        table = dataset_fns[dimension.entity](backend)
        field = dataset_ir.fields[dimension.name].fn(table)
        runtime_value = _canonical_slice_runtime_value(predicate.value)
        authored_filter_predicate(
            field,
            (
                tuple(runtime_value["value"])
                if isinstance(runtime_value, dict) and runtime_value.get("op") == "in"
                else runtime_value
            ),
            metric_id=metric_id,
            dimension_id=dimension_id,
        )


def _physical_targets(
    graph: MetricExpressionGraphV1,
) -> dict[str, tuple[str, dict[str, Any]]]:
    """Map physical execution ids to underlying value nodes and local slices."""
    nodes = {record.node_id: record.node for record in graph.nodes}
    targets: dict[str, tuple[str, dict[str, Any]]] = {}

    def visit(node_id: str) -> None:
        node = nodes[node_id]
        if isinstance(
            node,
            (
                CatalogBodyLeafV1,
                AggregateNodeV1,
                WeightedMeanAggregateNodeV1,
                CumulativeNodeV1,
            ),
        ):
            targets.setdefault(
                node_id,
                (node_id, _physical_node_filter(node, nodes=nodes)),
            )
            return
        if isinstance(node, SliceNodeV1):
            child = nodes[node.child_id]
            if not isinstance(
                child,
                (
                    CatalogBodyLeafV1,
                    AggregateNodeV1,
                    WeightedMeanAggregateNodeV1,
                    CumulativeNodeV1,
                ),
            ):
                raise_observe_planning_error(
                    code="metric-graph-slice-not-leaf",
                    message="Canonical metric slices must be attached directly to physical leaves.",
                    candidates={"node_id": node_id, "child_id": node.child_id},
                    repair=[],
                )
            slice_where = {
                predicate.dimension_ref.path: _canonical_slice_runtime_value(predicate.value)
                for predicate in node.predicates
            }
            targets.setdefault(
                node_id,
                (
                    node.child_id,
                    _merge_leaf_where(
                        _physical_node_filter(child, nodes=nodes),
                        slice_where,
                    ),
                ),
            )
            return
        for child_id in node_child_ids(node):
            visit(child_id)

    for root_id in graph.roots:
        visit(root_id)
    return targets


def _merge_leaf_where(
    global_where: dict[Any, Any] | None, local_where: dict[Any, Any]
) -> dict[Any, Any]:
    merged = dict(global_where or {})
    for dimension_id, value in local_where.items():
        if dimension_id in merged and canonical_value(merged[dimension_id]) != canonical_value(
            value
        ):
            raise_observe_planning_error(
                code="metric-graph-slice-conflict",
                message=f"Global and branch-local slices conflict for {dimension_id!r}.",
                candidates={"dimension": dimension_id},
                repair=[],
            )
        merged[dimension_id] = value
    return merged


def _input_id(value: Any) -> str:
    return str(getattr(value, "id", value))


def _dimension_ref_expression(value: Any, *, kind: SemanticKind) -> str:
    dimension_id = _input_id(value)
    factory = "time_dimension" if kind is SemanticKind.TIME_DIMENSION else "dimension"
    return f"ms.ref.{factory}({dimension_id!r})"


def _dimension_grain_candidates(
    leaves: list[ResolvedMetricLeafV1],
    dimensions: list[Any],
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    """Return duplicate output-axis conflicts and single-entity grain repairs."""

    if not leaves:
        return [], []
    planned = _base_plan(leaves[0]).dimensions
    if len(planned) != len(dimensions):
        return [], []

    by_column: dict[str, list[int]] = {}
    for index, item in enumerate(planned):
        by_column.setdefault(item.column, []).append(index)

    conflicts: list[dict[str, Any]] = []
    conflicting_indices: set[int] = set()
    common_entities: set[str] | None = None
    for column, indices in by_column.items():
        refs = [_input_id(dimensions[index]) for index in indices]
        entities = [ref_id.rsplit(".", 1)[0] for ref_id in refs]
        unique_entities = set(entities)
        if len(set(refs)) < 2 or len(unique_entities) < 2:
            continue
        conflicts.append({"column": column, "refs": refs})
        conflicting_indices.update(indices)
        common_entities = (
            unique_entities if common_entities is None else common_entities & unique_entities
        )

    if not conflicts or not common_entities:
        return conflicts, []

    entity_order: list[str] = []
    for index in sorted(conflicting_indices):
        entity = _input_id(dimensions[index]).rsplit(".", 1)[0]
        if entity in common_entities and entity not in entity_order:
            entity_order.append(entity)

    candidates: list[dict[str, Any]] = []
    for entity in entity_order[:4]:
        selected_indices: list[int] = []
        seen_conflict_columns: set[str] = set()
        for index, dimension in enumerate(dimensions):
            if index not in conflicting_indices:
                selected_indices.append(index)
                continue
            dimension_id = _input_id(dimension)
            column = planned[index].column
            if dimension_id.rsplit(".", 1)[0] == entity and column not in seen_conflict_columns:
                selected_indices.append(index)
                seen_conflict_columns.add(column)
        if len(seen_conflict_columns) != len(conflicts):
            continue
        candidate_ids = [_input_id(dimensions[index]) for index in selected_indices]
        snippet = (
            "dimensions=["
            + ", ".join(
                _dimension_ref_expression(dimensions[index], kind=planned[index].field.ref.kind)
                for index in selected_indices
            )
            + "]"
        )
        candidates.append(
            {
                "entity": entity,
                "dimensions": candidate_ids,
                "snippet": snippet,
            }
        )
    return conflicts, candidates


def _base_plan(leaf: ResolvedMetricLeafV1) -> BaseObservePlan:
    return leaf.plan.base_plan if isinstance(leaf.plan, CumulativePhysicalLeafPlanV1) else leaf.plan


def _raise_unreachable_scope(
    failures: list[tuple[str, ObservePlanningError]],
    leaves: list[ResolvedMetricLeafV1],
    *,
    dimensions: list[Any] | None,
    where: dict[Any, Any] | None,
) -> None:
    """Turn per-leaf path failures into one graph-level scope blocker."""

    missing_components = [metric_id for metric_id, _exc in failures]
    failure_causes = [
        {
            "metric": metric_id,
            "code": exc._context.get("code"),
            "candidates": exc._context.get("candidates", {}),
        }
        for metric_id, exc in failures
    ]
    if dimensions:
        dimension_id = _input_id(dimensions[0])
        column = dimension_id.rsplit(".", 1)[-1]
        resolved_components = [
            {
                "metric": leaf.metric_id,
                "resolved_field_id": planned.field.semantic_id,
            }
            for leaf in leaves
            for planned in _base_plan(leaf).dimensions
            if planned.column == column
        ]
        raise_observe_planning_error(
            code="component-axis-unreachable",
            message=f"Observation dimension {dimension_id!r} cannot be resolved by every leaf.",
            candidates={
                "dimension": dimension_id,
                "missing_components": missing_components,
                "resolved_components": resolved_components,
                "failure_causes": failure_causes,
            },
            repair=[],
        )
    if where:
        raw_key = next(iter(where))
        filter_key = _input_id(raw_key)
        resolved_components = [
            {
                "metric": leaf.metric_id,
                "resolved_field_id": planned.field.semantic_id,
            }
            for leaf in leaves
            for planned in _base_plan(leaf).where
            if planned.original_key == filter_key
        ]
        raise_observe_planning_error(
            code="component-filter-unreachable",
            message=f"Observation filter {filter_key!r} cannot be applied by every leaf.",
            candidates={
                "filter_key": filter_key,
                "missing_components": missing_components,
                "resolved_components": resolved_components,
                "failure_causes": failure_causes,
            },
            repair=[],
        )
    raise failures[0][1]


def _validate_leaf_comparability(
    leaves: list[ResolvedMetricLeafV1],
    *,
    dimensions: list[Any] | None,
    where: dict[Any, Any] | None,
) -> None:
    """Validate the shared axes, filters, and snapshot resolution of all leaves."""

    conflicts, grain_candidates = _dimension_grain_candidates(leaves, dimensions or [])
    if conflicts and grain_candidates:
        primary_column = conflicts[0]["column"]
        resolved_components = [
            {"metric": leaf.metric_id, "resolved_field_id": planned.field.semantic_id}
            for leaf in leaves
            for planned in _base_plan(leaf).dimensions
            if planned.column == primary_column
        ]
        relationship_ids = sorted(
            {
                relationship["relationship"]
                for leaf in leaves
                for relationship in _base_plan(leaf).lineage_metadata.get("relationships", [])
                if isinstance(relationship, dict)
                and isinstance(relationship.get("relationship"), str)
            }
        )
        conflict_text = "; ".join(
            f"{item['column']}: {', '.join(item['refs'])}" for item in conflicts
        )
        relationship_text = ", ".join(relationship_ids) or "the planned relationship path"
        retry_text = grain_candidates[0]["snippet"]
        if len(grain_candidates) > 1:
            retry_text += f"; alternative: {grain_candidates[1]['snippet']}"
        repairs = [
            RepairAction(
                action="replace_dimensions",
                target="session.observe",
                arg="dimensions",
                value=candidate["dimensions"],
                safety=RepairSafety.MODELING_DECISION,
                why=(
                    f"use {candidate['entity']!r} as the single output grain across "
                    f"relationship path {relationship_text}"
                ),
            )
            for candidate in grain_candidates
        ]
        raise_observe_planning_error(
            code="component-axis-field-mismatch",
            message=(
                "Observation dimensions define duplicate output axes across metric leaves "
                f"({conflict_text}). Planned relationships already connect the entities: "
                f"{relationship_text}. Choose one entity side as the output grain and retry "
                f"with {retry_text}."
            ),
            candidates={
                "dimension": conflicts[0]["refs"][0],
                "components": resolved_components,
                "conflicts": conflicts,
                "relationships": relationship_ids,
                "output_grain_candidates": grain_candidates,
            },
            repair=repairs,
        )

    for raw_dimension in dimensions or ():
        dimension_id = _input_id(raw_dimension)
        column = dimension_id.rsplit(".", 1)[-1]
        resolved = [
            (leaf.metric_id, planned.field.semantic_id)
            for leaf in leaves
            for planned in _base_plan(leaf).dimensions
            if planned.column == column
        ]
        field_ids = {field_id for _metric_id, field_id in resolved}
        if len(field_ids) > 1:
            raise_observe_planning_error(
                code="component-axis-field-mismatch",
                message=f"Dimension {dimension_id!r} resolves differently across leaves.",
                candidates={
                    "dimension": dimension_id,
                    "components": [
                        {"metric": metric_id, "resolved_field_id": field_id}
                        for metric_id, field_id in resolved
                    ],
                },
                repair=[],
            )
    for raw_key in where or ():
        filter_key = _input_id(raw_key)
        resolved = [
            (leaf.metric_id, planned.field.semantic_id)
            for leaf in leaves
            for planned in _base_plan(leaf).where
            if planned.original_key == filter_key
        ]
        field_ids = {field_id for _metric_id, field_id in resolved}
        if len(field_ids) > 1:
            raise_observe_planning_error(
                code="component-filter-field-mismatch",
                message=f"Filter {filter_key!r} resolves differently across leaves.",
                candidates={
                    "filter_key": filter_key,
                    "components": [
                        {"metric": metric_id, "resolved_field_id": field_id}
                        for metric_id, field_id in resolved
                    ],
                },
                repair=[],
            )
    by_dataset: dict[str, list[tuple[str, dict[str, Any]]]] = {}
    for leaf in leaves:
        for resolution in _base_plan(leaf).lineage_metadata.get("version_resolutions", []):
            by_dataset.setdefault(resolution["dataset"], []).append((leaf.metric_id, resolution))
    for dataset_id, entries in by_dataset.items():
        if len(entries) < 2:
            continue
        keys = {
            (
                value["mode"],
                value["anchor_source"],
                value.get("anchor_value"),
                value.get("resolved_partition"),
                value.get("resolved_interval_predicate"),
                value.get("anchor_to_partition_mapping_digest"),
            )
            for _metric_id, value in entries
        }
        if len(keys) > 1:
            raise_observe_planning_error(
                code="component-version-mismatch",
                message=f"Versioned dataset {dataset_id!r} differs across leaves.",
                candidates={
                    "versioned_dataset": dataset_id,
                    "components": [
                        {
                            "metric": metric_id,
                            "mode": value["mode"],
                            "anchor_source": value["anchor_source"],
                            "anchor_value": value.get("anchor_value"),
                            "resolved_partition_or_predicate": (
                                value.get("resolved_partition")
                                or value.get("resolved_interval_predicate")
                            ),
                            "mapping_digest": value.get("anchor_to_partition_mapping_digest"),
                        }
                        for metric_id, value in entries
                    ],
                },
                repair=[],
            )


def _is_cumulative_ir(metric_ir: Any) -> bool:
    return getattr(getattr(metric_ir, "composition", None), "kind", None) == "cumulative"


def _plan_cumulative_physical_leaf(
    *,
    catalog: SemanticCatalog,
    session: Any,
    metric_id: str,
    metric_ir: Any,
    dataset_irs: dict[str, Any],
    dataset_fns: dict[str, Any],
    dimensions: list[Any] | None,
    where: dict[Any, Any] | None,
    resolved_window: Any | None,
    time_dimension: str | None,
    subject_cohort: ResolvedSubjectCohort | None,
) -> CumulativePhysicalLeafPlanV1:
    registry = catalog._require_index().registry
    composition = registry.metrics[metric_id].composition
    if not isinstance(composition, CumulativeComposition):
        raise AssertionError(f"metric {metric_id!r} is not cumulative")
    base_ir = _catalog_metric_adapter(catalog, composition.base)
    base_plan = plan_base_observe(
        catalog=catalog,
        session=session,
        metric_ir=base_ir,
        dataset_irs=dataset_irs,
        dataset_fns=dataset_fns,
        dimensions=dimensions,
        where=where,
        resolved_window=resolved_window,
        time_dimension=composition.over or time_dimension,
        subject_cohort=subject_cohort,
        allow_unqualified_outside_scope=True,
    )
    return CumulativePhysicalLeafPlanV1(
        metric_ir=metric_ir,
        base_metric_ir=base_ir,
        base_plan=base_plan,
        over=composition.over,
        window=resolved_window,
        composition=composition,
    )


def _plan_metric_expression_forest(
    *,
    catalog: SemanticCatalog,
    session: Any,
    forest: MetricExpressionForestV1,
    dataset_irs: dict[str, Any],
    dataset_fns: dict[str, Any],
    dimensions: list[Any] | None,
    where: dict[Any, Any] | None,
    resolved_window: Any | None,
    time_dimension: str | None,
    subject_cohort: ResolvedSubjectCohort | None,
) -> MetricGraphObservePlanV1:
    """Recursively plan one already-lowered expression forest."""

    registry = catalog._require_index().registry
    node_by_id = {record.node_id: record.node for record in forest.graph.nodes}
    representatives = _representative_metrics(catalog, forest.graph)
    physical_targets = _physical_targets(forest.graph)
    occurrence_roles: dict[str, list[str]] = {}
    for occurrence in forest.graph.occurrences:
        occurrence_roles.setdefault(occurrence.node_id, []).append(occurrence.path)

    metric_adapters: dict[str, Any] = {
        metric_id: _catalog_metric_adapter(catalog, metric_id)
        for metric_id in sorted(set(representatives.values()))
    }
    leaves: list[ResolvedMetricLeafV1] = []
    datasource_names: set[str] = set()
    warnings: list[dict[str, Any]] = []
    lineage_leaves: list[dict[str, Any]] = []
    scope_failures: list[tuple[str, ObservePlanningError]] = []
    for node_id, (value_node_id, local_where) in sorted(physical_targets.items()):
        value_node = node_by_id[value_node_id]
        metric_id = representatives.get(value_node_id)
        if metric_id is not None:
            metric_ir = (
                registry.metrics[metric_id]
                if isinstance(value_node, WeightedMeanAggregateNodeV1)
                else metric_adapters[metric_id]
            )
        elif isinstance(value_node, AggregateNodeV1):
            metric_ir = _runtime_metric_adapter(catalog, value_node_id, value_node)
            metric_id = metric_ir.semantic_id
        elif isinstance(value_node, WeightedMeanAggregateNodeV1):
            metric_ir = _runtime_weighted_mean_adapter(catalog, value_node_id, value_node)
            metric_id = metric_ir.semantic_id
        else:
            raise_observe_planning_error(
                code="metric-graph-physical-leaf-missing",
                message="Metric graph contains a physical node without a governed execution contract.",
                candidates={"node_id": value_node_id, "node_kind": value_node.kind},
                repair=[],
            )
        if isinstance(value_node, AggregateNodeV1):
            _validate_aggregate_temporal_contract(value_node, metric_ir)
        leaf_where = _merge_leaf_where(where, local_where)
        _validate_authored_filter_types(
            node=value_node,
            registry=registry,
            session=session,
            dataset_irs=dataset_irs,
            dataset_fns=dataset_fns,
            metric_id=metric_id,
        )
        physical_plan: PhysicalLeafPlanV1
        base_plan: BaseObservePlan
        try:
            if _is_cumulative_ir(metric_ir):
                physical_plan = _plan_cumulative_physical_leaf(
                    catalog=catalog,
                    session=session,
                    metric_id=metric_id,
                    metric_ir=metric_ir,
                    dataset_irs=dataset_irs,
                    dataset_fns=dataset_fns,
                    dimensions=dimensions,
                    where=leaf_where,
                    resolved_window=resolved_window,
                    time_dimension=time_dimension,
                    subject_cohort=subject_cohort,
                )
                base_plan = physical_plan.base_plan
            else:
                physical_plan = plan_base_observe(
                    catalog=catalog,
                    session=session,
                    metric_ir=metric_ir,
                    dataset_irs=dataset_irs,
                    dataset_fns=dataset_fns,
                    dimensions=dimensions,
                    where=leaf_where,
                    resolved_window=resolved_window,
                    time_dimension=time_dimension,
                    subject_cohort=subject_cohort,
                    allow_unqualified_outside_scope=True,
                )
                base_plan = physical_plan
        except WindowInvalidError as exc:
            if "has no @ms.time_dimension" not in (exc.message or ""):
                raise
            if _is_cumulative_ir(metric_ir):
                physical_plan = _plan_cumulative_physical_leaf(
                    catalog=catalog,
                    session=session,
                    metric_id=metric_id,
                    metric_ir=metric_ir,
                    dataset_irs=dataset_irs,
                    dataset_fns=dataset_fns,
                    dimensions=dimensions,
                    where=leaf_where,
                    resolved_window=None,
                    time_dimension=time_dimension,
                    subject_cohort=subject_cohort,
                )
                base_plan = physical_plan.base_plan
            else:
                physical_plan = plan_base_observe(
                    catalog=catalog,
                    session=session,
                    metric_ir=metric_ir,
                    dataset_irs=dataset_irs,
                    dataset_fns=dataset_fns,
                    dimensions=dimensions,
                    where=leaf_where,
                    resolved_window=None,
                    time_dimension=time_dimension,
                    subject_cohort=subject_cohort,
                    allow_unqualified_outside_scope=True,
                )
                base_plan = physical_plan
        except ObservePlanningError as exc:
            details = exc._context if isinstance(exc._context, dict) else {}
            if details.get("code") in {
                "field-ref-not-found",
                "field-ref-ambiguous",
                "path-missing",
                "path-ambiguous",
            }:
                scope_failures.append((metric_id, exc))
                continue
            raise
        datasource_names.add(base_plan.datasource_name)
        warnings.extend(base_plan.warnings)
        roles = tuple(sorted(occurrence_roles.get(node_id, ())))
        leaves.append(
            ResolvedMetricLeafV1(
                node_id=node_id,
                value_node_id=value_node_id,
                occurrence_roles=roles,
                metric_id=metric_id,
                metric_ir=metric_ir,
                node=node_by_id[node_id],
                plan=physical_plan,
            )
        )
        lineage_leaves.append(
            {
                "node_id": node_id,
                "metric_id": metric_id,
                "occurrence_roles": list(roles),
                "datasource": base_plan.datasource_name,
                "lineage_metadata": base_plan.lineage_metadata,
            }
        )
    if scope_failures:
        _raise_unreachable_scope(
            scope_failures,
            leaves,
            dimensions=dimensions,
            where=where,
        )
    _validate_leaf_comparability(leaves, dimensions=dimensions, where=where)
    if len(datasource_names) != 1:
        raise_observe_planning_error(
            code="metric-graph-source-domain-mismatch",
            message="A metric expression graph must resolve to one datasource compatibility domain.",
            candidates={"datasources": sorted(datasource_names)},
            repair=[],
        )
    datasource_name = next(iter(datasource_names))
    datasource_ir = registry.datasources.get(datasource_name)
    if datasource_ir is None:
        datasource_ir = next(
            (
                candidate
                for candidate_id, candidate in registry.datasources.items()
                if candidate_id.rsplit(".", 1)[-1] == datasource_name
            ),
            None,
        )
    if datasource_ir is None:
        raise_observe_planning_error(
            code="metric-graph-source-domain-mismatch",
            message=f"Resolved datasource {datasource_name!r} has no semantic declaration.",
            candidates={"datasource": datasource_name},
            repair=[],
        )
    source_domain = DatasourceCompatibilityDomainV1(
        schema="datasource-compatibility/v1",
        datasource_ref=RefPayloadV1.from_ref(ref_factory.datasource(datasource_name)),
        backend_type=datasource_ir.backend_type,
        profile_fingerprint=fingerprint(
            (
                datasource_name,
                datasource_ir.backend_type,
                datasource_ir.fields,
                datasource_ir.env_refs,
            )
        ),
    )
    return MetricGraphObservePlanV1(
        forest=forest,
        leaves=tuple(leaves),
        datasource_name=datasource_name,
        source_domain=source_domain,
        lineage_metadata={
            "metric_graph_schema": forest.graph.schema,
            "root_node_ids": list(forest.graph.roots),
            "dependency_fingerprint": forest.dependency_digest.digest,
            "physical_leaves": lineage_leaves,
        },
        warnings=tuple(warnings),
    )


def plan_metric_graph_observe(
    *,
    catalog: SemanticCatalog,
    session: Any,
    metric_inputs: tuple[Ref[MetricKind] | RuntimeMetricExpr, ...],
    dataset_irs: dict[str, Any],
    dataset_fns: dict[str, Any],
    dimensions: list[Any] | None,
    where: dict[Any, Any] | None,
    resolved_window: Any | None,
    time_dimension: str | None,
    subject_cohort: ResolvedSubjectCohort | None = None,
) -> MetricGraphObservePlanV1:
    """Lower and plan one ordered catalog/runtime expression forest."""
    forest = lower_metric_inputs(
        catalog._require_index().registry,
        metric_inputs,
        sidecar=catalog._state.sidecar,
    )
    return _plan_metric_expression_forest(
        catalog=catalog,
        session=session,
        forest=forest,
        dataset_irs=dataset_irs,
        dataset_fns=dataset_fns,
        dimensions=dimensions,
        where=where,
        resolved_window=resolved_window,
        time_dimension=time_dimension,
        subject_cohort=subject_cohort,
    )


def plan_catalog_metric_graph_observe(
    *,
    catalog: SemanticCatalog,
    session: Any,
    metric_ids: tuple[str, ...],
    dataset_irs: dict[str, Any],
    dataset_fns: dict[str, Any],
    dimensions: list[Any] | None,
    where: dict[Any, Any] | None,
    resolved_window: Any | None,
    time_dimension: str | None,
    subject_cohort: ResolvedSubjectCohort | None = None,
) -> MetricGraphObservePlanV1:
    """Plan one ordered catalog forest through the unified graph planner."""
    forest = lower_catalog_metrics(
        catalog._require_index().registry,
        metric_ids,
        sidecar=catalog._state.sidecar,
    )
    return _plan_metric_expression_forest(
        catalog=catalog,
        session=session,
        forest=forest,
        dataset_irs=dataset_irs,
        dataset_fns=dataset_fns,
        dimensions=dimensions,
        where=where,
        resolved_window=resolved_window,
        time_dimension=time_dimension,
        subject_cohort=subject_cohort,
    )


__all__ = [
    "MetricGraphObservePlanV1",
    "PhysicalLeafPlanV1",
    "ResolvedMetricLeafV1",
    "plan_catalog_metric_graph_observe",
    "plan_metric_graph_observe",
]
