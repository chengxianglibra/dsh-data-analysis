"""Closed role-preserving semantic records for analysis persistence."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Literal, TypeAlias, cast

from typing_extensions import TypeAliasType

from marivo.refs import RefPayloadV1, SemanticKind
from marivo.semantic.metric_graph import (
    CatalogMetricIdentity,
    DeltaComparisonIdentity,
    MetricIdentity,
    RuntimeExpressionIdentity,
)
from marivo.semantic.metric_graph_canonical import canonical_value
from marivo.semantic.unit_algebra import (
    FactorizedUnitV2,
    MetricUnitStateV2,
    OpaqueUnitV2,
    UnknownUnitV2,
)

if TYPE_CHECKING:
    from marivo.analysis.frames.base import BaseFrame

JsonScalar: TypeAlias = str | int | float | bool | None
JsonValue = TypeAliasType(  # type: ignore[misc]
    "JsonValue",
    JsonScalar | list["JsonValue"] | dict[str, "JsonValue"],  # type: ignore[misc]
)


@dataclass(frozen=True, slots=True)
class AxisBindingV1:
    """Persist one physical result column and its exact semantic axis role."""

    ref: RefPayloadV1
    column: str
    role: Literal["dimension", "time_dimension"]
    grain: str | None = None

    def __post_init__(self) -> None:
        if type(self.ref) is not RefPayloadV1:
            raise TypeError("axis binding ref must be an exact RefPayloadV1")
        expected = {
            "dimension": SemanticKind.DIMENSION,
            "time_dimension": SemanticKind.TIME_DIMENSION,
        }[self.role]
        if self.ref.kind is not expected:
            raise ValueError(
                f"axis binding role {self.role!r} requires {expected.value} ref; "
                f"received {self.ref.kind.value}"
            )
        if type(self.column) is not str or not self.column:
            raise ValueError("axis binding column must be a non-empty string")
        if self.grain is not None and (type(self.grain) is not str or not self.grain):
            raise ValueError("axis binding grain must be a non-empty string when provided")


@dataclass(frozen=True, slots=True)
class SlicePredicateV1:
    """Persist one exact semantic slice role without string-keyed identity."""

    dimension_ref: RefPayloadV1
    value: JsonValue

    def __post_init__(self) -> None:
        if type(self.dimension_ref) is not RefPayloadV1:
            raise TypeError("slice predicate dimension_ref must be an exact RefPayloadV1")
        if self.dimension_ref.kind not in {
            SemanticKind.DIMENSION,
            SemanticKind.TIME_DIMENSION,
        }:
            raise ValueError("slice predicate requires a dimension or time_dimension ref")


@dataclass(frozen=True, slots=True)
class ComponentBindingV1:
    """Bind one named composition role to an exact metric identity and column."""

    role: str
    column: str
    metric_identity: MetricIdentity | None = None
    expression_node_id: str | None = None

    def __post_init__(self) -> None:
        if type(self.role) is not str or not self.role:
            raise ValueError("component binding role must be a non-empty string")
        if type(self.column) is not str or not self.column:
            raise ValueError("component binding column must be a non-empty string")
        if (self.metric_identity is None) == (self.expression_node_id is None):
            raise ValueError(
                "component binding requires exactly one metric_identity or expression_node_id"
            )
        if self.expression_node_id is not None and (
            type(self.expression_node_id) is not str or not self.expression_node_id
        ):
            raise ValueError("component binding expression_node_id must be non-empty")


@dataclass(frozen=True, slots=True)
class MeasureBindingV1:
    """Persist one metric value column with its exact execution semantics.

    Arity-aware: an arity-1 frame carries exactly one binding whose ``identity``
    matches ``metric_identity``; an arity-N frame carries one binding per
    ``metric_identities`` entry, ordered identically. ``value_column`` is the
    internal canonical value column. ``display_name`` is a render-only hint and
    is never an authority for intents, evidence, or recovery.
    """

    identity: MetricIdentity
    value_column: str
    display_name: str | None = None
    unit: str | None = None
    unit_state: MetricUnitStateV2 | None = None
    additivity: Literal["additive", "semi_additive", "non_additive"] | None = None
    aggregation: str | None = None
    #: True only when this binding has a known safe plain-sum rollup (additive,
    #: no fold/cumulative).  semi_additive uses ``rollup_fold``; non_additive and
    #: unknown values must never be published as reaggregatable (issue #110).
    reaggregatable: bool = True
    status_time_dimension_ref: RefPayloadV1 | None = None
    cumulative: dict[str, Any] | None = None

    def __post_init__(self) -> None:
        if not isinstance(self.identity, (CatalogMetricIdentity, RuntimeExpressionIdentity)):
            raise TypeError("measure binding identity must be a MetricIdentity")
        if type(self.value_column) is not str or not self.value_column:
            raise ValueError("measure binding value_column must be a non-empty string")
        if self.status_time_dimension_ref is not None and (
            type(self.status_time_dimension_ref) is not RefPayloadV1
        ):
            raise TypeError(
                "measure binding status_time_dimension_ref must be an exact RefPayloadV1"
            )
        if self.unit_state is not None and not isinstance(
            self.unit_state, (FactorizedUnitV2, OpaqueUnitV2, UnknownUnitV2)
        ):
            raise TypeError(
                "measure binding unit_state must be a MetricUnitStateV2, "
                f"got {type(self.unit_state).__name__}"
            )


def job_semantics_from_frames(*frames: BaseFrame) -> dict[str, Any]:
    """Derive one role-preserving analysis-job semantic envelope."""

    if not frames:
        raise ValueError("job semantic envelope requires at least one frame")
    fingerprints = {
        value
        for frame in frames
        if (value := getattr(frame.meta, "catalog_definition_fingerprint", None)) is not None
    }
    if len(fingerprints) > 1:
        raise ValueError("job frames disagree on catalog definition fingerprint")

    funnel_frames = tuple(
        frame
        for frame in frames
        if (
            frame.meta.kind == "delta_frame"
            and getattr(frame.meta, "semantic_kind", None) == "funnel"
        )
        or (
            frame.meta.kind == "attribution_frame"
            and getattr(frame.meta, "semantic_kind", None) == "funnel_loss_rate"
        )
    )
    if funnel_frames:
        if len(funnel_frames) != len(frames) or len(funnel_frames) != 1:
            raise ValueError("analysis job funnel semantics require exactly one funnel artifact")
        meta = cast("Any", funnel_frames[0].meta)
        semantic_kind = meta.semantic_kind
        if semantic_kind == "funnel":
            role = "funnel_comparison"
            semantics = {
                "artifact_ref": meta.artifact_id or meta.ref,
                "artifact_fingerprint": meta.content_hash,
                "source_current_ref": meta.source_current_ref,
                "source_baseline_ref": meta.source_baseline_ref,
                "source_current_fingerprint": meta.source_current_fingerprint,
                "source_baseline_fingerprint": meta.source_baseline_fingerprint,
                "source_current_journey_ref": meta.source_current_journey_ref,
                "source_baseline_journey_ref": meta.source_baseline_journey_ref,
                "pattern_fingerprint": meta.pattern.fingerprint,
                "matching": meta.matching.model_dump(mode="json"),
                "completion_through": meta.completion_through,
                "axes": [axis.model_dump(mode="json") for axis in meta.axes],
                "alignment_kind": meta.alignment_kind,
                "aligned_step_keys": list(meta.aligned_step_keys),
                "zero_filled_tuple_count": meta.zero_filled_tuple_count,
                "current_cohort_window": meta.current_cohort_window.model_dump(mode="json"),
                "baseline_cohort_window": meta.baseline_cohort_window.model_dump(mode="json"),
                "current_coverage_basis": meta.current_coverage_basis,
                "baseline_coverage_basis": meta.baseline_coverage_basis,
                "current_completeness": [
                    item.model_dump(mode="json") for item in meta.current_completeness
                ],
                "baseline_completeness": [
                    item.model_dump(mode="json") for item in meta.baseline_completeness
                ],
            }
        else:
            role = "funnel_attribution"
            semantics = {
                "artifact_ref": meta.artifact_id or meta.ref,
                "artifact_fingerprint": meta.content_hash,
                "source_delta_ref": meta.source_delta_ref,
                "source_delta_fingerprint": meta.source_delta_fingerprint,
                "source_current_journey_ref": meta.source_current_journey_ref,
                "source_baseline_journey_ref": meta.source_baseline_journey_ref,
                "source_pattern_fingerprint": meta.source_pattern_fingerprint,
                "matching": meta.matching.model_dump(mode="json"),
                "coverage_basis": meta.coverage_basis,
                "target": meta.target.model_dump(mode="json"),
                "preceding_step_key": meta.preceding_step_key,
                "axes": [axis.model_dump(mode="json") for axis in meta.axes],
                "mode": meta.mode,
                "reconciliation": meta.reconciliation.model_dump(mode="json"),
            }
        return {
            "catalog_definition_fingerprint": next(iter(fingerprints), None),
            "subject": {
                "kind": "event",
                "subject_entity_ref": meta.subject_entity_ref.to_dict(),
                "subject_identity_signature": list(meta.subject_identity),
            },
            role: semantics,
        }

    lifecycle_frames = tuple(frame for frame in frames if frame.meta.kind == "lifecycle_frame")
    if lifecycle_frames:
        if len(lifecycle_frames) != len(frames) or len(lifecycle_frames) != 1:
            raise ValueError("analysis job Lifecycle semantics require exactly one LifecycleFrame")
        meta = cast("Any", lifecycle_frames[0].meta)
        lifecycle_payload: dict[str, Any] = {
            "catalog_definition_fingerprint": next(iter(fingerprints), None),
            "subject": {
                "kind": "lifecycle",
                "subject_entity_ref": meta.subject_entity_ref.to_dict(),
                "subject_identity_signature": list(meta.subject_identity),
            },
        }
        common = {
            "state_model_ref": meta.state_model_ref.to_dict(),
            "state_model_fingerprint": meta.state_model_fingerprint,
            "states": [item.model_dump(mode="json") for item in meta.states],
        }
        if meta.semantic_kind == "history":
            lifecycle_payload["lifecycle_history"] = {
                **common,
                "seed": meta.seed.model_dump(mode="json"),
                "window": meta.window.model_dump(mode="json"),
                "violation_behavior_id": meta.violation_behavior_id,
                "triggers": [item.model_dump(mode="json") for item in meta.triggers],
                "completeness": [item.model_dump(mode="json") for item in meta.completeness],
                "input_coverage": [item.model_dump(mode="json") for item in meta.input_coverage],
                "coverage_basis": meta.coverage_basis,
                "event_fingerprints": dict(sorted(meta.event_fingerprints.items())),
                "event_identity_components": {
                    key: [component.to_dict() for component in components]
                    for key, components in sorted(meta.event_identity_components.items())
                },
                "query_refs": list(meta.query_refs),
                "population_count": meta.population_count,
                "seeded_subject_count": meta.seeded_subject_count,
                "coverage_censored_subject_count": (meta.coverage_censored_subject_count),
                "interval_count": meta.interval_count,
                "violation_count": meta.violation_count,
                "pre_inception_ignored_counts": dict(
                    sorted(meta.pre_inception_ignored_counts.items())
                ),
                "violation_trace": meta.violation_trace.model_dump(mode="json"),
            }
            if meta.cohort is not None:
                lifecycle_payload["cohort"] = meta.cohort.model_dump(mode="json")
        else:
            reducer_payload: dict[str, Any] = {
                **common,
                "kind": meta.semantic_kind,
                "source_artifact_ref": meta.source_history_ref,
                "source_artifact_fingerprint": meta.source_history_fingerprint,
            }
            if meta.semantic_kind == "distribution":
                reducer_payload.update(
                    {
                        "at": list(meta.at),
                        "axes": [item.model_dump(mode="json") for item in meta.axes],
                        "known_subject_counts": dict(sorted(meta.known_subject_counts.items())),
                        "coverage_censored_subject_counts": dict(
                            sorted(meta.coverage_censored_subject_counts.items())
                        ),
                        "grouped_reconciliation_hash": (meta.grouped_reconciliation_hash),
                    }
                )
            elif meta.semantic_kind == "transitions":
                reducer_payload.update(
                    {
                        "modeled_pairs": [
                            item.model_dump(mode="json") for item in meta.modeled_pairs
                        ],
                        "modeled_transition_count": meta.modeled_transition_count,
                    }
                )
            elif meta.semantic_kind == "dwell":
                reducer_payload["source_interval_count"] = meta.source_interval_count
            elif meta.semantic_kind == "violations":
                reducer_payload.update(
                    {
                        "violation_count": meta.violation_count,
                        "source_trace_content_hash": meta.source_trace_content_hash,
                    }
                )
            else:
                raise ValueError(f"unsupported Lifecycle semantic shape {meta.semantic_kind!r}")
            lifecycle_payload["lifecycle_reducer"] = reducer_payload
        return lifecycle_payload

    event_frames = tuple(frame for frame in frames if frame.meta.kind == "event_frame")
    if event_frames:
        if len(event_frames) != len(frames):
            raise ValueError("analysis job cannot mix Event and metric frame semantics")
        event_metas = tuple(cast("Any", frame.meta) for frame in event_frames)
        first = event_metas[0]
        signatures = {
            (
                meta.pattern.fingerprint,
                meta.subject_entity_ref.path,
                tuple(meta.subject_identity),
            )
            for meta in event_metas
        }
        if len(signatures) != 1:
            raise ValueError("analysis job Event frames disagree on journey semantics")
        event_payload: dict[str, Any] = {
            "catalog_definition_fingerprint": next(iter(fingerprints), None),
            "subject": {
                "kind": "event",
                "subject_entity_ref": first.subject_entity_ref.to_dict(),
                "subject_identity_signature": list(first.subject_identity),
            },
        }
        semantic_kinds = {meta.semantic_kind for meta in event_metas}
        if len(semantic_kinds) != 1:
            raise ValueError("analysis job Event frames disagree on semantic shape")
        semantic_kind = next(iter(semantic_kinds))
        if semantic_kind == "journey":
            event_payload["event_journey"] = {
                "pattern": first.pattern.model_dump(mode="json"),
                "matching": first.matching.model_dump(mode="json"),
                "cohort_window": first.cohort_window.model_dump(mode="json"),
                "completion_through": first.completion_through,
                "completeness": [item.model_dump(mode="json") for item in first.completeness],
                "input_coverage": [item.model_dump(mode="json") for item in first.input_coverage],
                "coverage_basis": first.coverage_basis,
                "event_fingerprints": dict(sorted(first.event_fingerprints.items())),
                "event_identity_components": {
                    key: [component.to_dict() for component in components]
                    for key, components in sorted(first.event_identity_components.items())
                },
                "role_endpoints": {
                    key: value.to_dict() for key, value in sorted(first.role_endpoints.items())
                },
                "query_refs": list(first.query_refs),
                "unused_event_count": first.unused_event_count,
                "unused_event_counts_by_step": dict(
                    sorted(first.unused_event_counts_by_step.items())
                ),
            }
        elif semantic_kind == "funnel":
            event_payload["event_reducer"] = {
                "kind": "funnel",
                "source_artifact_ref": first.source_journey_ref,
                "source_artifact_fingerprint": first.source_journey_fingerprint,
                "pattern_fingerprint": first.pattern.fingerprint,
                "matching": first.matching.model_dump(mode="json"),
                "coverage_basis": first.coverage_basis,
                "axes": [item.model_dump(mode="json") for item in first.axes],
                "grouped_reconciliation": first.grouped_reconciliation.model_dump(mode="json"),
                "source_unused_event_count": first.source_unused_event_count,
            }
        elif semantic_kind == "time_to_event":
            event_payload["event_reducer"] = {
                "kind": "time_to_event",
                "source_artifact_ref": first.source_journey_ref,
                "source_artifact_fingerprint": first.source_journey_fingerprint,
                "pattern_fingerprint": first.pattern.fingerprint,
                "matching": first.matching.model_dump(mode="json"),
                "coverage_basis": first.coverage_basis,
                "start_step": first.start_step.model_dump(mode="json"),
                "end_step": first.end_step.model_dump(mode="json"),
                "axes": [item.model_dump(mode="json") for item in first.axes],
                "source_unused_end_count": first.source_unused_end_count,
            }
        else:
            raise ValueError(f"unsupported Event semantic shape {semantic_kind!r}")
        cohorts = {meta.cohort for meta in event_metas}
        if len(cohorts) > 1:
            raise ValueError("analysis job Event frames disagree on SubjectSet cohort")
        cohort = next(iter(cohorts))
        if cohort is not None:
            event_payload["cohort"] = cohort.model_dump(mode="json")
        return event_payload

    subject_sets = tuple(frame for frame in frames if frame.meta.kind == "subject_set")
    if subject_sets:
        from marivo.analysis.frames.subject import SubjectSetMeta

        if len(subject_sets) != len(frames) or len(subject_sets) != 1:
            raise ValueError("analysis job SubjectSet semantics require exactly one SubjectSet")
        meta = subject_sets[0].meta
        if not isinstance(meta, SubjectSetMeta):
            raise ValueError("analysis job SubjectSet frame has invalid metadata")
        return {
            "catalog_definition_fingerprint": next(iter(fingerprints), None),
            "subject": {
                "kind": "subject_set",
                "subject_entity_ref": meta.subject_entity_ref.to_dict(),
                "subject_identity_signature": list(meta.subject_identity),
            },
            "subject_set": {
                "source": meta.source.model_dump(mode="json"),
                "selection": meta.selection.model_dump(mode="json"),
                "selection_fingerprint": meta.selection_fingerprint,
                "selected_count": meta.selected_count,
                "excluded_coverage_censored_count": (meta.excluded_coverage_censored_count),
                "coverage_status": meta.coverage_status,
            },
        }

    identities: list[MetricIdentity] = []
    comparisons: list[DeltaComparisonIdentity] = []
    digests: list[object] = []
    axis_bindings: list[AxisBindingV1] = []
    predicates: list[SlicePredicateV1] = []
    for frame in frames:
        meta = frame.meta
        comparison = getattr(meta, "comparison_identity", None)
        if isinstance(comparison, DeltaComparisonIdentity) and comparison not in comparisons:
            comparisons.append(comparison)
        frame_identities = tuple(getattr(meta, "metric_identities", ()))
        if not frame_identities:
            identity = getattr(meta, "metric_identity", None)
            if isinstance(identity, (CatalogMetricIdentity, RuntimeExpressionIdentity)):
                frame_identities = (identity,)
        for identity in frame_identities:
            if identity not in identities:
                identities.append(identity)
        digest = getattr(meta, "semantic_dependency_digest", None)
        if digest is not None and digest not in digests:
            digests.append(digest)
        for digest in tuple(getattr(meta, "source_dependency_digests", ())):
            if digest not in digests:
                digests.append(digest)
        for binding in tuple(getattr(meta, "axis_bindings", ())):
            if binding not in axis_bindings:
                axis_bindings.append(binding)
        for predicate in tuple(getattr(meta, "slice_predicates", ())):
            if predicate not in predicates:
                predicates.append(predicate)

    def subject(identity: MetricIdentity) -> dict[str, Any]:
        if isinstance(identity, CatalogMetricIdentity):
            return {"kind": "catalog_metric", "metric_ref": identity.metric_ref.to_dict()}
        return {
            "kind": "runtime_expression",
            "expression_schema": identity.expression_schema,
            "expression_fingerprint": identity.expression_fingerprint,
        }

    payload: dict[str, Any] = {
        "catalog_definition_fingerprint": next(iter(fingerprints), None),
        "dimension_refs": [
            binding.ref.to_dict() for binding in axis_bindings if binding.role == "dimension"
        ],
        "slice_predicates": canonical_value(tuple(predicates)),
        "time_dimension_ref": next(
            (
                binding.ref.to_dict()
                for binding in axis_bindings
                if binding.role == "time_dimension"
            ),
            None,
        ),
    }
    if len(digests) == 1:
        payload["semantic_dependency_digest"] = canonical_value(digests[0])
    elif digests:
        payload["semantic_dependency_digests"] = canonical_value(tuple(digests))
    else:
        payload["semantic_dependency_digest"] = None
    if len(comparisons) == 1:
        payload["subject"] = {
            "kind": "delta_metric",
            "comparison": canonical_value(comparisons[0]),
        }
    elif len(identities) == 1:
        payload["subject"] = subject(identities[0])
    else:
        payload["subjects"] = [subject(identity) for identity in identities]
    cohorts = {
        cohort for frame in frames if (cohort := getattr(frame.meta, "cohort", None)) is not None
    }
    if len(cohorts) > 1:
        raise ValueError("analysis job Metric frames disagree on SubjectSet cohort")
    if cohorts:
        payload["cohort"] = next(iter(cohorts)).model_dump(mode="json")
    return payload


__all__ = [
    "AxisBindingV1",
    "ComponentBindingV1",
    "JsonScalar",
    "JsonValue",
    "MeasureBindingV1",
    "SlicePredicateV1",
    "job_semantics_from_frames",
]
