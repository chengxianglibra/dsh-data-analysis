"""Executor helpers for analysis."""
