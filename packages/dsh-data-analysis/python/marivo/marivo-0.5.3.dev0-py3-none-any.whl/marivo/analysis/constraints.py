"""Constraint catalog for ``marivo.analysis`` runtime and help surfaces."""

from __future__ import annotations

from marivo._compat import StrEnum
from marivo.introspection.constraints import Constraint, Phase

__all__ = [
    "CONSTRAINTS",
    "Constraint",
    "ConstraintId",
    "constraints_for_error_kind",
    "constraints_for_symbol",
    "default_constraint_for_error_kind",
    "default_hint_for_error_kind",
    "get_constraint",
    "iter_constraints",
]


class ConstraintId(StrEnum):
    """Stable identifiers for analysis constraints."""

    METRIC_EXPRESSION_RESOLVABLE = "metric_expression_resolvable"
    METRIC_READINESS_VERIFIED = "metric_readiness_verified"
    WINDOW_ABSOLUTE_PARSEABLE = "window_absolute_parseable"
    OBSERVE_TIME_GRAIN_COMPATIBLE = "observe_time_grain_compatible"
    FRAME_KIND_COMPATIBLE = "frame_kind_compatible"
    SINGLE_METRIC_INPUT = "single_metric_input"
    DISCOVER_MINIMUM_EVIDENCE = "discover_minimum_evidence"
    DISCOVER_AXIS_REPLAY_AVAILABLE = "discover_axis_replay_available"
    ALIGNMENT_POLICY_SHAPE = "alignment_policy_shape"
    CORRELATE_LAG_SEMANTICS = "correlate_lag_semantics"
    TRANSFORM_ARGUMENTS = "transform_arguments"
    TRANSFORM_FRAME_SHAPE = "transform_frame_shape"
    TRANSFORM_OPERATOR_SUPPORTED = "transform_operator_supported"
    FORECAST_INPUT_SHAPE = "forecast_input_shape"
    EVENT_PATTERN_VALID = "event_pattern_valid"
    EVENT_WINDOW_VALID = "event_window_valid"
    EVENT_COMPLETENESS_VALID = "event_completeness_valid"
    EVENT_REDUCER_SOURCE_VALID = "event_reducer_source_valid"
    EVENT_SUBJECT_AXIS_VALID = "event_subject_axis_valid"
    EVENT_STEP_PAIR_VALID = "event_step_pair_valid"
    SUBJECT_SELECTION_VALID = "subject_selection_valid"
    LIFECYCLE_MODEL_VALID = "lifecycle_model_valid"
    LIFECYCLE_WINDOW_VALID = "lifecycle_window_valid"
    LIFECYCLE_SEED_VALID = "lifecycle_seed_valid"
    LIFECYCLE_REDUCER_SOURCE_VALID = "lifecycle_reducer_source_valid"
    FUNNEL_COMPARISON_COMPATIBLE = "funnel_comparison_compatible"
    FUNNEL_ATTRIBUTION_TARGET_VALID = "funnel_attribution_target_valid"
    FUNNEL_ATTRIBUTION_RECONCILIATION = "funnel_attribution_reconciliation"
    FRAME_IMMUTABLE = "frame_immutable"
    FRAME_READ_BOUNDS = "frame_read_bounds"
    FRAME_META_INVALID = "frame_meta_invalid"
    BACKEND_FACTORY_CONFIGURED = "backend_factory_configured"
    DATASOURCE_CONFIGURED = "datasource_configured"
    DATASOURCE_ENV_AVAILABLE = "datasource_env_available"
    DATASOURCE_BACKEND_SUPPORTED = "datasource_backend_supported"
    SOURCE_BINDINGS_EXACT = "source_bindings_exact"
    COMPONENT_FRAME_AVAILABLE = "component_frame_available"
    ATTRIBUTION_ADDITIVITY_COMPATIBLE = "attribution_additivity_compatible"
    ATTRIBUTION_AXIS_COLUMN_COMPATIBLE = "attribution_axis_column_compatible"
    ATTRIBUTION_RECONCILIATION = "attribution_reconciliation"
    CUMULATIVE_COMPARE_COMPATIBLE = "cumulative_compare_compatible"
    CUMULATIVE_ATTRIBUTION_ROUTE_COMPATIBLE = "cumulative_attribution_route_compatible"
    RUNTIME_METRIC_CLOSED_ALGEBRA = "runtime_metric_closed_algebra"
    RUNTIME_METRIC_FOLD_REQUIRES_SEMI_ADDITIVE = "runtime_metric_fold_requires_semi_additive"
    RUNTIME_WEIGHTED_MEAN_VALID = "runtime_weighted_mean_valid"
    RUNTIME_LINEAR_UNITS_COMMENSURABLE = "runtime_linear_units_commensurable"


_DATASOURCE_DOC = "site/src/content/docs/docs/latest/concepts/semantic-layer.mdx"


def _constraint(
    id: ConstraintId,
    error_kind: str,
    phase: Phase,
    applies_to: tuple[str, ...],
    title: str,
    why: str,
    hint: str,
    *,
    example: str | None = None,
    docs_ref: str | None = None,
    help_target: str | None = None,
) -> Constraint:
    return Constraint(
        id=id.value,
        error_kind=error_kind,
        phase=phase,
        applies_to=applies_to,
        title=title,
        why=why,
        hint=hint,
        example=example,
        docs_ref=docs_ref,
        help_target=help_target,
    )


CONSTRAINTS: dict[ConstraintId, Constraint] = {
    ConstraintId.METRIC_EXPRESSION_RESOLVABLE: _constraint(
        ConstraintId.METRIC_EXPRESSION_RESOLVABLE,
        "MetricNotFound",
        "runtime",
        ("observe", "Ref[metric]", "RuntimeMetricExpr"),
        "Every metric-expression leaf must resolve to an analysis-ready governed ref.",
        "Catalog metric refs and runtime expressions share one graph planner; unresolved or unready leaves cannot produce a typed frame.",
        "Pass an exact catalog Ref[metric] or build a closed expression with mv.runtime_metric.* from exact Ref[measure]/Ref[metric] operands.",
        help_target="observe",
    ),
    ConstraintId.METRIC_READINESS_VERIFIED: _constraint(
        ConstraintId.METRIC_READINESS_VERIFIED,
        "SemanticProjectNotReady",
        "runtime",
        ("observe",),
        "Verify refs are ready with session.catalog.readiness(refs=[metric]) before observe; analysis APIs do not invoke readiness automatically.",
        "Readiness surfaces authoring and evidence blockers up-front as an explicit decision; analysis does not perform this verification on your behalf.",
        "Run session.catalog.readiness(refs=[metric]) and inspect report.show(); observe only ready refs.",
        help_target="catalog.readiness",
    ),
    ConstraintId.WINDOW_ABSOLUTE_PARSEABLE: _constraint(
        ConstraintId.WINDOW_ABSOLUTE_PARSEABLE,
        "WindowInvalid",
        "runtime",
        ("observe", "forecast", "transform", "TimeScope", "AbsoluteWindow"),
        "Time scopes are half-open [start, end): start is inclusive and end is exclusive.",
        "Analysis persistence records concrete half-open ranges and cannot infer an ambiguous natural-language window or silently include the end bound.",
        'Pass time_scope=mv.time_scope(start="2026-07-01", end="2026-08-01") to include all of July and exclude August 1.',
        example='time_scope=mv.time_scope(start="2026-07-01", end="2026-08-01")',
        help_target="observe",
    ),
    ConstraintId.OBSERVE_TIME_GRAIN_COMPATIBLE: _constraint(
        ConstraintId.OBSERVE_TIME_GRAIN_COMPATIBLE,
        "GrainUnsupported",
        "runtime",
        ("observe", "grain", "time_dimension"),
        (
            "Observe grain must be no finer than the selected time dimension's declared "
            "granularity; when the default time dimension is day-granular, "
            'grain=mv.grain("hour") requires an hour-granular time dimension passed '
            "explicitly as time_dimension=hourly_time_dimension."
        ),
        (
            "Marivo cannot recover time-of-day detail from a day-granular time dimension "
            "or silently choose a different time axis."
        ),
        (
            "Select an existing hour-granular time dimension, or author and verify one "
            "first, then pass it explicitly as time_dimension=hourly_time_dimension."
        ),
        help_target="observe",
    ),
    ConstraintId.FRAME_KIND_COMPATIBLE: _constraint(
        ConstraintId.FRAME_KIND_COMPATIBLE,
        "SemanticKindMismatch",
        "runtime",
        (
            "compare",
            "attribute",
            "decompose",
            "discover",
            "select",
            "correlate",
            "hypothesis_test",
            "MetricFrame",
            "DeltaFrame",
            "CandidateSet",
            "SemanticKindMismatchError",
        ),
        "Intent inputs must match the required frame family and semantic shape.",
        "Each intent consumes a bounded frame contract; accepting the wrong family silently would corrupt follow-up lineage.",
        "Check frame.meta.kind, frame.semantic_shape, or CandidateSet.meta.shape before narrowing or dispatching.",
        help_target="compare",
    ),
    ConstraintId.SINGLE_METRIC_INPUT: _constraint(
        ConstraintId.SINGLE_METRIC_INPUT,
        "MetricArity",
        "runtime",
        (
            "compare",
            "correlate",
            "hypothesis_test",
            "forecast",
            "transform",
            "discover",
            "MetricFrame",
            "MetricArityError",
        ),
        (
            "Single-metric intents require both MetricFrame inputs to carry "
            "arity=1; multi-metric frames are rejected fail-closed."
        ),
        (
            "Each intent operates on one metric value column and its persisted "
            "comparable semantics; a multi-metric frame has no single canonical "
            "value series to compare, correlate, forecast, or transform."
        ),
        (
            'Project the frame to one metric with frame.metric("<metric_id>") '
            "before calling the intent; frame.metrics lists the carried ids."
        ),
        help_target="MetricFrame.metric",
    ),
    ConstraintId.DISCOVER_MINIMUM_EVIDENCE: _constraint(
        ConstraintId.DISCOVER_MINIMUM_EVIDENCE,
        "DiscoverInsufficientData",
        "runtime",
        ("discover", "CandidateSet"),
        "Discovery objectives need enough rows or buckets to rank candidates.",
        "Candidate scoring needs a minimum evidence set; too few observations make rankings misleading.",
        "Use a wider time_scope or choose a discovery objective compatible with the source shape.",
        help_target="discover",
    ),
    ConstraintId.DISCOVER_AXIS_REPLAY_AVAILABLE: _constraint(
        ConstraintId.DISCOVER_AXIS_REPLAY_AVAILABLE,
        "DiscoverAxisNotMaterialized",
        "runtime",
        ("discover.driver_axes", "DeltaFrame", "CandidateSet"),
        "Driver-axis discovery uses materialized axes or exact current replay authority with "
        "independent replay Runs.",
        "Missing axes can be introduced only by replaying both persisted source observations "
        "with unchanged semantic dependencies and the original comparison alignment. Each "
        "replayed observation and comparison has its own recoverable Run; driver_axes consumes "
        "only the expanded delta.",
        "Pass the requested current-catalog dimensions directly; Marivo replays them when "
        "possible and otherwise returns a structured repair before admitting a Run.",
        help_target="discover.driver_axes",
    ),
    ConstraintId.ALIGNMENT_POLICY_SHAPE: _constraint(
        ConstraintId.ALIGNMENT_POLICY_SHAPE,
        "AlignmentPolicyValidation",
        "runtime",
        ("compare", "correlate", "hypothesis_test", "AlignmentPolicy", "alignment"),
        "AlignmentPolicy arguments must match the selected alignment kind.",
        "The closed helpers admit only the registered alignment kinds with their exact fields, including working_day_progress(schedule=...).",
        "Construct one policy with mv.window_bucket(), mv.day_of_week(), mv.period_progress(), mv.period_correspondence(), mv.occurrence_progress(), or mv.working_day_progress(schedule=...).",
        help_target="alignment",
    ),
    ConstraintId.CORRELATE_LAG_SEMANTICS: _constraint(
        ConstraintId.CORRELATE_LAG_SEMANTICS,
        "AlignmentFailed",
        "runtime",
        ("correlate", "AssociationResult"),
        "Signed lag k pairs a[t] with b[t+k]: positive means a leads b, negative means b leads a, and lag 0 is the default. Non-zero lags require time_series or panel frames; panel lag shifts stay within each dimension series, and null pairs are dropped after shifting.",
        "Per-series shifting preserves panel boundaries and missing bucket positions.",
        "Pass a signed lag_range whose offsets leave at least two overlapping, non-constant pairs, such as range(-3, 4).",
        help_target="correlate",
    ),
    ConstraintId.TRANSFORM_ARGUMENTS: _constraint(
        ConstraintId.TRANSFORM_ARGUMENTS,
        "TransformArg",
        "runtime",
        ("transform", "MetricFrame", "DeltaFrame"),
        "Transform operators require their documented keyword arguments.",
        "Each transform op has a specific parameter contract; missing or contradictory kwargs produce ambiguous frames.",
        'Inspect marivo.help("analysis.transform") and pass the required args for the selected op.',
        help_target="transform",
    ),
    ConstraintId.TRANSFORM_FRAME_SHAPE: _constraint(
        ConstraintId.TRANSFORM_FRAME_SHAPE,
        "TransformShape",
        "runtime",
        ("transform", "MetricFrame", "DeltaFrame"),
        "Transform operators require compatible axes and value columns.",
        "Shape-changing transforms can only preserve lineage when the requested axes exist on the frame.",
        'Use frame.columns, frame.meta.axes, or marivo.help("analysis.transform") before topk, rollup, slice, or rank.',
        help_target="transform",
    ),
    ConstraintId.TRANSFORM_OPERATOR_SUPPORTED: _constraint(
        ConstraintId.TRANSFORM_OPERATOR_SUPPORTED,
        "TransformOp",
        "runtime",
        ("transform",),
        "Transform op names are limited to the supported v1 operator set.",
        "The runtime records transform lineage by stable op id; unknown ops cannot be replayed.",
        "Use filter, slice, rollup, topk, bottomk, rank, normalize, or window.",
        help_target="transform",
    ),
    ConstraintId.FORECAST_INPUT_SHAPE: _constraint(
        ConstraintId.FORECAST_INPUT_SHAPE,
        "ForecastShapeUnsupported",
        "runtime",
        ("forecast", "ForecastFrame", "MetricFrame"),
        "Forecast accepts MetricFrame time_series or panel inputs, including certified semantic periods.",
        "Forecast models need complete ordered history periods; semantic histories must match one exact period snapshot and cannot operate on scalar or segmented-only frames.",
        "Observe the metric with a built-in or certified semantic grain and enough complete history before calling session.forecast(...).",
        help_target="forecast",
    ),
    ConstraintId.EVENT_PATTERN_VALID: _constraint(
        ConstraintId.EVENT_PATTERN_VALID,
        "InvalidEventPattern",
        "runtime",
        ("events.match", "EventPattern", "PatternStep"),
        "Event Journey patterns contain typed steps over one subject Entity.",
        "A journey can only be matched when every step selects the same cardinality-one participant endpoint.",
        "Build each step with mv.step(participant=ms.participant_role(...), key='snake_case') and combine them with mv.sequence(...).",
        help_target="events.match",
    ),
    ConstraintId.EVENT_REDUCER_SOURCE_VALID: _constraint(
        ConstraintId.EVENT_REDUCER_SOURCE_VALID,
        "SubjectSetMismatch",
        "runtime",
        ("events.funnel", "events.time_to_event", "select_subjects", "EventFrame"),
        "Event reducers consume an exact registered EventFrame[journey].",
        "Reducer lineage and occurrence assignment are inherited from the persisted source artifact.",
        "Pass the same-session journey returned by session.events.match(...), not a reducer output or copied DataFrame.",
        help_target="events.funnel",
    ),
    ConstraintId.EVENT_SUBJECT_AXIS_VALID: _constraint(
        ConstraintId.EVENT_SUBJECT_AXIS_VALID,
        "InvalidSubjectAxis",
        "runtime",
        ("events.funnel", "events.time_to_event", "Dimension", "EventFrame"),
        "Event reducer axes must resolve through one governed fanout-safe subject path.",
        "Grouped counts and elapsed rows reconcile only when each subject has one deterministic cohort-entry axis value.",
        "Pass exact current-catalog Dimension entries or refs reachable by a unique directed to-one path.",
        help_target="events.funnel",
    ),
    ConstraintId.EVENT_STEP_PAIR_VALID: _constraint(
        ConstraintId.EVENT_STEP_PAIR_VALID,
        "PatternStepMismatch",
        "runtime",
        ("events.time_to_event", "PatternStep", "EventPattern"),
        "Time-to-event steps must be exact ordered members of the source pattern.",
        "The reducer preserves source occurrence assignment and cannot infer steps from names or positions.",
        "Pass exact PatternStep values retained by source.meta.pattern, with start before end.",
        help_target="events.time_to_event",
    ),
    ConstraintId.SUBJECT_SELECTION_VALID: _constraint(
        ConstraintId.SUBJECT_SELECTION_VALID,
        "SubjectSetMismatch",
        "runtime",
        ("select_subjects", "DroppedBefore", "SubjectSet"),
        "Subject selection uses one closed typed selection over a canonical journey.",
        "Only resolved loss can create a cohort without silently treating censored subjects as dropouts.",
        "Use mv.dropped_before(step=<exact non-initial source PatternStep>) on a first-per-subject journey.",
        help_target="select_subjects",
    ),
    ConstraintId.LIFECYCLE_MODEL_VALID: _constraint(
        ConstraintId.LIFECYCLE_MODEL_VALID,
        "InvalidStateTransition",
        "runtime",
        ("lifecycle.replay", "StateModel"),
        "Lifecycle replay requires one exact current, analysis-ready StateModel.",
        "Replay consumes the model's canonical subject, state, inception, and transition truth.",
        "Pass a current StateModel entry or exact Ref[state_model] with one usable inception.",
        help_target="lifecycle.replay",
    ),
    ConstraintId.LIFECYCLE_WINDOW_VALID: _constraint(
        ConstraintId.LIFECYCLE_WINDOW_VALID,
        "WindowInvalid",
        "runtime",
        ("lifecycle.replay", "TimeScope"),
        "Lifecycle replay windows are explicit timezone-aware half-open intervals.",
        "Replay reconstructs earlier state before clipping intervals to the requested window.",
        "Pass mv.time_scope(start=<aware instant>, end=<later aware instant>).",
        help_target="lifecycle.replay",
    ),
    ConstraintId.LIFECYCLE_SEED_VALID: _constraint(
        ConstraintId.LIFECYCLE_SEED_VALID,
        "InvalidLifecycleSeed",
        "runtime",
        ("lifecycle.replay", "FromInception"),
        "Phase 3 replay requires the exact explicit from-inception seed.",
        "No initial state is assumed at the replay window boundary.",
        "Pass seed=mv.from_inception() to an inception-ready StateModel.",
        help_target="lifecycle.replay",
    ),
    ConstraintId.LIFECYCLE_REDUCER_SOURCE_VALID: _constraint(
        ConstraintId.LIFECYCLE_REDUCER_SOURCE_VALID,
        "SubjectSetMismatch",
        "runtime",
        (
            "lifecycle.distribution",
            "lifecycle.transitions",
            "lifecycle.dwell",
            "lifecycle.violations",
            "LifecycleFrame",
        ),
        "Lifecycle reducers consume one exact registered LifecycleFrame[history].",
        "Reducers preserve committed replay authority and do not query or replay Event inputs.",
        "Pass the same-session history returned by session.lifecycle.replay(...).",
        help_target="lifecycle.replay",
    ),
    ConstraintId.FUNNEL_COMPARISON_COMPATIBLE: _constraint(
        ConstraintId.FUNNEL_COMPARISON_COMPATIBLE,
        "FunnelComparisonMismatch",
        "runtime",
        ("compare", "EventFrame", "DeltaFrame"),
        (
            "Funnel comparison requires identical pattern, step, matching, "
            "follow-up, subject, and axis contracts."
        ),
        "Comparison aligns PatternStep identity plus the exact axis tuple.",
        "Rebuild one side with the same funnel contract, then compare again.",
        help_target="compare",
    ),
    ConstraintId.FUNNEL_ATTRIBUTION_TARGET_VALID: _constraint(
        ConstraintId.FUNNEL_ATTRIBUTION_TARGET_VALID,
        "FunnelAttributionUnsupported",
        "runtime",
        ("attribute", "FunnelLossRate", "DeltaFrame"),
        (
            "Funnel attribution targets one exact non-initial PatternStep "
            "retained by both compared funnels."
        ),
        "The target names the loss from the immediately preceding step.",
        "Pass mv.funnel_loss_rate(step=<retained non-initial PatternStep>).",
        help_target="attribute",
    ),
    ConstraintId.FUNNEL_ATTRIBUTION_RECONCILIATION: _constraint(
        ConstraintId.FUNNEL_ATTRIBUTION_RECONCILIATION,
        "FunnelAttributionUnsupported",
        "runtime",
        ("attribute", "AttributionFrame"),
        (
            "Funnel attribution contributions reconcile exactly to the target "
            "loss-rate delta within numeric tolerance."
        ),
        "Loss and denominator-mix components are additive.",
        "Inspect additive journey components and retry from an ungrouped funnel delta.",
        help_target="attribute",
    ),
    ConstraintId.EVENT_WINDOW_VALID: _constraint(
        ConstraintId.EVENT_WINDOW_VALID,
        "InvalidEventPattern",
        "runtime",
        ("events.match", "TimeScope"),
        "Event Journey cohort and follow-up bounds are explicit.",
        "The first occurrence is anchored in a half-open cohort window while completion follow-up includes completion_through.",
        "Pass mv.time_scope(start=..., end=...) and completion_through greater than or equal to its end.",
        help_target="events.match",
    ),
    ConstraintId.EVENT_COMPLETENESS_VALID: _constraint(
        ConstraintId.EVENT_COMPLETENESS_VALID,
        "InvalidCompletenessDeclaration",
        "runtime",
        ("events.match", "CompletenessDeclaration"),
        "Completeness declarations cover exact Event inputs in the active pattern.",
        "Caller declarations are validity evidence and cannot be reused for unrelated or overlapping Event inputs.",
        "Build declarations with mv.declared_complete_through(inputs=(event_ref,), through=..., rationale=...).",
        help_target="events.match",
    ),
    ConstraintId.FRAME_IMMUTABLE: _constraint(
        ConstraintId.FRAME_IMMUTABLE,
        "FrameMutation",
        "runtime",
        ("BaseFrame", "MetricFrame", "DeltaFrame", "AttributionFrame", "CandidateSet"),
        "Persisted frames are immutable through the analysis wrapper.",
        "Lineage and persisted metadata assume frame contents do not change after materialization.",
        "Call frame.to_pandas() and mutate the copy when ad hoc analysis needs local changes.",
        help_target="boundary.to_pandas",
    ),
    ConstraintId.FRAME_READ_BOUNDS: _constraint(
        ConstraintId.FRAME_READ_BOUNDS,
        "FrameRead",
        "runtime",
        ("BaseFrame", "MetricFrame", "DeltaFrame", "CandidateSet"),
        "Frame read helpers enforce bounded inspection arguments.",
        "Help and show APIs should stay small enough for agents and terminals.",
        "Use frame.show() for bounded inspection, or frame.to_pandas() for terminal custom analysis.",
        help_target="artifacts.reading",
    ),
    ConstraintId.FRAME_META_INVALID: _constraint(
        ConstraintId.FRAME_META_INVALID,
        "FrameMetaInvalid",
        "runtime",
        (
            "BaseFrame",
            "MetricFrame",
            "DeltaFrame",
            "CandidateSet",
            "EventFrame",
            "LifecycleFrame",
            "AttributionFrame",
        ),
        "Frame metadata must match the current analysis-artifact schema.",
        "Persisted metadata records schema, semantic shape, and identity; stale or corrupt metadata cannot produce a typed frame.",
        "Read the Location line on this error against the current schema; when the Location names a frame ref, inspect the artifact's meta.json on disk. Then re-run the producing intent or delete the stale artifact so it is regenerated.",
        help_target="session.artifact",
    ),
    ConstraintId.BACKEND_FACTORY_CONFIGURED: _constraint(
        ConstraintId.BACKEND_FACTORY_CONFIGURED,
        "NoBackendFactory",
        "runtime",
        ("session", "observe", "datasources"),
        "Materializing analysis intents need a configured ibis backend factory.",
        "Observe and related intents need a live backend to compile and execute semantic metrics.",
        "Register the real project datasource and resume the same session by id, or resume it with an explicit backend override.",
        help_target="runtime.sessions",
        docs_ref=_DATASOURCE_DOC,
    ),
    ConstraintId.DATASOURCE_CONFIGURED: _constraint(
        ConstraintId.DATASOURCE_CONFIGURED,
        "DatasourceMissing",
        "runtime",
        ("datasources", "session", "observe"),
        "Named datasources must exist before analysis runtime lookup.",
        "Datasource-backed sessions resolve semantic source refs through persisted datasource metadata.",
        "Register the datasource with md.register(...) before creating or attaching the session.",
        docs_ref=_DATASOURCE_DOC,
    ),
    ConstraintId.DATASOURCE_ENV_AVAILABLE: _constraint(
        ConstraintId.DATASOURCE_ENV_AVAILABLE,
        "DatasourceEnvVarMissing",
        "runtime",
        ("datasources", "session"),
        "Datasource secret environment variables must be available at runtime.",
        "The datasource contract stores secret references, not plaintext credentials.",
        "Export the referenced environment variable or validate it with md.test(...), which attempts to cache it.",
        docs_ref=_DATASOURCE_DOC,
    ),
    ConstraintId.DATASOURCE_BACKEND_SUPPORTED: _constraint(
        ConstraintId.DATASOURCE_BACKEND_SUPPORTED,
        "DatasourceBackendTypeUnsupported",
        "runtime",
        ("datasources", "session"),
        "Datasource backend_type must have a registered backend adapter.",
        "The analysis runtime can only create ibis connections for supported datasource backend types.",
        "Use a supported backend_type or add an adapter before relying on datasource auto-loading.",
        docs_ref=_DATASOURCE_DOC,
    ),
    ConstraintId.SOURCE_BINDINGS_EXACT: _constraint(
        ConstraintId.SOURCE_BINDINGS_EXACT,
        "SourceBinding",
        "runtime",
        ("Session.source_bindings", "SourceBindingError"),
        "Source bindings belong to one Session runtime and use exact scalar or flat non-empty scalar-list values.",
        "Session-local ownership prevents one analysis from reusing another session's request values, while exact names keep request and artifact identity aligned.",
        "Use exact ms.ref.entity(...) keys and provide every non-secret md.source_param(...) value with no extras; lists must be flat and non-empty.",
        help_target="Session.source_bindings",
        docs_ref=_DATASOURCE_DOC,
    ),
    ConstraintId.COMPONENT_FRAME_AVAILABLE: _constraint(
        ConstraintId.COMPONENT_FRAME_AVAILABLE,
        "ComponentFrameUnavailable",
        "runtime",
        ("MetricFrame", "DeltaFrame", "ComponentFrame", "components"),
        "Observed MetricFrames require a persisted recursive component graph.",
        "Every graph root retains evaluator, child-role, quality, coverage, presentation, and governed-leaf lineage state.",
        "Re-run session.observe(...) when component_ref is absent or its ComponentFrame cannot be loaded.",
        help_target="artifacts.quality_projection",
    ),
    ConstraintId.ATTRIBUTION_ADDITIVITY_COMPATIBLE: _constraint(
        ConstraintId.ATTRIBUTION_ADDITIVITY_COMPATIBLE,
        "AttributionAdditivity",
        "runtime",
        (
            "attribute",
            "decompose",
            "DeltaFrame",
            "AttributionAdditivityError",
        ),
        "Axis attribution requires compatible persisted additivity: additive, semi-additive "
        "off the status time axis, component-aware ratio/weighted-mean, or a Tier-1 mean "
        "lowered to sum/count_non_null components. If a DeltaFrame reports "
        "attribution_shape=weighted_mix lowered_from=mean, call attribute directly: its "
        "Tier-1 mean is already lowered to sum/count_non_null components, so do not manually "
        "split numerator and denominator. Graph-owned count_distinct and supported quantiles "
        "also call attribute directly when DeltaFrame.contract().attribute_admission is "
        "supported. Other non-additive aggregates remain blocked until they have an approved "
        "distribution-aware attribution basis.",
        "Axis-sum attribution is valid for additive metrics, semi-additive metrics away "
        "from their status time axis, component-aware ratio or weighted-mean deltas, and "
        "Tier-1 means with persisted sum/count_non_null components.",
        "Inspect DeltaFrame.contract().attribute_admission; re-observe and compare legacy "
        "artifacts, or author an approved attribution basis for the aggregate.",
        help_target="attribute",
    ),
    ConstraintId.ATTRIBUTION_RECONCILIATION: _constraint(
        ConstraintId.ATTRIBUTION_RECONCILIATION,
        "AttributionReconciliation",
        "runtime",
        ("attribute", "decompose", "AttributionFrame", "ComponentDecompositionError"),
        "Attribution emits share_of_total_delta plus positive- and negative-pool shares; "
        "new and churned component rows keep exact one-sided contributions, and every "
        "deepest partition must reconcile to its independently computed total delta.",
        "The AttributionFrame show card reports total, contribution, one-sided, "
        "unattributed, and residual reconciliation facts instead of hiding missing rows "
        "behind a normalized percentage.",
        "Inspect the reconciliation card and component rows; repair invalid component "
        "weights or inputs before retrying if attribution fails closed.",
        help_target="attribute",
    ),
    ConstraintId.ATTRIBUTION_AXIS_COLUMN_COMPATIBLE: _constraint(
        ConstraintId.ATTRIBUTION_AXIS_COLUMN_COMPATIBLE,
        "SemanticKindMismatch",
        "runtime",
        ("attribute", "decompose", "AttributionFrame"),
        "Single-axis attribution preserves the resolved dimension name only when it does "
        "not collide with attribution result, value, or panel bucket columns.",
        "A flat pandas result cannot represent a dimension and an attribution measure under "
        "the same column name; evidence fields use an explicit metadata mapping instead.",
        "Rename the semantic dimension to a non-reserved name, reload the catalog, then "
        "re-observe and compare before retrying attribution.",
        help_target="attribute",
    ),
    ConstraintId.CUMULATIVE_COMPARE_COMPATIBLE: _constraint(
        ConstraintId.CUMULATIVE_COMPARE_COMPATIBLE,
        "CumulativeFrameUnsupported",
        "runtime",
        ("compare", "MetricFrame", "DeltaFrame"),
        "Cumulative compare supports trailing, grain_to_date, and all_history anchors; "
        "every outer component must resolve to one compatible anchor, trailing uses canonical "
        "fixed duration, grain_to_date uses one reset grain, and all_history rows carry exact "
        "evaluation_end coordinates.",
        "A derived cumulative frame is comparable only when every outer component is "
        "cumulative and all components share the same anchor; mixed or unresolved component "
        "anchors are rejected. Comparable-period deltas keep paired ordinal, day-of-week, "
        "progress, or correspondence coordinates only; all-history source revision remains "
        "unverified.",
        "Re-observe both sides under the current cumulative contract, then compare compatible "
        "frames with at least one shared business coordinate.",
        help_target="compare",
    ),
    ConstraintId.CUMULATIVE_ATTRIBUTION_ROUTE_COMPATIBLE: _constraint(
        ConstraintId.CUMULATIVE_ATTRIBUTION_ROUTE_COMPATIBLE,
        "AttributeAdmissionBlocked",
        "runtime",
        ("attribute", "DeltaFrame"),
        "Cumulative attribution selects one exact business-axis or accumulation-time route.",
        "Business dimensions replay cumulative endpoint levels; exactly the cumulative over "
        "axis replays additive base flow; mixed routes and unsupported base structures block.",
        "Inspect DeltaFrame.contract().cumulative_attribution and request one supported route.",
        help_target="attribute",
    ),
    ConstraintId.RUNTIME_METRIC_CLOSED_ALGEBRA: _constraint(
        ConstraintId.RUNTIME_METRIC_CLOSED_ALGEBRA,
        "SemanticKindMismatch",
        "runtime",
        (
            "runtime_metric.aggregate",
            "runtime_metric.slice",
            "runtime_metric.weighted_mean",
            "runtime_metric.ratio",
            "runtime_metric.linear",
            "RuntimeMetricExpression",
        ),
        "Runtime metrics use a closed recursive algebra over governed refs.",
        "Closed descriptors preserve typed planning, replay, lineage, units, and quality facts without creating catalog authority.",
        "Use exact Ref[measure], Ref[metric], Ref[dimension], or Ref[time_dimension] values and materialize the descriptor only through session.observe(...).",
        help_target="runtime_metric",
    ),
    ConstraintId.RUNTIME_METRIC_FOLD_REQUIRES_SEMI_ADDITIVE: _constraint(
        ConstraintId.RUNTIME_METRIC_FOLD_REQUIRES_SEMI_ADDITIVE,
        "runtime-metric-fold-requires-semi-additive",
        "runtime",
        ("runtime_metric.aggregate", "RuntimeAggregateExpr"),
        "Runtime aggregates inherit a semi-additive measure's default fold; an explicit fold only overrides that governed contract.",
        "A semi-additive measure supplies the governed status-time axis and default fold; an explicit fold only overrides that default and cannot create an axis for another measure.",
        "Use a semi-additive measure to inherit its fold, override that fold explicitly when needed, or omit fold for a non-semi-additive measure.",
        help_target="runtime_metric",
    ),
    ConstraintId.RUNTIME_WEIGHTED_MEAN_VALID: _constraint(
        ConstraintId.RUNTIME_WEIGHTED_MEAN_VALID,
        "MetricShapeUnsupported",
        "runtime",
        ("runtime_metric.weighted_mean", "RuntimeWeightedMeanExpr"),
        "Runtime weighted means require same-entity measures and an additive weight.",
        "The value and weight must be evaluated on the same physical rows so null pairing and row-level multiplication remain exact.",
        "Pass exact loaded Ref[measure] values from the same entity and choose an additive measure for weight.",
        help_target="runtime_metric",
    ),
    ConstraintId.RUNTIME_LINEAR_UNITS_COMMENSURABLE: _constraint(
        ConstraintId.RUNTIME_LINEAR_UNITS_COMMENSURABLE,
        "MetricShapeUnsupported",
        "runtime",
        ("runtime_metric.linear", "RuntimeLinearExpr"),
        "Runtime linear terms require commensurable units.",
        "Addition and subtraction preserve business meaning only when every known term unit agrees.",
        "Use exact governed metric refs or runtime expressions with commensurable units; author a durable semantic metric when the business conversion requires an explicit modeling decision.",
        help_target="runtime_metric",
    ),
}

_DEFAULT_BY_ERROR_KIND: dict[str, str] = {}
for _constraint_obj in CONSTRAINTS.values():
    _DEFAULT_BY_ERROR_KIND.setdefault(_constraint_obj.error_kind, _constraint_obj.id)


def get_constraint(id: ConstraintId | str) -> Constraint | None:
    """Return a constraint by id."""

    try:
        constraint_id = id if isinstance(id, ConstraintId) else ConstraintId(id)
    except ValueError:
        return None
    return CONSTRAINTS.get(constraint_id)


def iter_constraints() -> tuple[Constraint, ...]:
    """Return all constraints in declaration order."""

    return tuple(CONSTRAINTS.values())


def constraints_for_symbol(symbol: str) -> tuple[Constraint, ...]:
    """Return constraints whose applies_to includes *symbol*."""

    return tuple(c for c in CONSTRAINTS.values() if symbol in c.applies_to)


def constraints_for_error_kind(error_kind: str) -> tuple[Constraint, ...]:
    """Return constraints that map to an analysis error kind."""

    return tuple(c for c in CONSTRAINTS.values() if c.error_kind == error_kind)


def default_constraint_for_error_kind(error_kind: str) -> Constraint | None:
    """Return the default constraint for an analysis error kind."""

    constraint_id = _DEFAULT_BY_ERROR_KIND.get(error_kind)
    if constraint_id is None:
        return None
    return get_constraint(constraint_id)


def default_hint_for_error_kind(error_kind: str) -> str | None:
    """Return the catalog-backed default hint for an analysis error kind."""

    constraint = default_constraint_for_error_kind(error_kind)
    return constraint.hint if constraint is not None else None
