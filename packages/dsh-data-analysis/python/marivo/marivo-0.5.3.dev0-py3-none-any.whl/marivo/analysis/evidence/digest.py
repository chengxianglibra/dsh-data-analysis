"""Private operator-local rules for building bounded artifact digests."""

from __future__ import annotations

from collections.abc import Callable, Iterable
from dataclasses import dataclass
from typing import TypedDict, cast

from marivo.analysis.evidence.identity import (
    make_digest_fingerprint,
    make_digest_item_id,
)
from marivo.analysis.evidence.types import (
    AnalysisScope,
    AnomalyCandidate,
    AnomalyCandidateFindingValue,
    ArtifactDigest,
    AssociationFact,
    AssociationFindingValue,
    ChangeFact,
    ContributionFact,
    ContributionFindingValue,
    DeltaFindingValue,
    DerivationRule,
    DigestItem,
    DigestItemKind,
    EvidenceScope,
    EvidenceSubject,
    FallbackReason,
    Finding,
    ForecastOutput,
    ForecastPointFindingValue,
    InferenceBoundary,
    MetricValueFindingValue,
    ObservationFact,
    ObservationFindingValue,
    OmissionSummary,
    OperatorSemantics,
    QualityCheckFindingValue,
    QualityCheckResult,
    QualitySummary,
    RawFallback,
    Subject,
    TestDecision,
    TestFindingValue,
)

_ITEM_LIMIT = 5
_BOUNDARY_LIMIT = 3


@dataclass(frozen=True)
class _RuleEntry:
    rule_id: str
    rule_version: str
    accepted_finding_kinds: tuple[str, ...]
    produced_item_kinds: tuple[DigestItemKind, ...]
    source_fields: tuple[str, ...]
    sort_key: Callable[[Finding], tuple[int, str, str]]


def _default_sort_key(finding: Finding) -> tuple[int, str, str]:
    rank = getattr(finding.value, "rank", None)
    return (
        rank if isinstance(rank, int) else 2**31 - 1,
        finding.canonical_item_key,
        finding.finding_id,
    )


def _ordered_findings(
    *,
    operator_name: str,
    scope: EvidenceScope,
    findings: tuple[Finding, ...],
    entry: _RuleEntry,
) -> tuple[Finding, ...]:
    """Order current digest findings without depending on extraction order."""
    if operator_name != "observe" or not isinstance(scope, AnalysisScope):
        return tuple(sorted(findings, key=entry.sort_key))

    metric_ids = scope.metric_ids
    if len(metric_ids) <= 1:
        return tuple(sorted(findings, key=entry.sort_key))

    positions = {metric_id: index for index, metric_id in enumerate(metric_ids)}
    for finding in findings:
        if finding.finding_type != "observation":
            continue
        finding_subject = finding.subject
        metric_id = finding_subject.metric if isinstance(finding_subject, Subject) else None
        if metric_id is None:
            raise ValueError("multi-metric observe digest requires a metric subject on every item")
        if metric_id not in positions:
            raise ValueError(
                f"multi-metric observe digest subject {metric_id!r} is outside analysis scope"
            )

    def metric_order_key(finding: Finding) -> tuple[int, str, str]:
        finding_subject = finding.subject
        metric_id = finding_subject.metric if isinstance(finding_subject, Subject) else None
        return (
            positions.get(metric_id, len(positions)) if metric_id is not None else len(positions),
            finding.canonical_item_key,
            finding.finding_id,
        )

    return tuple(sorted(findings, key=metric_order_key))


_RULES: dict[str, _RuleEntry] = {
    "observe": _RuleEntry(
        rule_id="digest.observe",
        rule_version="v1",
        accepted_finding_kinds=("observation", "metric_value"),
        produced_item_kinds=("observation",),
        source_fields=("value.row_count", "value.value"),
        sort_key=_default_sort_key,
    ),
    "events.match": _RuleEntry(
        rule_id="digest.event_journey",
        rule_version="v1",
        accepted_finding_kinds=("observation",),
        produced_item_kinds=("observation",),
        source_fields=(
            "value.attempt_count",
            "value.complete_count",
            "value.incomplete_count",
            "value.coverage_censored_count",
            "value.unused_event_count",
        ),
        sort_key=_default_sort_key,
    ),
    "events.funnel": _RuleEntry(
        rule_id="digest.event_funnel",
        rule_version="v1",
        accepted_finding_kinds=("observation",),
        produced_item_kinds=("observation",),
        source_fields=(
            "value.cohort_count",
            "value.step_count",
            "value.axis_tuple_count",
            "value.reconciliation_passed",
            "value.source_unused_event_count",
            "value.steps",
        ),
        sort_key=_default_sort_key,
    ),
    "events.time_to_event": _RuleEntry(
        rule_id="digest.event_time_to_event",
        rule_version="v1",
        accepted_finding_kinds=("observation",),
        produced_item_kinds=("observation",),
        source_fields=(
            "value.qualifying_count",
            "value.complete_count",
            "value.incomplete_count",
            "value.coverage_censored_count",
            "value.source_unused_end_count",
            "value.median_duration_seconds",
        ),
        sort_key=_default_sort_key,
    ),
    "select_subjects": _RuleEntry(
        rule_id="digest.subject_set",
        rule_version="v1",
        accepted_finding_kinds=("observation",),
        produced_item_kinds=("observation",),
        source_fields=(
            "value.selected_count",
            "value.excluded_coverage_censored_count",
            "value.coverage_status",
        ),
        sort_key=_default_sort_key,
    ),
    "compare": _RuleEntry(
        rule_id="digest.compare",
        rule_version="v1",
        accepted_finding_kinds=("delta",),
        produced_item_kinds=("change",),
        source_fields=(
            "value.current",
            "value.baseline",
            "value.magnitude",
            "value.relative_delta",
            "value.relative_delta_undefined_reason",
            "value.direction",
            "value.presence",
            "value.unit",
            "value.dimension_keys",
        ),
        sort_key=_default_sort_key,
    ),
    "attribute": _RuleEntry(
        rule_id="digest.contribution",
        rule_version="v1",
        accepted_finding_kinds=("decomposition_item",),
        produced_item_kinds=("contribution",),
        source_fields=(
            "value.dimension",
            "value.dimension_keys",
            "value.contribution_value",
            "value.contribution_share",
            "value.contribution_rank",
            "value.decomposition_method",
            "value.reconciliation_residual",
        ),
        sort_key=_default_sort_key,
    ),
    "correlate": _RuleEntry(
        rule_id="digest.association",
        rule_version="v1",
        accepted_finding_kinds=("correlation_result",),
        produced_item_kinds=("association",),
        source_fields=(
            "value.left_ref",
            "value.right_ref",
            "value.method",
            "value.coefficient",
            "value.p_value",
            "value.confidence_interval",
            "value.sample_size",
            "value.join_basis",
            "value.lag",
        ),
        sort_key=_default_sort_key,
    ),
    "hypothesis_test": _RuleEntry(
        rule_id="digest.test_decision",
        rule_version="v1",
        accepted_finding_kinds=("test_result",),
        produced_item_kinds=("test_decision",),
        source_fields=(
            "value.null_predicate",
            "value.alternative",
            "value.method",
            "value.alpha",
            "value.statistic",
            "value.p_value",
            "value.effect_estimate",
            "value.confidence_interval",
            "value.reject_null",
            "value.sample_size",
        ),
        sort_key=_default_sort_key,
    ),
    "forecast": _RuleEntry(
        rule_id="digest.forecast",
        rule_version="v1",
        accepted_finding_kinds=("forecast_point",),
        produced_item_kinds=("forecast_output",),
        source_fields=(
            "value.bucket_start",
            "value.bucket_end",
            "value.predicted_value",
            "value.prediction_interval",
            "value.horizon_index",
            "value.model",
            "value.training_scope",
            "value.evaluation_scope",
        ),
        sort_key=_default_sort_key,
    ),
    "discover": _RuleEntry(
        rule_id="digest.anomaly_candidate",
        rule_version="v1",
        accepted_finding_kinds=("anomaly_candidate",),
        produced_item_kinds=("anomaly_candidate",),
        source_fields=(
            "value.candidate_ref",
            "value.score",
            "value.detector",
            "value.threshold",
            "value.rank",
            "value.reason_codes",
            "value.flag_level",
            "value.current_value",
            "value.baseline_value",
            "value.deviation_absolute",
            "value.deviation_relative",
        ),
        sort_key=_default_sort_key,
    ),
    "transform": _RuleEntry(
        rule_id="digest.transform",
        rule_version="v1",
        accepted_finding_kinds=(),
        produced_item_kinds=(),
        source_fields=(),
        sort_key=_default_sort_key,
    ),
    "select_metric": _RuleEntry(
        rule_id="digest.select_metric",
        rule_version="v1",
        accepted_finding_kinds=(),
        produced_item_kinds=(),
        source_fields=(),
        sort_key=_default_sort_key,
    ),
}
for _funnel_operator in ("compare.funnel", "attribute.funnel_loss_rate"):
    _RULES[_funnel_operator] = _RuleEntry(
        rule_id=f"digest.{_funnel_operator}",
        rule_version="v1",
        accepted_finding_kinds=("observation",),
        produced_item_kinds=("observation",),
        source_fields=("value.row_count", "value.value"),
        sort_key=_default_sort_key,
    )
for _lifecycle_operator in (
    "lifecycle.replay",
    "lifecycle.distribution",
    "lifecycle.transitions",
    "lifecycle.dwell",
    "lifecycle.violations",
):
    _RULES[_lifecycle_operator] = _RuleEntry(
        rule_id=f"digest.{_lifecycle_operator}",
        rule_version="v1",
        accepted_finding_kinds=("observation",),
        produced_item_kinds=("observation",),
        source_fields=("value.row_count", "value.value"),
        sort_key=_default_sort_key,
    )
_OPERATOR_ALIASES = {"decompose": "attribute", "test": "hypothesis_test"}


def _item_derivation(entry: _RuleEntry, finding: Finding) -> DerivationRule:
    return DerivationRule(
        rule_id=entry.rule_id,
        rule_version=entry.rule_version,
        operator=entry.rule_id.removeprefix("digest."),
        source_fields=entry.source_fields,
        source_finding_refs=(finding.finding_id,),
    )


class _CommonItemArgs(TypedDict):
    item_id: str
    artifact_ref: str
    subject: EvidenceSubject
    scope: EvidenceScope
    derivation: DerivationRule


def _common(entry: _RuleEntry, finding: Finding, scope: EvidenceScope) -> _CommonItemArgs:
    item_kind = cast(
        "DigestItemKind",
        {
            "observation": "observation",
            "delta": "change",
            "decomposition_item": "contribution",
            "correlation_result": "association",
            "test_result": "test_decision",
            "forecast_point": "forecast_output",
            "anomaly_candidate": "anomaly_candidate",
            "quality_check": "quality_check",
            "metric_value": "observation",
        }[finding.finding_type],
    )
    refs = (finding.finding_id,)
    return {
        "item_id": make_digest_item_id(
            artifact_ref=finding.artifact_id,
            item_kind=item_kind,
            source_finding_refs=refs,
        ),
        "artifact_ref": finding.artifact_id,
        "subject": finding.subject,
        "scope": scope,
        "derivation": _item_derivation(entry, finding),
    }


def _build_item(entry: _RuleEntry, finding: Finding, scope: EvidenceScope) -> DigestItem | None:
    value = finding.value
    item_scope = value.evaluated_scope if isinstance(value, QualityCheckFindingValue) else scope
    common = _common(entry, finding, item_scope)
    if isinstance(value, ObservationFindingValue):
        return ObservationFact(**common, row_count=value.row_count, value=value.value)
    if isinstance(value, MetricValueFindingValue):
        return None
    if isinstance(value, DeltaFindingValue):
        return ChangeFact(
            **common,
            current=value.current,
            baseline=value.baseline,
            delta=value.magnitude,
            relative_delta=value.relative_delta,
            relative_delta_undefined_reason=value.relative_delta_undefined_reason,
            direction=value.direction,
            presence=value.presence,
            unit=value.unit,
            dimension_keys=value.dimension_keys,
        )
    if isinstance(value, ContributionFindingValue):
        return ContributionFact(
            **common,
            dimension=value.dimension,
            dimension_keys=value.dimension_keys,
            contribution_value=value.contribution_value,
            contribution_share=value.contribution_share,
            contribution_rank=value.contribution_rank,
            decomposition_method=value.decomposition_method,
            reconciliation_residual=value.reconciliation_residual,
            resolution_axis_refs=value.resolution_axis_refs,
            rollup_safe=value.rollup_safe,
            causal_claim=value.causal_claim,
            contribution_std_error=value.contribution_std_error,
            source_error_bound=value.source_error_bound,
        )
    if isinstance(value, AssociationFindingValue):
        return AssociationFact(
            **common,
            left_ref=value.left_ref,
            right_ref=value.right_ref,
            method=value.method,
            coefficient=value.coefficient,
            p_value=value.p_value,
            confidence_interval=value.confidence_interval,
            sample_size=value.sample_size,
            join_basis=value.join_basis,
            lag=value.lag,
        )
    if isinstance(value, TestFindingValue):
        return TestDecision(
            **common,
            null_predicate=value.null_predicate,
            alternative=value.alternative,
            method=value.method,
            alpha=value.alpha,
            statistic=value.statistic,
            p_value=value.p_value,
            effect_estimate=value.effect_estimate,
            confidence_interval=value.confidence_interval,
            reject_null=value.reject_null,
            sample_size=value.sample_size,
        )
    if isinstance(value, ForecastPointFindingValue):
        return ForecastOutput(
            **common,
            bucket_start=value.bucket_start,
            bucket_end=value.bucket_end,
            predicted_value=value.predicted_value,
            prediction_interval=value.prediction_interval,
            horizon_index=value.horizon_index,
            model=value.model,
            training_scope=value.training_scope,
            evaluation_scope=value.evaluation_scope,
        )
    if isinstance(value, AnomalyCandidateFindingValue):
        return AnomalyCandidate(
            **common,
            candidate_ref=value.candidate_ref,
            score=value.score,
            detector=value.detector,
            threshold=value.threshold,
            rank=value.rank,
            reason_codes=value.reason_codes,
            flag_level=value.flag_level,
            current_value=value.current_value,
            baseline_value=value.baseline_value,
            deviation_absolute=value.deviation_absolute,
            deviation_relative=value.deviation_relative,
        )
    if isinstance(value, QualityCheckFindingValue):
        return QualityCheckResult(
            **common,
            check_id=value.check_id,
            measured_value=value.measured_value,
            expectation_predicate=value.expectation_predicate,
            expectation_parameters=value.expectation_parameters,
            expectation_condition_passed=value.expectation_condition_passed,
        )
    raise TypeError(f"unsupported finding value: {type(value).__name__}")


def inference_boundaries_for_operator(
    operator: str,
    findings: Iterable[Finding],
    *,
    omitted_item_count: int = 0,
) -> tuple[InferenceBoundary, ...]:
    """Return the complete inference-boundary projection for one operator.

    Artifact digests retain only the first three entries; selection-wide
    compatibility consumes this complete result so display bounds never erase
    an epistemic boundary.
    """
    operator = _OPERATOR_ALIASES.get(operator, operator)
    if operator not in _RULES:
        raise ValueError(f"no evidence rule registered for operator {operator!r}")
    finding_values = tuple(finding.value for finding in findings)
    result: list[InferenceBoundary] = []
    if omitted_item_count:
        result.append(
            InferenceBoundary(
                kind="full_distribution_not_in_digest",
                reason="digest_bound_exceeded",
                required_evidence=("full_distribution",),
            )
        )
    if operator == "correlate":
        associations = [
            value for value in finding_values if isinstance(value, AssociationFindingValue)
        ]
        if any(value.p_value is None for value in associations):
            result.append(
                InferenceBoundary(
                    kind="significance_not_computed",
                    reason="operator_did_not_compute",
                    required_evidence=("significance_statistic",),
                )
            )
        if any(value.confidence_interval is None for value in associations):
            result.append(
                InferenceBoundary(
                    kind="interval_not_computed",
                    reason="operator_did_not_compute",
                    required_evidence=("uncertainty_interval",),
                )
            )
        result.append(
            InferenceBoundary(
                kind="causal_effect_not_estimated",
                reason="requires_independent_evidence",
                required_evidence=("causal_design",),
            )
        )
    elif operator in {"attribute", "events.funnel"}:
        result.append(
            InferenceBoundary(
                kind="causal_effect_not_estimated",
                reason="requires_independent_evidence",
                required_evidence=("causal_design",),
            )
        )
    elif operator.startswith("lifecycle."):
        result.extend(
            (
                InferenceBoundary(
                    kind="raw_rows_omitted",
                    reason="artifact_does_not_contain",
                    required_evidence=("raw_rows",),
                ),
                InferenceBoundary(
                    kind="causal_effect_not_estimated",
                    reason="requires_independent_evidence",
                    required_evidence=("causal_design",),
                ),
            )
        )
    elif operator == "hypothesis_test" and any(
        isinstance(value, TestFindingValue) and value.confidence_interval is None
        for value in finding_values
    ):
        result.append(
            InferenceBoundary(
                kind="interval_not_computed",
                reason="operator_did_not_compute",
                required_evidence=("uncertainty_interval",),
            )
        )
    elif operator == "forecast":
        result.extend(
            (
                InferenceBoundary(
                    kind="forecast_actual_not_observed",
                    reason="artifact_does_not_contain",
                    required_evidence=("observed_forecast_actual",),
                ),
                InferenceBoundary(
                    kind="forecast_accuracy_not_evaluated",
                    reason="artifact_does_not_contain",
                    required_evidence=("forecast_error_metric",),
                ),
            )
        )
    elif operator == "discover":
        result.append(
            InferenceBoundary(
                kind="candidate_not_reviewed",
                reason="requires_independent_evidence",
                required_evidence=("independent_review",),
            )
        )
    distinct: dict[str, InferenceBoundary] = {}
    for boundary in result:
        distinct.setdefault(boundary.kind, boundary)
    return tuple(distinct.values())


def build_artifact_digest(
    *,
    artifact_ref: str,
    operator: OperatorSemantics,
    subject: EvidenceSubject,
    scope: EvidenceScope,
    findings: Iterable[Finding],
    quality: QualitySummary | None,
    rows_available: bool,
) -> ArtifactDigest:
    """Build one bounded digest from validated in-memory typed findings."""
    operator_name = _OPERATOR_ALIASES.get(operator.operator, operator.operator)
    entry = _RULES.get(operator_name)
    supplied_findings = tuple(findings)
    if entry is None:
        raise ValueError(f"no digest rule registered for operator {operator.operator!r}")
    ordered = _ordered_findings(
        operator_name=operator_name,
        scope=scope,
        findings=supplied_findings,
        entry=entry,
    )
    for finding in ordered:
        if finding.artifact_id != artifact_ref:
            raise ValueError("every finding must belong to the digest artifact")
        if finding.finding_type not in entry.accepted_finding_kinds:
            raise ValueError(
                f"{operator.operator} digest does not accept {finding.finding_type} findings"
            )
    all_items = tuple(
        item for finding in ordered if (item := _build_item(entry, finding, scope)) is not None
    )
    retained = all_items[:_ITEM_LIMIT]
    omitted_items = all_items[_ITEM_LIMIT:]
    omitted_kinds = tuple(dict.fromkeys(item.kind for item in omitted_items))
    boundaries = inference_boundaries_for_operator(
        operator_name,
        ordered,
        omitted_item_count=len(omitted_items),
    )[:_BOUNDARY_LIMIT]
    fallback_reasons: list[FallbackReason] = ["unregistered_question"]
    if omitted_items:
        fallback_reasons.append("omitted_item_detail")
    if rows_available:
        fallback_reasons.append("row_level_validation")
    payload = {
        "digest_version": "v2",
        "artifact_ref": artifact_ref,
        "operator": operator,
        "subject": subject,
        "scope": scope,
        "items": retained,
        "boundaries": boundaries,
        "omissions": OmissionSummary(
            retained_items=len(retained),
            omitted_items=len(omitted_items),
            omitted_kinds=omitted_kinds,
            bounded=bool(omitted_items),
        ),
        "quality": quality,
        "fallback": RawFallback(
            artifact_ref=artifact_ref,
            findings_available=bool(ordered),
            rows_available=rows_available,
            recommended_when=tuple(fallback_reasons),
        ),
        "fingerprint": "",
    }
    digest = ArtifactDigest.model_validate(payload)
    return digest.model_copy(update={"fingerprint": make_digest_fingerprint(digest)})


__all__ = ["build_artifact_digest", "inference_boundaries_for_operator"]
