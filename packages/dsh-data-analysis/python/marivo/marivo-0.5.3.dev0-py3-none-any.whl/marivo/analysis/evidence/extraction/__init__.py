"""Frame -> canonical finding extractors."""
