"""Extract anomaly_candidate findings from a CandidateSet DataFrame."""

from __future__ import annotations

# mypy: disable-error-code=import-untyped
from datetime import datetime
from typing import Any

import pandas as pd

from marivo.analysis.evidence.identity import make_finding_id, make_typed_item_key
from marivo.analysis.evidence.types import (
    AnomalyCandidateFindingValue,
    DerivationRule,
    Finding,
    Subject,
)


def _is_missing(value: Any) -> bool:
    return bool(pd.isna(value)) if not isinstance(value, (list, tuple, dict)) else False


def _to_float(value: Any) -> float | None:
    if value is None or _is_missing(value):
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _json_value(value: Any) -> Any:
    if _is_missing(value):
        return None
    return value


def extract_anomaly_candidate_findings(
    *,
    df: pd.DataFrame,
    artifact_id: str,
    session_id: str,
    subject: Subject,
    committed_at: datetime,
) -> list[Finding]:
    """Extract one finding per anomaly candidate row. Empty input is legal."""
    if df.empty:
        return []

    findings: list[Finding] = []
    ranked_rows = list(df.iterrows())
    ranked_rows.sort(key=lambda entry: -(_to_float(entry[1].get("score")) or 0.0))
    for rank, (idx, row) in enumerate(ranked_rows, start=1):
        candidate_ref = _json_value(row["candidate_ref"]) if "candidate_ref" in row.index else None
        if candidate_ref is None:
            candidate_identity = f"row:{idx}"
            item_key = make_typed_item_key(
                namespace="anomaly_candidate",
                context={"identity_source": "row_index"},
                coordinates={"row_index": idx},
            )
        else:
            candidate_identity = str(candidate_ref)
            item_key = make_typed_item_key(
                namespace="anomaly_candidate",
                context={"identity_source": "candidate_ref"},
                coordinates={"candidate_ref": candidate_ref},
            )
        findings.append(
            Finding(
                finding_id=make_finding_id(
                    artifact_id=artifact_id,
                    finding_type="anomaly_candidate",
                    canonical_item_key=item_key,
                ),
                finding_type="anomaly_candidate",
                epistemic_kind="candidate",
                artifact_id=artifact_id,
                session_id=session_id,
                subject=subject,
                canonical_item_key=item_key,
                value=AnomalyCandidateFindingValue(
                    candidate_ref=candidate_identity,
                    score=_to_float(row.get("score")),
                    detector=str(row.get("detector") or "point_anomaly_detector"),
                    threshold=_to_float(row.get("threshold")),
                    rank=rank,
                    reason_codes=tuple(str(code) for code in (row.get("reason_codes") or ()))
                    if isinstance(row.get("reason_codes"), (list, tuple))
                    else (),
                    flag_level=(
                        str(row.get("flag_level"))
                        if not _is_missing(row.get("flag_level"))
                        else None
                    ),
                    current_value=_to_float(row.get("observed_value")),
                    baseline_value=_to_float(row.get("baseline_value")),
                    deviation_absolute=_to_float(row.get("delta")),
                    deviation_relative=_to_float(row.get("deviation_relative")),
                ),
                derivation=DerivationRule(
                    rule_id="extract.anomaly_candidate",
                    rule_version="v3",
                    operator="discover",
                    source_fields=tuple(str(column) for column in df.columns),
                    source_finding_refs=(),
                ),
                source_refs=(artifact_id,),
                committed_at=committed_at,
            )
        )
    return findings


__all__ = ["extract_anomaly_candidate_findings"]
