"""File-system layout and byte I/O for analysis sessions.

Separates path/directory structure from metadata persistence (which now
belongs to the SQLite store in ``_store.py``).  This module owns:

- ``PersistenceLayout`` — directory paths for a session.
- ``_atomic_write_text`` — safe text writes via temp + rename.
- ``write_job_record`` / ``read_job_record`` / ``list_job_ids`` — job JSON I/O.
- ``write_frame_to_disk`` — public frame parquet, private frame-owned
  auxiliary Parquet payloads, and meta.json I/O.
- ``read_frame_from_disk`` — low-level public frame parquet and meta.json I/O;
  typed cold recovery validates auxiliary payloads in ``session._load``.

This module does **not** expose ``read_session_meta`` or
``write_session_meta``; session metadata lives in the SQLite store.
"""

from __future__ import annotations

# mypy: disable-error-code=import-untyped
import json
import os
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any, cast

import pandas as pd

from marivo.analysis.frames._content_hash import (
    compute_file_content_hash,
    compute_frame_content_hash,
)
from marivo.analysis.frames.base import (
    BaseFrame,
    BaseFrameMeta,
    _FrameAuxiliaryReceipt,
)
from marivo.analysis.refs import ArtifactRef


@dataclass(frozen=True)
class PersistenceLayout:
    """Directory layout for a single analysis session.

    Args:
        project_root: The project root directory (contains ``.marivo/``).
        session_id: The session identifier (``sess_...``).

    Example:
        >>> layout = PersistenceLayout(project_root=Path("/my/project"), session_id="sess_abc")
        >>> layout.session_dir
        PosixPath('/my/project/.marivo/analysis/sessions/sess_abc')
    """

    project_root: Path
    session_id: str

    @property
    def analysis_dir(self) -> Path:
        return Path(self.project_root) / ".marivo" / "analysis"

    @property
    def sessions_dir(self) -> Path:
        return self.analysis_dir / "sessions"

    @property
    def session_dir(self) -> Path:
        return self.sessions_dir / self.session_id

    @property
    def jobs_dir(self) -> Path:
        return self.session_dir / "jobs"

    @property
    def frames_dir(self) -> Path:
        return self.session_dir / "frames"

    @property
    def scripts_dir(self) -> Path:
        return self.session_dir / "scripts"

    @property
    def store_db(self) -> Path:
        """Path to the SQLite session store database."""
        return self.analysis_dir / "session_store.db"

    def relative_path(self, absolute_path: Path) -> str:
        """Convert an absolute path under project_root to a project-relative string.

        The store records paths relative to ``project_root`` so that the
        database remains valid if the project directory is moved.

        Args:
            absolute_path: An absolute path that is a descendant of
                ``project_root``.

        Returns:
            A POSIX-style relative path string (using ``/`` as separator).

        Raises:
            ValueError: If *absolute_path* is not under ``project_root``.
        """
        try:
            return str(absolute_path.relative_to(self.project_root))
        except ValueError:
            raise ValueError(
                f"path {absolute_path!s} is not under project root {self.project_root!s}"
            ) from None


def _atomic_write_text(path: Path, data: str) -> None:
    """Write *data* to *path* atomically via temp file + rename.

    Creates parent directories as needed.  On failure the temp file is
    cleaned up and the original file (if any) is left untouched.
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_name = tempfile.mkstemp(dir=str(path.parent), prefix=".tmp_", suffix=path.name)
    try:
        with os.fdopen(fd, "w") as f:
            f.write(data)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp_name, path)
    except BaseException:
        if os.path.exists(tmp_name):
            os.unlink(tmp_name)
        raise


def write_job_record(layout: PersistenceLayout, record: dict[str, Any]) -> None:
    """Persist a job record as a JSON file in the session jobs directory.

    Args:
        layout: Session layout providing directory paths.
        record: Job record dict; must contain an ``"id"`` key.
    """
    _atomic_write_text(
        layout.jobs_dir / f"{record['id']}.json",
        json.dumps(record, indent=2, sort_keys=True),
    )


def read_job_record(layout: PersistenceLayout, job_id: str) -> dict[str, Any]:
    """Read a job record JSON file from the session jobs directory.

    Args:
        layout: Session layout providing directory paths.
        job_id: The job identifier (used as the filename stem).

    Returns:
        The parsed job record dict.
    """
    return cast("dict[str, Any]", json.loads((layout.jobs_dir / f"{job_id}.json").read_text()))


def list_job_ids(layout: PersistenceLayout) -> list[str]:
    """Return sorted job ids for the session.

    Args:
        layout: Session layout providing directory paths.

    Returns:
        Sorted list of job id strings, or an empty list if the jobs
        directory does not exist.
    """
    if not layout.jobs_dir.is_dir():
        return []
    return sorted(path.stem for path in layout.jobs_dir.glob("*.json"))


def write_frame_to_disk(layout: PersistenceLayout, frame: BaseFrame) -> BaseFrameMeta:
    """Write a frame's data and metadata to the session frames directory.

    Writes ``data.parquet``, any private frame-owned auxiliary tables, and a
    ``meta.json`` sidecar. Every Parquet write uses temp + rename. Auxiliary
    receipts are bound into metadata before the parent content hash is built.

    Args:
        layout: Session layout providing directory paths.
        frame: The frame to persist.

    Returns:
        Updated ``BaseFrameMeta`` with the on-disk ``byte_size`` and
        ``content_hash`` populated.
    """
    frame_dir = layout.frames_dir / frame.meta.ref
    frame_dir.mkdir(parents=True, exist_ok=True)

    data_path = frame_dir / "data.parquet"
    _atomic_write_parquet(frame._df, data_path)

    auxiliary_tables = frame._auxiliary_tables()
    filenames = tuple(table.filename for table in auxiliary_tables)
    if len(set(filenames)) != len(filenames):
        raise ValueError("frame auxiliary table filenames must be unique")
    receipts: list[_FrameAuxiliaryReceipt] = []
    for table in auxiliary_tables:
        auxiliary_path = frame_dir / table.filename
        _atomic_write_parquet(table.dataframe, auxiliary_path)
        receipts.append(
            _FrameAuxiliaryReceipt(
                filename=table.filename,
                row_count=len(table.dataframe),
                byte_size=auxiliary_path.stat().st_size,
                content_hash=compute_file_content_hash(auxiliary_path),
            )
        )

    byte_size = data_path.stat().st_size + sum(item.byte_size for item in receipts)
    without_hash = frame.meta.model_copy(update={"byte_size": byte_size})
    without_hash = frame._bind_auxiliary_receipts(without_hash, tuple(receipts))
    content_hash = compute_frame_content_hash(meta=without_hash, data_path=data_path)
    updated = without_hash.model_copy(update={"content_hash": content_hash})
    _atomic_write_text(frame_dir / "meta.json", updated.model_dump_json(indent=2))
    return updated


def _atomic_write_parquet(frame: pd.DataFrame, path: Path) -> None:
    """Write one Parquet payload atomically beside its final destination.

    ``use_dictionary=False`` is deliberate: pyarrow 25.0.0 has a race in
    multithreaded reads of dictionary-encoded pages that intermittently raises
    ``ArrowInvalid: Index not in dictionary bounds`` (issue #77). Disabling
    dictionary encoding at write time makes the resulting files immune to the
    reader-side race without pinning or upgrading pyarrow.
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_name = tempfile.mkstemp(
        dir=str(path.parent),
        prefix=".tmp_",
        suffix=f"_{path.name}",
    )
    os.close(fd)
    try:
        frame.to_parquet(
            tmp_name,
            engine="pyarrow",
            compression="snappy",
            index=False,
            use_dictionary=False,
        )
        os.replace(tmp_name, path)
    except BaseException:
        if os.path.exists(tmp_name):
            os.unlink(tmp_name)
        raise


def _is_dictionary_bounds_error(exc: BaseException) -> bool:
    """Return True for pyarrow's transient dictionary-decoding race error.

    pyarrow 25.0.0 raises ``ArrowInvalid: Index not in dictionary bounds``
    intermittently when reading dictionary-encoded parquet pages with multiple
    threads (issue #77). Matching the message keeps the retry scoped to this
    specific transient condition so genuine corruption is never masked.
    """
    message = str(exc).lower()
    return "dictionary" in message and "bounds" in message


_DICTIONARY_RACE_RETRIES = 8


def _read_parquet_frame(path: Path) -> pd.DataFrame:
    """Read a frame parquet file, retrying around the pyarrow dictionary race.

    pyarrow 25.0.0 has a race in multithreaded reads of dictionary-encoded
    parquet pages that intermittently raises ``Index not in dictionary
    bounds``. Files written with ``use_dictionary=False`` are immune, but
    legacy files still use dictionary encoding; retrying the read a few times
    makes cache-hits reliable. A genuinely corrupt file fails every attempt
    and its error surfaces to the caller unchanged.
    """
    last_error: BaseException | None = None
    for _ in range(_DICTIONARY_RACE_RETRIES):
        try:
            return pd.read_parquet(path, engine="pyarrow")
        except Exception as exc:
            if not _is_dictionary_bounds_error(exc):
                raise
            last_error = exc
    assert last_error is not None
    raise last_error


def read_frame_from_disk(
    layout: PersistenceLayout,
    frame_ref: str | ArtifactRef,
) -> tuple[pd.DataFrame, dict[str, Any]]:
    """Read a frame's data and metadata from the session frames directory.

    Args:
        layout: Session layout providing directory paths.
        frame_ref: Frame identifier (string or ``ArtifactRef``).

    Returns:
        A ``(DataFrame, meta_dict)`` tuple.
    """
    if isinstance(frame_ref, ArtifactRef):
        frame_ref = frame_ref.ref
    frame_dir = layout.frames_dir / frame_ref
    df = _read_parquet_frame(frame_dir / "data.parquet")
    meta = json.loads((frame_dir / "meta.json").read_text())
    return df, meta
