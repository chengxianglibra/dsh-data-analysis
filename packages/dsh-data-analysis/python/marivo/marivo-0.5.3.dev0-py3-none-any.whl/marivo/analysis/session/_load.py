"""Load persisted analysis frames."""

from __future__ import annotations

import sqlite3
from dataclasses import replace
from pathlib import Path
from typing import TYPE_CHECKING, Any, cast

from pydantic import ValidationError

from marivo._temporal import _trusted_time_scope_validation
from marivo.analysis._cumulative import (
    authored_comparable_period_anchor,
    cumulative_compare_anchor,
    cumulative_equivalent_comparison_semantics,
)
from marivo.analysis.attribution_contract import basis_fingerprint
from marivo.analysis.candidate_identity import (
    validate_candidate_frame_identity,
    validate_semantic_hypothesis_frame_integrity,
)
from marivo.analysis.errors import (
    AnalysisRepair,
    ArtifactNotFoundError,
    CrossSessionFrameError,
    EvidenceStoreUnavailableError,
    FrameCacheCorruptedError,
    FrameMetaInvalidError,
    SchemaVersionMismatchError,
)
from marivo.analysis.evidence.store import EXPECTED_SCHEMA_VERSION
from marivo.analysis.frames._content_hash import (
    compute_file_content_hash,
    compute_frame_content_hash,
)
from marivo.analysis.frames.association import AssociationResult, AssociationResultMeta
from marivo.analysis.frames.attribution import (
    AttributionFrame,
    AttributionFrameMeta,
    FunnelAttributionFrameMeta,
    validate_cumulative_flow_attribution_rows,
    validate_generic_attribution_rows,
)
from marivo.analysis.frames.base import CURRENT_ARTIFACT_SCHEMA_VERSION, BaseFrame
from marivo.analysis.frames.candidate import (
    CandidateSet,
    CandidateSetMeta,
    SemanticHypothesisCandidateSetMeta,
)
from marivo.analysis.frames.component import ComponentFrame, ComponentFrameMeta
from marivo.analysis.frames.coverage import CoverageFrame, CoverageFrameMeta
from marivo.analysis.frames.delta import (
    CumulativeDeltaFrameMetaV1,
    DeltaFrame,
    DeltaFrameMeta,
    FunnelDeltaFrameMeta,
)
from marivo.analysis.frames.event import (
    EventFrame,
    EventFrameMeta,
    EventFunnelFrameMeta,
    EventTimeToEventFrameMeta,
)
from marivo.analysis.frames.forecast import ForecastFrame, ForecastFrameMeta
from marivo.analysis.frames.hypothesis import HypothesisTestResult, HypothesisTestResultMeta
from marivo.analysis.frames.lifecycle import (
    LifecycleDistributionFrameMeta,
    LifecycleDwellFrameMeta,
    LifecycleFrame,
    LifecycleHistoryFrameMeta,
    LifecycleTransitionsFrameMeta,
    LifecycleViolationsFrameMeta,
)
from marivo.analysis.frames.metric import MetricFrame, MetricFrameMeta, _clamp_reaggregatable
from marivo.analysis.frames.subject import SubjectSet, SubjectSetMeta
from marivo.analysis.intents._candidate_columns import (
    CANDIDATE_COLUMNS,
    validate_shape_columns,
)
from marivo.analysis.policies import decode_alignment_policy
from marivo.analysis.refs import ArtifactRef
from marivo.introspection.live.model import LiveHelpTarget
from marivo.semantic.metric_graph import (
    DeltaComparisonSemantics,
    ExactComparisonSemanticsV1,
)
from marivo.semantic.metric_graph_canonical import (
    MetricGraphContractError,
    fingerprint,
    validate_graph,
)

if TYPE_CHECKING:
    from marivo.analysis.session.core import Session

_FRAME_CLASSES = {
    "metric_frame": (MetricFrame, MetricFrameMeta),
    "delta_frame": (DeltaFrame, DeltaFrameMeta),
    "attribution_frame": (AttributionFrame, AttributionFrameMeta),
    "candidate_set": (CandidateSet, CandidateSetMeta),
    "association_result": (AssociationResult, AssociationResultMeta),
    "hypothesis_test_result": (HypothesisTestResult, HypothesisTestResultMeta),
    "forecast_frame": (ForecastFrame, ForecastFrameMeta),
    "event_frame": (EventFrame, EventFrameMeta),
    "lifecycle_frame": (LifecycleFrame, LifecycleHistoryFrameMeta),
    "subject_set": (SubjectSet, SubjectSetMeta),
    "component_frame": (ComponentFrame, ComponentFrameMeta),
    "coverage_frame": (CoverageFrame, CoverageFrameMeta),
}

_CURRENT_METRIC_FRAME_FIELDS = frozenset(
    {
        "metric_identity",
        "metric_identities",
        "catalog_definition_fingerprint",
        "expression_graph_ref",
        "expression_graph",
        "expression_fingerprint",
        "semantic_dependency_digest",
        "presentation_ref",
        "presentation",
        "presentation_fingerprint",
        "artifact_identity",
        "key_schema",
        "source_compatibility_domain",
        "component_ref",
        "replay_graph_ref",
        "comparable_value_semantics_ref",
        "comparable_value_semantics",
        "execution_stats",
        "unit_state",
        "axis_bindings",
        "slice_predicates",
        "status_time_dimension_ref",
    }
)


def _evidence_recovery_marker(session: Session, ref: str) -> sqlite3.Row | None:
    """Return one committed evidence row that can recover a missing session index."""
    db_path = session._layout.session_dir / "judgment.db"
    if not db_path.is_file():
        return None
    store = session._evidence_store()
    if store is None:
        raise EvidenceStoreUnavailableError(
            message=f"cannot recover artifact {ref!r} because judgment.db is unavailable",
            context={"artifact_ref": ref, "db_path": str(db_path)},
        )
    try:
        connection = store.read()
        user_version = connection.execute("PRAGMA user_version").fetchone()[0]
        if user_version != EXPECTED_SCHEMA_VERSION:
            raise SchemaVersionMismatchError(
                message=(
                    f"judgment.db schema version {user_version} is unsupported; "
                    f"this release requires a fresh v{EXPECTED_SCHEMA_VERSION} evidence store"
                ),
                context={"got": user_version, "expected": EXPECTED_SCHEMA_VERSION},
            )
        row = connection.execute(
            "SELECT * FROM artifacts WHERE session_id = ? AND artifact_id = ?",
            (session.id, ref),
        ).fetchone()
    except SchemaVersionMismatchError:
        raise
    except sqlite3.Error as exc:
        raise EvidenceStoreUnavailableError(
            message=f"cannot read judgment.db while recovering artifact {ref!r}",
            context={
                "artifact_ref": ref,
                "db_path": str(db_path),
                "cause": str(exc),
            },
        ) from exc
    if row is None:
        return None
    expected_data_path = (session._layout.frames_dir / ref / "data.parquet").resolve()
    recorded_data_path = Path(str(row["frame_path"])).resolve()
    if recorded_data_path != expected_data_path:
        raise FrameCacheCorruptedError(
            message=f"frame '{ref}' evidence marker points outside its canonical path",
            context={
                "ref": ref,
                "expected_path": str(expected_data_path),
                "recorded_path": str(recorded_data_path),
            },
        )
    if row["artifact_schema_version"] != "v4":
        raise FrameCacheCorruptedError(
            message=f"frame '{ref}' evidence marker uses an unsupported artifact projection",
            context={
                "ref": ref,
                "expected_artifact_schema_version": "v4",
                "received_artifact_schema_version": row["artifact_schema_version"],
            },
        )
    return cast("sqlite3.Row", row)


def _contains_semantic_grain(value: Any) -> bool:
    """Detect a serialized semantic Grain that requires JSON model decoding."""
    if isinstance(value, dict):
        if value.get("kind") == "semantic" and isinstance(value.get("calendar_ref"), str):
            return True
        return any(_contains_semantic_grain(child) for child in value.values())
    if isinstance(value, list | tuple):
        return any(_contains_semantic_grain(child) for child in value)
    return False


def _current_metric_state_error(
    ref: str,
    *,
    path: str,
    reason: str,
) -> FrameMetaInvalidError:
    return FrameMetaInvalidError(
        message=(f"frame '{ref}' has invalid current-schema metric state at {path}: {reason}"),
        location=f"frame '{ref}' current-schema metric state ({path})",
        repair=AnalysisRepair(
            kind="retry",
            action=(
                f"frame '{ref}' has invalid current-schema metric state at {path}. "
                "Re-run observe() to regenerate the frame under the current contract."
            ),
            help_target=LiveHelpTarget(surface="analysis", canonical_id="observe"),
            snippet="session.observe(metric_ref, ...)",
        ),
        context={
            "ref": ref,
            "artifact_schema_version": CURRENT_ARTIFACT_SCHEMA_VERSION,
            "path": path,
            "reason": reason,
        },
    )


def _validate_current_replay_payload(ref: str, meta: MetricFrameMeta) -> None:
    from marivo.analysis.runtime_metric import from_replay_payload

    observe_step = next(
        (step for step in reversed(meta.lineage.steps) if step.intent == "observe"),
        None,
    )
    if observe_step is None or not isinstance(observe_step.params, dict):
        raise _current_metric_state_error(
            ref,
            path="lineage.observe.params",
            reason="typed observe replay params are missing",
        )
    replay_step = (
        meta.lineage.steps[-1]
        if meta.lineage.steps and meta.lineage.steps[-1].intent == "select_metric"
        else observe_step
    )
    if not isinstance(replay_step.params, dict):
        raise _current_metric_state_error(
            ref,
            path=f"lineage.{replay_step.intent}.params",
            reason="typed replay params are missing",
        )
    replay_expression = replay_step.params.get("replay_expression")
    replay_expressions = replay_step.params.get("replay_expressions")
    try:
        if len(meta.metric_identities) == 1:
            if replay_expression is None or replay_expressions is not None:
                raise ValueError("arity-one frame requires exactly replay_expression")
            from_replay_payload(replay_expression)
        else:
            if replay_expression is not None or not isinstance(replay_expressions, list):
                raise ValueError("multi-root frame requires exactly replay_expressions")
            if len(replay_expressions) != len(meta.metric_identities):
                raise ValueError("replay expression count does not match metric root count")
            for item in replay_expressions:
                from_replay_payload(item)
    except (TypeError, ValueError) as exc:
        raise _current_metric_state_error(
            ref,
            path="lineage.observe.params.replay_expression",
            reason=str(exc),
        ) from exc


def _clamp_loaded_metric_reaggregatable(meta: MetricFrameMeta) -> None:
    """Re-derive the plain-sum ``reaggregatable`` flag on load (issue #110).

    Artifacts persisted before the issue #110 fix carried ``reaggregatable=True``
    for ``non_additive``/unknown metrics (the pre-fix fold/cumulative-only rule).
    Loading such an artifact would re-publish a plain-sum-rollup-able frame, the
    exact combination issue #110 eliminates. This clamp keeps every ``additive``
    payload intact while downgrading ``semi_additive``/``non_additive``/unknown
    to the blocked state, both at the frame level and per measure binding.
    """
    bindings = meta.measure_bindings
    if bindings:
        meta.measure_bindings = tuple(
            replace(
                binding,
                reaggregatable=_clamp_reaggregatable(binding.additivity, binding.reaggregatable),
            )
            for binding in bindings
        )
        meta.reaggregatable = all(binding.reaggregatable for binding in meta.measure_bindings)
        return
    if meta.measures is not None:
        meta.measures = [
            {
                **entry,
                "reaggregatable": _clamp_reaggregatable(
                    entry.get("additivity"), bool(entry.get("reaggregatable", True))
                ),
            }
            for entry in meta.measures
        ]
        meta.reaggregatable = all(bool(entry.get("reaggregatable")) for entry in meta.measures)
        return
    meta.reaggregatable = _clamp_reaggregatable(meta.additivity, meta.reaggregatable)


def _validate_current_metric_state(ref: str, meta: MetricFrameMeta) -> None:
    graph = meta.expression_graph
    assert graph is not None
    try:
        validate_graph(graph)
    except MetricGraphContractError as exc:
        raise _current_metric_state_error(
            ref,
            path="expression_graph",
            reason=str(exc),
        ) from exc

    if len(graph.roots) != len(meta.metric_identities):
        raise _current_metric_state_error(
            ref,
            path="expression_graph.roots",
            reason="root count does not match metric identity count",
        )
    expected_expression_fingerprint = (
        graph.roots[0] if len(graph.roots) == 1 else fingerprint(graph.roots)
    )
    if meta.expression_fingerprint != expected_expression_fingerprint:
        raise _current_metric_state_error(
            ref,
            path="expression_fingerprint",
            reason="fingerprint does not match the canonical graph roots",
        )
    if meta.presentation is None or meta.presentation_fingerprint != fingerprint(meta.presentation):
        raise _current_metric_state_error(
            ref,
            path="presentation_fingerprint",
            reason="fingerprint does not match the persisted presentation",
        )
    if meta.key_schema is None or meta.key_schema.fingerprint != fingerprint(
        meta.key_schema.fields
    ):
        raise _current_metric_state_error(
            ref,
            path="key_schema.fingerprint",
            reason="fingerprint does not match the persisted key fields",
        )

    artifact_identity = meta.artifact_identity
    dependency_digest = meta.semantic_dependency_digest
    source_domain = meta.source_compatibility_domain
    if artifact_identity is None or dependency_digest is None or source_domain is None:
        raise _current_metric_state_error(
            ref,
            path="artifact_identity",
            reason="artifact identity dependencies are incomplete",
        )
    artifact_mismatches = {
        "metric_identities": artifact_identity.metric_identities != meta.metric_identities,
        "dependency_fingerprint": (
            artifact_identity.dependency_fingerprint != dependency_digest.digest
        ),
        "source_domain_fingerprint": (
            artifact_identity.source_domain_fingerprint != source_domain.profile_fingerprint
        ),
        "presentation_fingerprint": (
            artifact_identity.presentation_fingerprint != meta.presentation_fingerprint
        ),
        "artifact_schema_version": (
            artifact_identity.artifact_schema_version != meta.artifact_schema_version
        ),
    }
    # The version gate above has already rejected any non-current schema, so
    # attribution_basis is always the current-schema field here.
    artifact_mismatches["attribution_basis_fingerprint"] = (
        artifact_identity.attribution_basis_fingerprint != basis_fingerprint(meta.attribution_basis)
    )
    failed_artifact_fields = sorted(
        field for field, mismatched in artifact_mismatches.items() if mismatched
    )
    if failed_artifact_fields:
        raise _current_metric_state_error(
            ref,
            path="artifact_identity",
            reason=f"identity fields do not match frame state: {failed_artifact_fields}",
        )
    artifact_identity_payload: dict[str, object] = {
        "metric_identities": artifact_identity.metric_identities,
        "scope_fingerprint": artifact_identity.scope_fingerprint,
        "source_domain_fingerprint": artifact_identity.source_domain_fingerprint,
        "dependency_fingerprint": artifact_identity.dependency_fingerprint,
        "snapshot_fingerprint": artifact_identity.snapshot_fingerprint,
        "coverage_fingerprint": artifact_identity.coverage_fingerprint,
        "presentation_fingerprint": artifact_identity.presentation_fingerprint,
        "artifact_schema_version": artifact_identity.artifact_schema_version,
    }
    artifact_identity_payload["attribution_basis_fingerprint"] = (
        artifact_identity.attribution_basis_fingerprint
    )
    if artifact_identity.fingerprint != fingerprint(artifact_identity_payload):
        raise _current_metric_state_error(
            ref,
            path="artifact_identity.fingerprint",
            reason="fingerprint does not match the persisted artifact identity",
        )

    comparable = meta.comparable_value_semantics
    assert comparable is not None
    comparable_payload = {
        "expression_fingerprint": comparable.expression_fingerprint,
        "evaluator_contracts": comparable.evaluator_contracts,
        "global_slice": comparable.global_slice,
        "key_schema_fingerprint": comparable.key_schema_fingerprint,
        "unit": comparable.unit,
        "fold": comparable.fold,
        "source_domain_fingerprint": comparable.source_domain_fingerprint,
        "definition_transform_fingerprint": comparable.definition_transform_fingerprint,
    }
    if comparable.fingerprint != fingerprint(comparable_payload):
        raise _current_metric_state_error(
            ref,
            path="comparable_value_semantics.fingerprint",
            reason="fingerprint does not match comparable semantics",
        )
    if comparable.key_schema_fingerprint != meta.key_schema.fingerprint:
        raise _current_metric_state_error(
            ref,
            path="comparable_value_semantics.key_schema_fingerprint",
            reason="key schema fingerprint does not match the frame key schema",
        )

    expected_refs = {
        "expression_graph_ref": f"{meta.ref}#expression-graph",
        "presentation_ref": f"{meta.ref}#presentation",
        "replay_graph_ref": f"{meta.ref}#replay-graph",
        "comparable_value_semantics_ref": f"{meta.ref}#comparable-value-semantics",
    }
    for field, expected in expected_refs.items():
        actual = getattr(meta, field)
        if actual != expected:
            raise _current_metric_state_error(
                ref,
                path=field,
                reason=f"expected {expected!r}, found {actual!r}",
            )
    _validate_current_replay_payload(ref, meta)


def _delta_identity_recovery_error(ref: str, *, reason: str) -> FrameMetaInvalidError:
    return FrameMetaInvalidError(
        message=f"frame '{ref}' has an invalid delta comparison identity",
        location=f"frame '{ref}' delta comparison identity",
        repair=AnalysisRepair(
            kind="retry",
            action="Re-run session.compare(current, baseline, alignment=...) from the source MetricFrames.",
            help_target=LiveHelpTarget(surface="analysis", canonical_id="compare"),
            snippet="delta = session.compare(current, baseline, alignment=alignment)",
        ),
        context={
            "ref": ref,
            "artifact_schema_version": CURRENT_ARTIFACT_SCHEMA_VERSION,
            "reason": reason,
        },
    )


def _validate_delta_comparison_state(
    ref: str,
    meta: DeltaFrameMeta,
    *,
    session: Session,
) -> None:
    """Recompute persisted delta identity semantics from its two source frames."""

    current = load_frame(meta.source_current_ref, session=session)
    baseline = load_frame(meta.source_baseline_ref, session=session)
    if not isinstance(current, MetricFrame) or not isinstance(baseline, MetricFrame):
        raise _delta_identity_recovery_error(
            ref,
            reason="delta sources must both recover as MetricFrames",
        )
    identity = meta.comparison_identity
    current_identity = current.meta.metric_identity
    baseline_identity = baseline.meta.metric_identity
    current_comparable = current.meta.comparable_value_semantics
    baseline_comparable = baseline.meta.comparable_value_semantics
    if current_identity is None or baseline_identity is None:
        raise _delta_identity_recovery_error(ref, reason="source metric identity is missing")
    if current_comparable is None or baseline_comparable is None:
        raise _delta_identity_recovery_error(
            ref,
            reason="source comparable semantics are missing",
        )
    mismatches: list[str] = []
    if identity.current != current_identity:
        mismatches.append("current metric identity")
    if identity.baseline != baseline_identity:
        mismatches.append("baseline metric identity")
    if identity.current_artifact_id != (current.meta.artifact_id or current.ref):
        mismatches.append("current artifact id")
    if identity.baseline_artifact_id != (baseline.meta.artifact_id or baseline.ref):
        mismatches.append("baseline artifact id")

    policy_fields = {
        key: meta.alignment[key]
        for key in (
            "kind",
            "mode",
            "strict_lengths",
            "within",
            "unmatched",
            "correspondence",
            "anchor",
            "schedule_ref",
        )
        if key in meta.alignment
    }
    try:
        policy = decode_alignment_policy(cast("Any", policy_fields))
    except Exception as exc:
        raise _delta_identity_recovery_error(
            ref,
            reason=f"persisted alignment policy is invalid: {exc}",
        ) from exc
    if identity.alignment_policy_fingerprint != fingerprint(policy.model_dump(mode="json")):
        mismatches.append("alignment policy fingerprint")
    if policy.kind == "working_day_progress":
        temporal_contract = meta.temporal_contract
        binding = temporal_contract.work_schedule if temporal_contract is not None else None
        schedule_ref = getattr(policy, "schedule_ref", None)
        if binding is None or binding.work_schedule_ref != schedule_ref:
            mismatches.append("work schedule binding")

    cumulative_alignment = meta.cumulative_alignment
    expected_semantics: DeltaComparisonSemantics
    if cumulative_alignment is None:
        expected_semantics = ExactComparisonSemanticsV1(
            schema="exact-comparison-semantics/v1",
            comparable_semantics_fingerprint=current_comparable.fingerprint,
        )
        if current_comparable.fingerprint != baseline_comparable.fingerprint:
            mismatches.append("exact source comparable semantics")
    else:
        current_anchor = cumulative_compare_anchor(current.meta.cumulative)
        baseline_anchor = cumulative_compare_anchor(baseline.meta.cumulative)
        if not isinstance(current_anchor, tuple) or not isinstance(baseline_anchor, tuple):
            raise _delta_identity_recovery_error(
                ref,
                reason="comparable-period delta sources have invalid cumulative anchors",
            )
        if cumulative_alignment.current_authored_anchor != authored_comparable_period_anchor(
            current_anchor
        ):
            mismatches.append("current authored cumulative anchor")
        if cumulative_alignment.baseline_authored_anchor != authored_comparable_period_anchor(
            baseline_anchor
        ):
            mismatches.append("baseline authored cumulative anchor")
        current_graph = current.meta.expression_graph
        baseline_graph = baseline.meta.expression_graph
        if current_graph is None or baseline_graph is None:
            raise _delta_identity_recovery_error(
                ref,
                reason="comparable-period delta sources are missing expression graphs",
            )
        try:
            expected_semantics = cumulative_equivalent_comparison_semantics(
                current_graph=current_graph,
                baseline_graph=baseline_graph,
                current_comparable=current_comparable,
                baseline_comparable=baseline_comparable,
                current_anchor=current_anchor,
                baseline_anchor=baseline_anchor,
            )
        except (TypeError, ValueError) as exc:
            raise _delta_identity_recovery_error(
                ref,
                reason=f"source cumulative semantics cannot be recomputed: {exc}",
            ) from exc
    if identity.semantics != expected_semantics:
        mismatches.append("comparison semantics")
    if mismatches:
        raise _delta_identity_recovery_error(
            ref,
            reason=f"identity fields do not match recovered source state: {sorted(mismatches)}",
        )


def load_frame(
    ref: str | ArtifactRef,
    *,
    session: Session,
    _require_evidence_marker: bool = False,
) -> BaseFrame:
    """Load a persisted analysis frame by ref from the given or active session."""
    import json

    if isinstance(ref, ArtifactRef):
        ref = ref.ref

    # The Session Store is the ordinary index. A fully committed evidence row
    # can recover a missing index entry after interruption between the ledger
    # transaction and Session Store registration.
    artifact_row = session._store.get_artifact(session.id, ref)
    recovery_marker: sqlite3.Row | None = None
    if artifact_row is None or _require_evidence_marker:
        recovery_marker = _evidence_recovery_marker(session, ref)
    if _require_evidence_marker and recovery_marker is None:
        raise ArtifactNotFoundError.for_ref(ref)
    registered_content_hash: object | None
    if artifact_row is not None:
        # Use store-registered paths to locate the on-disk data.
        meta_path = session.project_root / artifact_row["meta_path"]
        data_path = session.project_root / artifact_row["path"]
        registered_content_hash = artifact_row["content_hash"]
    elif recovery_marker is not None:
        meta_path = session._layout.frames_dir / ref / "meta.json"
        data_path = session._layout.frames_dir / ref / "data.parquet"
        registered_content_hash = None
    else:
        # No index or committed evidence marker: unregistered files are orphans,
        # not loadable artifacts.
        raise ArtifactNotFoundError.for_ref(ref)
    if not meta_path.is_file():
        raise FrameCacheCorruptedError(
            message=f"frame '{ref}' is committed but meta file is missing",
            context={"ref": ref, "meta_path": str(meta_path)},
        )
    if not data_path.is_file():
        raise FrameCacheCorruptedError(
            message=f"frame '{ref}' is committed but data file is missing",
            context={"ref": ref, "data_path": str(data_path)},
        )
    try:
        from marivo.analysis.session._layout import _read_parquet_frame

        df = _read_parquet_frame(data_path)
        meta = json.loads(meta_path.read_text())
        if recovery_marker is not None and artifact_row is None:
            registered_content_hash = meta.get("content_hash")
    except Exception as exc:
        raise FrameCacheCorruptedError(
            message=f"frame '{ref}' exists on disk but cannot be loaded",
            context={"ref": ref, "cause": str(exc)},
        ) from exc

    artifact_schema_version = meta.get("artifact_schema_version")
    if artifact_schema_version != CURRENT_ARTIFACT_SCHEMA_VERSION:
        raise FrameMetaInvalidError(
            message=(
                f"frame '{ref}' uses unsupported artifact schema "
                f"{artifact_schema_version!r}; recreate the analysis session"
            ),
            location=f"frame '{ref}' artifact schema version",
            expected=CURRENT_ARTIFACT_SCHEMA_VERSION,
            received=artifact_schema_version or "<missing>",
            repair=AnalysisRepair(
                kind="retry",
                action=(
                    "Re-run the analysis (observe/compare/attribute/...) so the "
                    f"frame is regenerated as {CURRENT_ARTIFACT_SCHEMA_VERSION}."
                ),
                help_target=LiveHelpTarget(surface="analysis", canonical_id="observe"),
                snippet="session.observe(metric_ref, ...)",
            ),
            context={
                "ref": ref,
            },
        )
    if meta.get("session_id") != session.id:
        raise CrossSessionFrameError(
            message=(
                f"frame '{ref}' belongs to session {meta.get('session_id')!r} "
                f"but was loaded through session {session.id!r}"
            ),
        )
    kind = meta["kind"]
    if kind not in _FRAME_CLASSES:
        raise FrameMetaInvalidError(
            message=f"Artifact {ref!r} has an unsupported kind",
            expected=f"one of {sorted(_FRAME_CLASSES)!r}",
            received=str(kind),
            location=f"Artifact {ref!r} kind",
            repair=AnalysisRepair(
                kind="inspect",
                action="Inspect the Artifact record, then regenerate it from its producing Run.",
                help_target=LiveHelpTarget(surface="analysis", canonical_id="session.artifact"),
                snippet=f"session.artifact({ref!r})",
            ),
        )
    frame_cls, meta_cls = _FRAME_CLASSES[kind]
    if kind == "event_frame":
        semantic_kind = meta.get("semantic_kind")
        event_meta_classes = {
            "journey": EventFrameMeta,
            "funnel": EventFunnelFrameMeta,
            "time_to_event": EventTimeToEventFrameMeta,
        }
        if semantic_kind not in event_meta_classes:
            raise FrameMetaInvalidError(
                message=f"frame '{ref}' has an unsupported Event semantic shape",
                location=f"frame '{ref}' event semantic shape",
                repair=AnalysisRepair(
                    kind="retry",
                    action=(
                        f"frame '{ref}' has unsupported semantic shape "
                        f"{semantic_kind!r}. Re-run the producing intent under "
                        "the current schema."
                    ),
                    help_target=LiveHelpTarget(surface="analysis", canonical_id="observe"),
                ),
                context={
                    "ref": ref,
                    "artifact_schema_version": CURRENT_ARTIFACT_SCHEMA_VERSION,
                    "got_semantic_kind": semantic_kind,
                    "expected_semantic_kinds": tuple(event_meta_classes),
                },
            )
        meta_cls = event_meta_classes[semantic_kind]
    if kind == "lifecycle_frame":
        semantic_kind = meta.get("semantic_kind")
        lifecycle_meta_classes = {
            "history": LifecycleHistoryFrameMeta,
            "distribution": LifecycleDistributionFrameMeta,
            "transitions": LifecycleTransitionsFrameMeta,
            "dwell": LifecycleDwellFrameMeta,
            "violations": LifecycleViolationsFrameMeta,
        }
        if semantic_kind not in lifecycle_meta_classes:
            raise FrameMetaInvalidError(
                message=f"frame '{ref}' has an unsupported Lifecycle semantic shape",
                location=f"frame '{ref}' lifecycle semantic shape",
                repair=AnalysisRepair(
                    kind="retry",
                    action=(
                        f"frame '{ref}' has unsupported semantic shape "
                        f"{semantic_kind!r}. Re-run the producing intent under "
                        "the current schema."
                    ),
                    help_target=LiveHelpTarget(surface="analysis", canonical_id="observe"),
                ),
                context={
                    "ref": ref,
                    "artifact_schema_version": CURRENT_ARTIFACT_SCHEMA_VERSION,
                    "got_semantic_kind": semantic_kind,
                    "expected_semantic_kinds": tuple(lifecycle_meta_classes),
                },
            )
        meta_cls = lifecycle_meta_classes[semantic_kind]
        if semantic_kind == "history":
            manifest_payload = meta.get("violation_trace")
            filename = (
                manifest_payload.get("filename") if isinstance(manifest_payload, dict) else None
            )
            if isinstance(filename, str):
                frame_dir = data_path.parent.resolve()
                trace_path = (frame_dir / filename).resolve()
                if trace_path.parent != frame_dir:
                    raise FrameCacheCorruptedError(
                        message=f"frame '{ref}' has an escaped Lifecycle trace path",
                        context={
                            "ref": ref,
                            "cause": "auxiliary trace path is outside the artifact directory",
                        },
                    )
    if kind == "delta_frame" and meta.get("semantic_kind") == "funnel":
        meta_cls = FunnelDeltaFrameMeta
    if (
        kind == "delta_frame"
        and meta.get("semantic_kind") != "funnel"
        and meta.get("cumulative") is not None
    ):
        if meta.get("artifact_schema") != "cumulative-delta/v1":
            raise FrameMetaInvalidError(
                message=(f"frame '{ref}' uses an unsupported cumulative delta artifact schema"),
                location=f"frame '{ref}' cumulative delta artifact schema",
                expected="cumulative-delta/v1",
                received=meta.get("artifact_schema"),
                repair=AnalysisRepair(
                    kind="retry",
                    action=(
                        f"frame '{ref}' uses an unsupported cumulative delta artifact "
                        "schema. Re-run observe and compare under the current "
                        "environment to regenerate it."
                    ),
                    help_target=LiveHelpTarget(surface="analysis", canonical_id="observe"),
                ),
                context={
                    "ref": ref,
                    "kind": "unsupported_artifact_schema",
                },
            )
        if "cumulative_attribution" not in meta:
            raise FrameMetaInvalidError(
                message=(
                    f"frame '{ref}' is missing its required cumulative-delta/v1 "
                    "cumulative_attribution field"
                ),
                location=f"frame '{ref}' cumulative delta cumulative_attribution",
                repair=AnalysisRepair(
                    kind="retry",
                    action=(
                        f"frame '{ref}' is missing its cumulative_attribution "
                        "field. Re-run observe() and session.compare(current, "
                        "baseline, alignment=...) under the current environment "
                        "to regenerate it."
                    ),
                    help_target=LiveHelpTarget(surface="analysis", canonical_id="observe"),
                    snippet="session.observe(metric_ref, ...)",
                ),
                context={
                    "ref": ref,
                    "artifact_schema_version": CURRENT_ARTIFACT_SCHEMA_VERSION,
                    "missing_state": ["cumulative_attribution"],
                },
            )
        meta_cls = CumulativeDeltaFrameMetaV1
    if kind == "attribution_frame" and meta.get("semantic_kind") == "funnel_loss_rate":
        meta_cls = FunnelAttributionFrameMeta
    if kind == "attribution_frame" and meta.get("semantic_kind") != "funnel_loss_rate":
        row_contract = meta.get("row_contract_version")
        supported_row_contracts = {
            "generic-attribution-rows/v3",
            "cumulative-flow-attribution-rows/v1",
        }
        if row_contract not in supported_row_contracts:
            raise FrameMetaInvalidError(
                message=f"frame '{ref}' uses an unsupported attribution row contract",
                location=f"frame '{ref}' attribution row contract",
                expected="generic-attribution-rows/v3",
                received=row_contract or "<missing>",
                repair=AnalysisRepair(
                    kind="retry",
                    action=(
                        f"Re-run session.attribute(...) for frame '{ref}' under the current "
                        "contract. Use mode='hierarchy' for ordered-prefix output."
                    ),
                    help_target=LiveHelpTarget(surface="analysis", canonical_id="attribute"),
                    snippet="result = session.attribute(delta, axes=axes, mode='hierarchy')",
                ),
                context={
                    "ref": ref,
                    "row_contract_version": row_contract,
                    "replacement_mode": "hierarchy",
                },
            )
    if kind == "candidate_set" and meta.get("shape") == "semantic_hypothesis":
        meta_cls = SemanticHypothesisCandidateSetMeta
    if (
        kind == "delta_frame"
        and meta.get("semantic_kind") != "funnel"
        and "comparison_identity" not in meta
    ):
        raise FrameMetaInvalidError(
            message=f"frame '{ref}' is missing its required delta identity",
            location=f"frame '{ref}' delta comparison identity",
            repair=AnalysisRepair(
                kind="retry",
                action=(
                    f"frame '{ref}' is missing its delta comparison identity. "
                    "Re-run session.compare(current, baseline, alignment=...) to "
                    "rebuild it from the source MetricFrames."
                ),
                help_target=LiveHelpTarget(surface="analysis", canonical_id="compare"),
                snippet="delta = session.compare(current, baseline, alignment=alignment)",
            ),
            context={
                "ref": ref,
                "artifact_schema_version": CURRENT_ARTIFACT_SCHEMA_VERSION,
                "missing_state": ["comparison_identity"],
            },
        )
    if kind == "delta_frame" and meta.get("semantic_kind") != "funnel":
        comparison_payload = meta.get("comparison_identity")
        if isinstance(comparison_payload, dict) and comparison_payload.get("schema") != (
            "delta-comparison/v2"
        ):
            raise _delta_identity_recovery_error(
                ref,
                reason=(
                    "only delta-comparison/v2 is supported; persisted V1 deltas must be "
                    "re-created from their source MetricFrames"
                ),
            )
    if kind == "metric_frame":
        required_metric_fields = _CURRENT_METRIC_FRAME_FIELDS | (
            {"attribution_basis"}
            if artifact_schema_version == CURRENT_ARTIFACT_SCHEMA_VERSION
            else set()
        )
        missing_fields = sorted(required_metric_fields - set(meta))
        if missing_fields:
            raise FrameMetaInvalidError(
                message=(
                    f"frame '{ref}' is missing required {artifact_schema_version} "
                    f"fields: {', '.join(missing_fields)}"
                ),
                location=f"frame '{ref}' required metric fields",
                repair=AnalysisRepair(
                    kind="retry",
                    action=(
                        f"frame '{ref}' is missing required schema field(s) "
                        f"{', '.join(missing_fields)}. Re-run observe() to "
                        "regenerate the frame under the current contract."
                    ),
                    help_target=LiveHelpTarget(surface="analysis", canonical_id="observe"),
                    snippet="session.observe(metric_ref, ...)",
                ),
                context={
                    "ref": ref,
                    "artifact_schema_version": artifact_schema_version,
                    "missing_fields": missing_fields,
                },
            )
    if (
        kind == "delta_frame"
        and meta.get("semantic_kind") != "funnel"
        and artifact_schema_version == CURRENT_ARTIFACT_SCHEMA_VERSION
        and "attribution_basis" not in meta
    ):
        raise FrameMetaInvalidError(
            message=f"frame '{ref}' is missing its {CURRENT_ARTIFACT_SCHEMA_VERSION} attribution basis field",
            location=f"frame '{ref}' attribution basis field",
            repair=AnalysisRepair(
                kind="retry",
                action=(
                    f"frame '{ref}' is missing its attribution basis field. "
                    "Re-run session.compare(current, baseline, alignment=...) to "
                    "rebuild it from the source MetricFrames."
                ),
                help_target=LiveHelpTarget(surface="analysis", canonical_id="compare"),
                snippet="delta = session.compare(current, baseline, alignment=alignment)",
            ),
            context={
                "ref": ref,
                "artifact_schema_version": artifact_schema_version,
                "missing_state": ["attribution_basis"],
            },
        )
    try:
        use_json_validation = (
            kind
            in {
                "event_frame",
                "lifecycle_frame",
                "subject_set",
            }
            or (kind == "delta_frame" and meta.get("semantic_kind") == "funnel")
            or (kind == "attribution_frame" and meta.get("semantic_kind") == "funnel_loss_rate")
            or (kind == "candidate_set" and meta.get("shape") == "semantic_hypothesis")
            # CandidateOrigin contains the sealed SemanticEdgeRef, whose
            # persisted dict form is intentionally accepted only in JSON mode.
            or bool(meta.get("candidate_origins"))
            # FrameTemporalContractV1 contains strict date/datetime and tuple
            # fields whose persisted JSON representation must be parsed by
            # Pydantic's JSON decoder on cold-start recovery.
            or bool(meta.get("temporal_contract"))
            # MetricExpressionGraphV1 can carry a semantic Grain anchor even
            # when an older or heterogeneous forest omitted the frame-level
            # temporal contract. Direct model construction leaves that mapping
            # as a dict and fails the graph validator; JSON mode rehydrates it.
            or _contains_semantic_grain(meta.get("expression_graph"))
        )
        with _trusted_time_scope_validation():
            parsed_meta = (
                cast("Any", meta_cls).model_validate_json(json.dumps(meta))
                if use_json_validation
                else meta_cls(**meta)
            )
    except ValidationError as exc:
        errors = exc.errors()
        extra_fields = [
            str(err["loc"][0])
            for err in errors
            if err.get("type") == "extra_forbidden" and err.get("loc")
        ]
        # Only report a version mismatch when *every* validation failure is an
        # extra-forbidden field. If a removed field coexists with a genuinely
        # corrupt value, the corruption must win: re-running observe() masks the
        # real data problem (issue #57 review P3-1).
        if extra_fields and all(err.get("type") == "extra_forbidden" for err in errors):
            # The artifact carries a field removed in this schema version (e.g.
            # the pre-issue-57 component_graph_ref). This is a version mismatch,
            # not data corruption: the operator re-runs observe() to regenerate
            # the frame under the current contract (per AGENTS.md, no read-side
            # legacy migration).
            raise FrameMetaInvalidError(
                message=(
                    f"frame '{ref}' carries field(s) no longer in "
                    f"{artifact_schema_version}: {', '.join(extra_fields)}"
                ),
                location=f"frame '{ref}' extra forbidden fields",
                context={
                    "ref": ref,
                    "artifact_schema_version": artifact_schema_version,
                    "extra_fields": extra_fields,
                    "validation_errors": errors,
                },
                repair=AnalysisRepair(
                    kind="environment",
                    action=(
                        "The persisted artifact was written by an older schema "
                        "that includes removed field(s). Re-run observe() to "
                        "regenerate the frame under the current contract."
                    ),
                    help_target=LiveHelpTarget(surface="analysis", canonical_id="session.artifact"),
                ),
            ) from exc
        raise FrameMetaInvalidError(
            message=(f"frame '{ref}' metadata fails {artifact_schema_version} validation"),
            location=f"frame '{ref}' metadata validation",
            repair=AnalysisRepair(
                kind="inspect",
                action=(
                    f"frame '{ref}' metadata fails {artifact_schema_version} "
                    "validation. Inspect the persisted artifact; if it is stale, "
                    "re-run the producing intent to regenerate it."
                ),
                help_target=LiveHelpTarget(surface="analysis", canonical_id="session.artifact"),
            ),
            context={
                "ref": ref,
                "artifact_schema_version": artifact_schema_version,
                "validation_errors": exc.errors(),
            },
        ) from exc
    if isinstance(parsed_meta, MetricFrameMeta):
        _clamp_loaded_metric_reaggregatable(parsed_meta)
        last_intent = parsed_meta.lineage.steps[-1].intent if parsed_meta.lineage.steps else None
        if last_intent in {"observe", "select_metric"}:
            metric_required_state: dict[str, object | None] = {
                "metric_identities": parsed_meta.metric_identities or None,
                "catalog_definition_fingerprint": (parsed_meta.catalog_definition_fingerprint),
                "expression_graph": parsed_meta.expression_graph,
                "expression_fingerprint": parsed_meta.expression_fingerprint,
                "semantic_dependency_digest": parsed_meta.semantic_dependency_digest,
                "presentation": parsed_meta.presentation,
                "presentation_fingerprint": parsed_meta.presentation_fingerprint,
                "artifact_identity": parsed_meta.artifact_identity,
                "key_schema": parsed_meta.key_schema,
                "source_compatibility_domain": parsed_meta.source_compatibility_domain,
                "component_ref": parsed_meta.component_ref,
                "comparable_value_semantics": parsed_meta.comparable_value_semantics,
                "execution_stats": parsed_meta.execution_stats,
                "unit_state": (
                    parsed_meta.unit_state
                    if len(parsed_meta.metric_identities) == 1
                    else (
                        tuple(binding.unit_state for binding in parsed_meta.measure_bindings)
                        if parsed_meta.measure_bindings
                        else parsed_meta.measures
                    )
                ),
            }
            missing_state = sorted(
                name for name, value in metric_required_state.items() if value is None
            )
            if missing_state:
                raise FrameMetaInvalidError(
                    message=f"frame '{ref}' has incomplete current-schema metric state",
                    location=f"frame '{ref}' current-schema metric state",
                    repair=AnalysisRepair(
                        kind="retry",
                        action=(
                            f"frame '{ref}' has incomplete current-schema metric "
                            f"state ({', '.join(missing_state)}). Re-run observe() "
                            "to regenerate the frame under the current contract."
                        ),
                        help_target=LiveHelpTarget(surface="analysis", canonical_id="observe"),
                        snippet="session.observe(metric_ref, ...)",
                    ),
                    context={
                        "ref": ref,
                        "artifact_schema_version": CURRENT_ARTIFACT_SCHEMA_VERSION,
                        "missing_state": missing_state,
                    },
                )
            _validate_current_metric_state(ref, parsed_meta)
    if isinstance(parsed_meta, DeltaFrameMeta):
        expected_basis_fingerprint = basis_fingerprint(parsed_meta.attribution_basis)
        if (
            parsed_meta.comparison_identity.attribution_basis_fingerprint
            != expected_basis_fingerprint
        ):
            raise FrameMetaInvalidError(
                message=f"frame '{ref}' has a mismatched attribution basis identity",
                location=f"frame '{ref}' attribution basis identity",
                repair=AnalysisRepair(
                    kind="retry",
                    action=(
                        f"frame '{ref}' has a mismatched attribution basis identity. "
                        "Re-run session.compare(current, baseline, alignment=...) to "
                        "rebuild it from the source MetricFrames."
                    ),
                    help_target=LiveHelpTarget(surface="analysis", canonical_id="compare"),
                    snippet="delta = session.compare(current, baseline, alignment=alignment)",
                ),
                context={
                    "ref": ref,
                    "artifact_schema_version": artifact_schema_version,
                    "expected_basis_fingerprint": expected_basis_fingerprint,
                },
            )
        delta_required_state: dict[str, object | None] = {
            "metric_identity": parsed_meta.metric_identity,
            "baseline_metric_identity": parsed_meta.baseline_metric_identity,
            "comparison_identity": parsed_meta.comparison_identity,
        }
        missing_state = sorted(
            name for name, value in delta_required_state.items() if value is None
        )
        if missing_state:
            raise FrameMetaInvalidError(
                message=f"frame '{ref}' has incomplete current-schema delta identity",
                location=f"frame '{ref}' current-schema delta identity",
                repair=AnalysisRepair(
                    kind="retry",
                    action=(
                        f"frame '{ref}' has incomplete current-schema delta "
                        f"identity ({', '.join(missing_state)}). Re-run "
                        "session.compare(current, baseline, alignment=...) to "
                        "rebuild it from the source MetricFrames."
                    ),
                    help_target=LiveHelpTarget(surface="analysis", canonical_id="compare"),
                    snippet="delta = session.compare(current, baseline, alignment=alignment)",
                ),
                context={
                    "ref": ref,
                    "artifact_schema_version": CURRENT_ARTIFACT_SCHEMA_VERSION,
                    "missing_state": missing_state,
                },
            )
        _validate_delta_comparison_state(ref, parsed_meta, session=session)
    if isinstance(parsed_meta, AttributionFrameMeta):
        try:
            validate_generic_attribution_rows(parsed_meta, df)
            validate_cumulative_flow_attribution_rows(parsed_meta, df)
        except ValueError as exc:
            row_family = (
                "generic attribution rows"
                if parsed_meta.row_contract_version == "generic-attribution-rows/v3"
                else "cumulative flow attribution rows"
            )
            raise FrameMetaInvalidError(
                message=f"frame '{ref}' has corrupt {row_family}",
                location=f"frame '{ref}' {row_family}",
                repair=AnalysisRepair(
                    kind="retry",
                    action=(
                        f"frame '{ref}' has corrupt {row_family}. Re-run the "
                        "producing intent (attribute) from its source frames to "
                        "rebuild them."
                    ),
                    help_target=LiveHelpTarget(surface="analysis", canonical_id="attribute"),
                ),
                context={
                    "ref": ref,
                    "artifact_schema_version": artifact_schema_version,
                    "reason": str(exc),
                },
            ) from exc
    if isinstance(parsed_meta, (CandidateSetMeta, SemanticHypothesisCandidateSetMeta)):
        if list(df.columns) != CANDIDATE_COLUMNS:
            raise FrameMetaInvalidError(
                message=f"frame '{ref}' has a non-canonical CandidateSet column layout",
                location=f"frame '{ref}' CandidateSet column layout",
                repair=AnalysisRepair(
                    kind="retry",
                    action=(
                        f"frame '{ref}' has a non-canonical CandidateSet column "
                        "layout. Re-run the candidate-producing intent through "
                        "the session.discover entry for this shape to regenerate "
                        "it."
                    ),
                    help_target=LiveHelpTarget(surface="analysis", canonical_id="discover"),
                ),
                context={
                    "ref": ref,
                    "got_columns": list(df.columns),
                    "expected_columns": CANDIDATE_COLUMNS,
                },
            )
        validate_shape_columns(parsed_meta.shape, df)
        validate_candidate_frame_identity(
            shape=parsed_meta.shape,
            source_artifact_ref=parsed_meta.source_ref,
            dataframe=df,
        )
        if isinstance(parsed_meta, SemanticHypothesisCandidateSetMeta):
            validate_semantic_hypothesis_frame_integrity(
                dataframe=df,
                edge_contexts=parsed_meta.edge_contexts,
                readiness_fingerprints={
                    binding.metric_ref: binding.fingerprint
                    for binding in parsed_meta.readiness_bindings
                },
                exclusions=parsed_meta.resolution_summary.exclusions,
            )
    auxiliary_frames: dict[str, Any] = {}
    if isinstance(parsed_meta, LifecycleHistoryFrameMeta):
        manifest = parsed_meta.violation_trace
        if manifest.content_hash is None:
            raise FrameMetaInvalidError(
                message=f"frame '{ref}' is missing its Lifecycle trace content hash",
                location=f"frame '{ref}' Lifecycle trace content hash",
                repair=AnalysisRepair(
                    kind="retry",
                    action=(
                        f"frame '{ref}' is missing its Lifecycle trace content "
                        "hash. Re-run the producing intent to regenerate the "
                        "frame."
                    ),
                    help_target=LiveHelpTarget(surface="analysis", canonical_id="session.artifact"),
                ),
                context={
                    "ref": ref,
                    "artifact_schema_version": CURRENT_ARTIFACT_SCHEMA_VERSION,
                    "missing_state": ["violation_trace.content_hash"],
                },
            )
        frame_dir = data_path.parent.resolve()
        trace_path = (frame_dir / manifest.filename).resolve()
        if trace_path.parent != frame_dir:
            raise FrameCacheCorruptedError(
                message=f"frame '{ref}' has an escaped Lifecycle trace path",
                context={
                    "ref": ref,
                    "cause": "auxiliary trace path is outside the artifact directory",
                },
            )
        if not trace_path.is_file():
            raise FrameCacheCorruptedError(
                message=f"frame '{ref}' Lifecycle trace is missing",
                context={"ref": ref, "cause": f"missing {manifest.filename}"},
            )
        if compute_file_content_hash(trace_path) != manifest.content_hash:
            raise FrameCacheCorruptedError(
                message=f"frame '{ref}' Lifecycle trace hash does not match metadata",
                context={"ref": ref, "cause": "auxiliary trace content hash mismatch"},
            )
        try:
            from marivo.analysis.session._layout import _read_parquet_frame

            trace = _read_parquet_frame(trace_path)
        except Exception as exc:
            raise FrameCacheCorruptedError(
                message=f"frame '{ref}' Lifecycle trace cannot be loaded",
                context={"ref": ref, "cause": str(exc)},
            ) from exc
        if len(trace) != manifest.row_count:
            raise FrameCacheCorruptedError(
                message=f"frame '{ref}' Lifecycle trace row count does not match metadata",
                context={"ref": ref, "cause": "auxiliary trace row count mismatch"},
            )
        expected_parent_hash = compute_frame_content_hash(
            meta=parsed_meta,
            data_path=data_path,
        )
        if (
            parsed_meta.content_hash != expected_parent_hash
            or registered_content_hash != expected_parent_hash
        ):
            raise FrameCacheCorruptedError(
                message=f"frame '{ref}' Lifecycle content identity is corrupt",
                context={"ref": ref, "cause": "parent artifact content hash mismatch"},
            )
        auxiliary_frames[manifest.filename] = trace
    loaded_frame = cast(
        "BaseFrame",
        frame_cls(
            _df=df,
            meta=parsed_meta,
            _auxiliary_frames=auxiliary_frames,
        ),
    )
    if recovery_marker is not None:
        expected_content_hash = compute_frame_content_hash(
            meta=parsed_meta,
            data_path=data_path,
        )
        evidence_status = recovery_marker["evidence_status"]
        sidecar_digest = parsed_meta.evidence_digest
        try:
            marker_store = session._evidence_store()
            if marker_store is None:
                raise EvidenceStoreUnavailableError(
                    message=(
                        f"cannot finalize recovery for artifact {ref!r} because "
                        "judgment.db is unavailable"
                    ),
                    context={"artifact_ref": ref},
                )
            digest_row = (
                marker_store.read()
                .execute(
                    "SELECT digest_payload, fingerprint FROM artifact_digests "
                    "WHERE artifact_id = ? AND session_id = ?",
                    (ref, session.id),
                )
                .fetchone()
            )
        except EvidenceStoreUnavailableError:
            raise
        except sqlite3.Error as exc:
            raise EvidenceStoreUnavailableError(
                message=f"cannot finalize evidence recovery for artifact {ref!r}",
                context={"artifact_ref": ref, "cause": str(exc)},
            ) from exc
        digest_mismatch = (
            evidence_status == "complete" and (sidecar_digest is None or digest_row is None)
        ) or (
            sidecar_digest is not None
            and (
                digest_row is None
                or digest_row["fingerprint"] != sidecar_digest.fingerprint
                or json.loads(digest_row["digest_payload"])
                != sidecar_digest.model_dump(mode="json")
            )
        )
        if (
            evidence_status not in {"complete", "partial", "unavailable"}
            or parsed_meta.evidence_status != evidence_status
            or parsed_meta.content_hash != expected_content_hash
            or compute_file_content_hash(data_path).removeprefix("sha256:")
            != recovery_marker["frame_sha"]
            or digest_mismatch
        ):
            raise FrameCacheCorruptedError(
                message=f"frame '{ref}' evidence recovery marker failed integrity validation",
                context={"ref": ref, "cause": "sidecar and evidence marker mismatch"},
            )
        from marivo.analysis._artifact_integrity import load_canonical_artifact_evidence

        load_canonical_artifact_evidence(
            session=session,
            store=marker_store,
            frame=loaded_frame,
            _recovery_data_path=data_path,
            _recovery_content_hash=expected_content_hash,
        )
        if artifact_row is None:
            session._store.record_recovered_artifact(
                session_id=session.id,
                artifact_id=ref,
                kind=parsed_meta.kind,
                path=session._layout.relative_path(data_path),
                meta_path=session._layout.relative_path(meta_path),
                content_hash=expected_content_hash,
                produced_by_job=parsed_meta.produced_by_job,
                evidence_status=parsed_meta.evidence_status,
                artifact_schema_version=parsed_meta.artifact_schema_version,
                finding_count=parsed_meta.finding_count,
                created_at=parsed_meta.created_at.isoformat(),
            )
    return loaded_frame
