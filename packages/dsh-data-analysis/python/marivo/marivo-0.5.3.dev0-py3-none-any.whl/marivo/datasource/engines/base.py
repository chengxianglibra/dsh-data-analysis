"""Engine profile foundation: dataclasses, generic profile, and cursor decode."""

from __future__ import annotations

from collections.abc import Callable, Mapping
from contextlib import AbstractContextManager
from dataclasses import dataclass
from typing import TYPE_CHECKING, Literal, TypeAlias

import ibis.expr.types as ir
from ibis.backends import BaseBackend

from marivo.datasource.ir import DatasourceIR, TableSourceIR

if TYPE_CHECKING:
    from marivo.datasource.metadata import MetadataWarning, TableMetadata

BackendDatetimeDecodePolicy: TypeAlias = Literal["local_naive_label", "utc_naive_instant"]
PartitionValueSource: TypeAlias = Literal["metadata", "system_catalog"]
AuthoringTimeout: TypeAlias = Callable[[BaseBackend, int], AbstractContextManager[None]]
MetadataResolutionFailure: TypeAlias = Literal["metadata_unavailable"]


def fail_closed_metadata_resolution(_exc: Exception) -> MetadataResolutionFailure | None:
    """Keep table-resolution failures closed unless a profile classifies one."""
    return None


def structured_exception_chain(exc: Exception) -> tuple[BaseException, ...]:
    """Return structured wrapper/original exceptions without parsing messages."""
    pending: list[BaseException] = [exc]
    seen: set[int] = set()
    resolved: list[BaseException] = []
    while pending and len(resolved) < 8:
        current = pending.pop(0)
        identity = id(current)
        if identity in seen:
            continue
        seen.add(identity)
        resolved.append(current)
        for candidate in (
            getattr(current, "orig", None),
            current.__cause__,
            current.__context__,
        ):
            if isinstance(candidate, BaseException):
                pending.append(candidate)
    return tuple(resolved)


@dataclass(frozen=True)
class QuantileCapability:
    mode: Literal["exact", "approximate"]
    method: str


@dataclass(frozen=True)
class CursorFrame:
    columns: tuple[str, ...]
    rows: tuple[dict[str, object], ...]
    types: dict[str, str]


@dataclass(frozen=True)
class TableRefRequest:
    source: TableSourceIR
    datasource_ir: DatasourceIR


@dataclass(frozen=True)
class PartitionProbeRequest:
    backend: BaseBackend
    datasource_ir: DatasourceIR
    source: TableSourceIR
    partition_columns: tuple[str, ...]
    limit: int
    order: Literal["asc", "desc"] = "desc"

    def __post_init__(self) -> None:
        if type(self.limit) is not int or self.limit < 1:
            raise ValueError("partition probe limit must be a positive integer")
        if type(self.order) is not str or self.order not in {"asc", "desc"}:
            raise ValueError("partition probe order must be 'asc' or 'desc'")


@dataclass(frozen=True)
class PartitionProbeResult:
    rows: tuple[dict[str, object], ...]
    value_source: PartitionValueSource


@dataclass(frozen=True)
class MetadataInspectRequest:
    datasource: str
    backend: BaseBackend
    table: str
    database: str | tuple[str, ...] | None
    table_expr: ir.Table
    include_partitions: bool
    datasource_ir: DatasourceIR


@dataclass(frozen=True)
class EngineMetadataIntrospection:
    inspect_table: Callable[[MetadataInspectRequest], TableMetadata]
    schema_only_warnings: tuple[MetadataWarning, ...] = ()
    classify_table_resolution_failure: Callable[[Exception], MetadataResolutionFailure | None] = (
        fail_closed_metadata_resolution
    )


@dataclass(frozen=True)
class AuthoringCapabilities:
    partition_predicate_supported: bool
    transformed_partition_supported: bool
    timeout_enforced: bool
    byte_estimate_supported: bool


@dataclass(frozen=True)
class EngineProfile:
    name: str
    aliases: tuple[str, ...]
    authoring_func: str
    required_modules: tuple[str, ...]
    connect: Callable[[str, Mapping[str, object]], BaseBackend]
    apply_read_only_kwargs: Callable[[Mapping[str, object]], dict[str, object]]
    timezone_probe_sql: str | None
    identifier_quote: str
    table_name_parts: Callable[[TableRefRequest], tuple[str, ...]]
    inspect_partition_values: Callable[[PartitionProbeRequest], PartitionProbeResult] | None
    readonly_tx_start: str | None
    metadata: EngineMetadataIntrospection
    authoring_capabilities: AuthoringCapabilities
    translate_strptime_format: Callable[[str], str]
    postprocess_sql: Callable[[str], str]
    datetime_decode_policy: BackendDatetimeDecodePolicy
    quantile: QuantileCapability | None
    percentile_uses_approx_quantile: bool
    authoring_timeout: AuthoringTimeout | None

    def __post_init__(self) -> None:
        timeout_enforced = self.authoring_timeout is not None
        if self.authoring_capabilities.timeout_enforced != timeout_enforced:
            raise ValueError(
                "authoring_capabilities.timeout_enforced must match "
                "whether authoring_timeout is configured"
            )


def identity_read_only_kwargs(kwargs: Mapping[str, object]) -> dict[str, object]:
    return dict(kwargs)


def identity_str(value: str) -> str:
    return value


def default_table_name_parts(request: TableRefRequest) -> tuple[str, ...]:
    database = request.source.database
    if database is None:
        return (request.source.table,)
    if isinstance(database, tuple):
        return (*tuple(str(part) for part in database), request.source.table)
    return (str(database), request.source.table)


def quote_identifier(value: str, profile: EngineProfile) -> str:
    """Quote *value* as a SQL identifier using *profile*'s quote character."""
    quote = profile.identifier_quote
    escaped = value.replace(quote, quote + quote)
    return f"{quote}{escaped}{quote}"


def require_field(
    name: str,
    kwargs: Mapping[str, object],
    key: str,
    *,
    help_target: str,
) -> object:
    from marivo.datasource.errors import DatasourceFieldInvalidError, repair

    if key not in kwargs:
        raise DatasourceFieldInvalidError(
            message=f"datasource {name!r} missing required field {key!r}",
            expected=f"required datasource field {key!r}",
            received="missing",
            location=f"datasource {name!r}",
            repair=repair(
                kind="reauthor",
                canonical_id=help_target,
                action="Provide the required datasource field.",
            ),
        )
    return kwargs[key]


def _generic_connect_unsupported(name: str, kwargs: Mapping[str, object]) -> BaseBackend:
    from marivo.datasource.errors import DatasourceBackendTypeUnsupportedError, repair

    raise DatasourceBackendTypeUnsupportedError(
        message=f"datasource {name!r} cannot connect through GENERIC_PROFILE",
        expected="a supported datasource backend type",
        received="generic",
        location=f"datasource {name!r}",
        repair=repair(
            kind="configure",
            canonical_id="register",
            action="Use a supported datasource backend type.",
        ),
    )


def generic_metadata_inspect(request: MetadataInspectRequest) -> TableMetadata:
    from marivo.datasource.metadata import _schema_only

    return _schema_only(
        datasource=request.datasource,
        table=request.table,
        database=request.database,
        backend_type=GENERIC_PROFILE.name,
        table_expr=request.table_expr,
        warnings=GENERIC_PROFILE.metadata.schema_only_warnings,
    )


def decode_cursor_frame(
    cursor: object,
    *,
    include_types: bool,
    max_rows: int | None,
) -> CursorFrame:
    row_limit = max_rows + 1 if max_rows is not None else None
    description = getattr(cursor, "description", None)
    fetchall = getattr(cursor, "fetchall", None)
    if description is not None and callable(fetchall):
        columns = tuple(str(item[0]) for item in description)
        types = {str(item[0]): str(item[1]) for item in description} if include_types else {}
        fetchmany = getattr(cursor, "fetchmany", None)
        raw_rows = (
            fetchmany(row_limit) if row_limit is not None and callable(fetchmany) else fetchall()
        )
        if row_limit is not None:
            raw_rows = raw_rows[:row_limit]
        return CursorFrame(
            columns=columns,
            rows=tuple(dict(zip(columns, row, strict=True)) for row in raw_rows),
            types=types,
        )
    column_names = getattr(cursor, "column_names", None)
    result_rows = getattr(cursor, "result_rows", None)
    if column_names and result_rows is not None:
        columns = tuple(str(name) for name in column_names)
        raw_rows = result_rows[:row_limit] if row_limit is not None else result_rows
        return CursorFrame(
            columns=columns,
            rows=tuple(dict(zip(columns, row, strict=True)) for row in raw_rows),
            types={},
        )
    return CursorFrame(columns=(), rows=(), types={})


GENERIC_PROFILE = EngineProfile(
    name="generic",
    aliases=(),
    authoring_func="",
    required_modules=(),
    connect=_generic_connect_unsupported,
    apply_read_only_kwargs=identity_read_only_kwargs,
    timezone_probe_sql=None,
    identifier_quote='"',
    table_name_parts=default_table_name_parts,
    inspect_partition_values=None,
    readonly_tx_start=None,
    metadata=EngineMetadataIntrospection(inspect_table=generic_metadata_inspect),
    authoring_capabilities=AuthoringCapabilities(
        partition_predicate_supported=False,
        transformed_partition_supported=False,
        timeout_enforced=False,
        byte_estimate_supported=False,
    ),
    translate_strptime_format=identity_str,
    postprocess_sql=identity_str,
    datetime_decode_policy="local_naive_label",
    quantile=None,
    percentile_uses_approx_quantile=False,
    authoring_timeout=None,
)
